<?php
/**
 * Reusable theme output helpers.
 *
 * @package Xiujin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function xiujin_theme_asset( $filename ) {
	return XIUJIN_THEME_URI . '/assets/images/' . ltrim( $filename, '/' );
}

function xiujin_company_name() {
	return sanitize_text_field( (string) get_theme_mod( 'xiujin_company_name', 'Bazhou Xiujin Furniture Co., Ltd' ) );
}

/**
 * Return the verified WhatsApp contact URL.
 *
 * Keeping the default here gives a newly installed theme a working contact
 * path while the Customizer setting still lets an administrator replace it.
 *
 * @return string
 */
function xiujin_whatsapp_url() {
	return esc_url_raw(
		(string) get_theme_mod( 'xiujin_whatsapp_url', 'https://wa.me/8618406845852' ),
		array( 'http', 'https' )
	);
}

/**
 * Return the current language's home URL, optionally with a page anchor.
 *
 * Polylang and WPML both expose a localized home URL. Using it here keeps
 * header and footer links in the visitor's selected language.
 *
 * @param string $anchor Optional anchor without the hash character.
 * @return string
 */
function xiujin_home_url( $anchor = '' ) {
	$url = home_url( '/' );

	if ( function_exists( 'pll_home_url' ) ) {
		$localized_url = pll_home_url();
		if ( $localized_url ) {
			$url = $localized_url;
		}
	} elseif ( has_filter( 'wpml_home_url' ) ) {
		$localized_url = apply_filters( 'wpml_home_url', $url );
		if ( is_string( $localized_url ) && $localized_url ) {
			$url = $localized_url;
		}
	}

	$anchor = sanitize_title( ltrim( (string) $anchor, '#' ) );
	if ( $anchor ) {
		$url = preg_replace( '/#.*$/', '', $url ) . '#' . $anchor;
	}

	return $url;
}

function xiujin_social_links() {
	$networks = array(
		'facebook'  => __( 'Facebook', 'xiujin' ),
		'instagram' => __( 'Instagram', 'xiujin' ),
		'tiktok'    => __( 'TikTok', 'xiujin' ),
		'whatsapp'  => __( 'WhatsApp', 'xiujin' ),
		'messenger' => __( 'Messenger', 'xiujin' ),
	);
	$links = array();
	foreach ( $networks as $key => $label ) {
		$url = 'whatsapp' === $key
			? xiujin_whatsapp_url()
			: esc_url_raw( (string) get_theme_mod( 'xiujin_' . $key . '_url', '' ), array( 'http', 'https' ) );
		if ( $url ) {
			$links[ $key ] = array( 'label' => $label, 'url' => $url );
		}
	}
	return $links;
}

function xiujin_language_switcher() {
	if ( function_exists( 'pll_the_languages' ) ) {
		echo '<label class="language-switcher"><span class="screen-reader-text">' . esc_html__( 'Language selection', 'xiujin' ) . '</span>';
		pll_the_languages(
			array(
				'show_flags'            => 0,
				'show_names'            => 1,
				'dropdown'              => 1,
				'hide_if_empty'         => 0,
				'hide_if_no_translation' => 0,
				'force_home'            => 0,
			)
		);
		echo '</label>';
		return;
	}
	if ( has_action( 'wpml_add_language_selector' ) ) {
		echo '<div class="language-switcher" aria-label="' . esc_attr__( 'Language selection', 'xiujin' ) . '">';
		do_action( 'wpml_add_language_selector' );
		echo '</div>';
	}
}

/**
 * Avoid duplicate menu-item IDs when menus are rendered in more than one
 * navigation region.
 *
 * @param string   $menu_id Menu item ID.
 * @param WP_Post  $item    Menu item object.
 * @param stdClass $args    Menu arguments.
 * @return string
 */
function xiujin_mobile_menu_item_id( $menu_id, $item, $args ) {
	unset( $item );
	if ( isset( $args->menu_class ) && in_array( $args->menu_class, array( 'mobile-menu', 'footer-menu' ), true ) ) {
		return '';
	}
	return $menu_id;
}
add_filter( 'nav_menu_item_id', 'xiujin_mobile_menu_item_id', 10, 3 );

function xiujin_section_heading( $eyebrow, $heading, $intro = '' ) {
	?>
	<div class="section-heading" data-reveal>
		<div>
			<span class="eyebrow"><?php echo esc_html( $eyebrow ); ?></span>
			<h2><?php echo esc_html( $heading ); ?></h2>
		</div>
		<?php if ( $intro ) : ?>
			<p><?php echo esc_html( $intro ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

function xiujin_render_social_links( $class_name = 'social-links', $excluded = array() ) {
	$links = xiujin_social_links();
	foreach ( (array) $excluded as $key ) {
		unset( $links[ sanitize_key( $key ) ] );
	}
	if ( ! $links ) {
		return;
	}
	echo '<div class="' . esc_attr( $class_name ) . '">';
	foreach ( $links as $key => $item ) {
		printf(
			'<a class="social-link social-link--%1$s" href="%2$s" target="_blank" rel="noopener noreferrer"><span>%3$s</span></a>',
			esc_attr( $key ),
			esc_url( $item['url'] ),
			esc_html( $item['label'] )
		);
	}
	echo '</div>';
}

