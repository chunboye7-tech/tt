<?php
/**
 * Lightweight fallback metadata. Dedicated SEO plugins take precedence.
 *
 * @package Xiujin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function xiujin_has_seo_plugin() {
	return defined( 'WPSEO_VERSION' )
		|| defined( 'RANK_MATH_VERSION' )
		|| defined( 'AIOSEO_VERSION' )
		|| defined( 'THE_SEO_FRAMEWORK_VERSION' )
		|| defined( 'SEOPRESS_VERSION' )
		|| defined( 'SLIM_SEO_VER' );
}

/**
 * Return the canonical URL for the current front-page request.
 *
 * @return string
 */
function xiujin_front_page_canonical_url() {
	$paged = max( 1, absint( get_query_var( 'paged' ) ) );
	if ( $paged > 1 ) {
		return get_pagenum_link( $paged, false );
	}

	return xiujin_home_url();
}

function xiujin_fallback_meta() {
	if ( xiujin_has_seo_plugin() || ! is_front_page() ) {
		return;
	}
	$description    = __( 'Explore XIUJIN factory-direct office and gaming chairs for wholesale and retail enquiries.', 'xiujin' );
	$image          = xiujin_theme_asset( 'hero-chair-collection.webp' );
	$image_width    = 1200;
	$image_height   = 900;
	$image_alt      = __( 'XIUJIN office and gaming chair collection', 'xiujin' );
	$hero_image_id  = absint( get_theme_mod( 'xiujin_hero_image', 0 ) );
	$hero_image     = $hero_image_id ? wp_get_attachment_image_src( $hero_image_id, 'full' ) : false;
	if ( is_array( $hero_image ) && ! empty( $hero_image[0] ) ) {
		$image        = $hero_image[0];
		$image_width  = absint( $hero_image[1] );
		$image_height = absint( $hero_image[2] );
		$custom_alt   = trim( (string) get_post_meta( $hero_image_id, '_wp_attachment_image_alt', true ) );
		if ( '' !== $custom_alt ) {
			$image_alt = $custom_alt;
		}
	}
	$document_title = wp_get_document_title();
	$canonical_url  = xiujin_front_page_canonical_url();
	$locale         = get_locale();
	?>
	<meta name="description" content="<?php echo esc_attr( $description ); ?>">
	<?php if ( ! is_singular() ) : ?>
		<link rel="canonical" href="<?php echo esc_url( $canonical_url ); ?>">
	<?php endif; ?>
	<meta property="og:type" content="website">
	<meta property="og:title" content="<?php echo esc_attr( $document_title ); ?>">
	<meta property="og:description" content="<?php echo esc_attr( $description ); ?>">
	<meta property="og:url" content="<?php echo esc_url( $canonical_url ); ?>">
	<meta property="og:site_name" content="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
	<?php if ( $locale ) : ?><meta property="og:locale" content="<?php echo esc_attr( $locale ); ?>"><?php endif; ?>
	<meta property="og:image" content="<?php echo esc_url( $image ); ?>">
	<meta property="og:image:width" content="<?php echo esc_attr( (string) $image_width ); ?>">
	<meta property="og:image:height" content="<?php echo esc_attr( (string) $image_height ); ?>">
	<meta property="og:image:alt" content="<?php echo esc_attr( $image_alt ); ?>">
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="<?php echo esc_attr( $document_title ); ?>">
	<meta name="twitter:description" content="<?php echo esc_attr( $description ); ?>">
	<meta name="twitter:image" content="<?php echo esc_url( $image ); ?>">
	<meta name="twitter:image:alt" content="<?php echo esc_attr( $image_alt ); ?>">
	<?php
}
add_action( 'wp_head', 'xiujin_fallback_meta', 2 );

function xiujin_organization_schema() {
	if ( xiujin_has_seo_plugin() || ! is_front_page() ) {
		return;
	}
	$site_url     = xiujin_home_url();
	$language     = get_bloginfo( 'language' );
	$organization = array(
		'@type' => 'Organization',
		'@id'   => rtrim( $site_url, '/' ) . '/#organization',
		'name'  => xiujin_company_name(),
		'url'   => $site_url,
	);
	$logo_id = get_theme_mod( 'custom_logo' );
	if ( $logo_id ) {
		$logo = wp_get_attachment_image_url( $logo_id, 'full' );
		if ( $logo ) {
			$organization['logo'] = $logo;
		}
	}
	$social  = xiujin_social_links();
	$same_as = array();
	foreach ( array( 'facebook', 'instagram', 'tiktok' ) as $network ) {
		if ( isset( $social[ $network ]['url'] ) ) {
			$same_as[] = $social[ $network ]['url'];
		}
	}
	if ( $same_as ) {
		$organization['sameAs'] = $same_as;
	}
	$phone = sanitize_text_field( (string) get_theme_mod( 'xiujin_phone', '' ) );
	$email = sanitize_email( (string) get_theme_mod( 'xiujin_email', '' ) );
	if ( $phone || $email ) {
		$organization['contactPoint'] = array_filter(
			array(
				'@type'       => 'ContactPoint',
				'telephone'   => $phone,
				'email'       => $email,
				'contactType' => 'sales',
			)
		);
	}
	$data = array(
		'@context' => 'https://schema.org',
		'@graph'   => array(
			$organization,
			array(
				'@type'     => 'WebSite',
				'@id'       => $site_url . '#website',
				'url'       => $site_url,
				'name'      => get_bloginfo( 'name' ),
				'publisher' => array( '@id' => rtrim( $site_url, '/' ) . '/#organization' ),
				'inLanguage' => $language,
			),
		),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
add_action( 'wp_head', 'xiujin_organization_schema', 30 );

