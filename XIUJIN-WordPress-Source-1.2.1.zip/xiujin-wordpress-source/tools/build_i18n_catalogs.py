#!/usr/bin/env python3
"""Build and verify XIUJIN theme and plugin gettext catalogs.

The source of truth is the current PHP/CSS metadata plus reviewed JSON
translation maps.  The build fails when a new gettext message has no Spanish
or Portuguese translation, when a text domain is wrong, or when printf
placeholders/HTML tags do not match.  This prevents shipped MO files from
silently falling behind the PHP templates.
"""

from __future__ import annotations

import json
import re
import shutil
import struct
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "tools" / "i18n_copy.json"
OUT = ROOT / "i18n-staging"
THEME = ROOT / "theme" / "xiujin-furniture"
PLUGIN = ROOT / "plugin" / "xiujin-store-core"
TRANSLATION_CALL = re.compile(
    r"\b(?P<function>__|_e|_x|esc_html__|esc_attr__|esc_html_e|esc_attr_e)"
    r"\(\s*(?P<quote>['\"])(?P<message>(?:\\.|(?!\2).)*)\2",
    re.DOTALL,
)
PLURAL_CALL = re.compile(r"\b(?:_n|_nx|_n_noop|_nx_noop)\s*\(")
PRINTF_PLACEHOLDER = re.compile(
    r"%(?:\d+\$)?[-+0 '#]*\d*(?:\.\d+)?[bcdeEfFgGgosuxX]"
)
HTML_TAG = re.compile(r"</?([a-zA-Z][a-zA-Z0-9-]*)\b[^>]*>")

COMPONENTS = {
    "theme": {
        "root": THEME,
        "domain": "xiujin",
        "translations": {
            "es_ES": ROOT / "tools" / "theme_gettext_es.json",
            "pt_BR": ROOT / "tools" / "theme_gettext_pt_BR.json",
        },
        "metadata": (THEME / "style.css", ("Theme Name", "Description", "Author")),
        "output": THEME / "languages",
        # WordPress resolves a bundled theme catalog as languages/{locale}.mo.
        # The domain-prefixed convention is for plugins and language packs in
        # wp-content/languages, not a custom directory inside the theme.
        "catalog_style": "locale",
        "staging": OUT,
        "project": "XIUJIN Furniture 1.2.1",
    },
    "plugin": {
        "root": PLUGIN,
        "domain": "xiujin-store-core",
        "translations": {
            "es_ES": ROOT / "tools" / "plugin_gettext_es_ES.json",
            "pt_BR": ROOT / "tools" / "plugin_gettext_pt_BR.json",
        },
        "metadata": (
            PLUGIN / "xiujin-store-core.php",
            ("Plugin Name", "Description", "Author"),
        ),
        "output": PLUGIN / "languages",
        "catalog_style": "domain-locale",
        "project": "XIUJIN Store Core 1.2.1",
    },
}


def catalog_filename(component: dict, locale: str, extension: str) -> str:
    """Return the runtime filename WordPress expects for this component."""

    if component["catalog_style"] == "locale":
        return f"{locale}.{extension}"
    return f"{component['domain']}-{locale}.{extension}"


def po_quote(value: str) -> str:
    return (
        value.replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\t", "\\t")
        .replace("\r", "\\r")
        .replace("\n", "\\n")
    )


def catalog_header(project: str, domain: str, locale: str, language_name: str) -> str:
    plural = "nplurals=2; plural=(n != 1);"
    is_template = not locale
    return (
        f"Project-Id-Version: {project}\n"
        "Report-Msgid-Bugs-To: \n"
        "POT-Creation-Date: 2026-10-20 00:00+0800\n"
        + ("PO-Revision-Date: YEAR-MO-DA HO:MI+ZONE\n" if is_template else "PO-Revision-Date: 2026-10-20 00:00+0800\n")
        + f"Language: {locale}\n"
        + f"Language-Team: {language_name}\n"
        "MIME-Version: 1.0\n"
        "Content-Type: text/plain; charset=UTF-8\n"
        "Content-Transfer-Encoding: 8bit\n"
        f"Plural-Forms: {plural}\n"
        f"X-Domain: {domain}\n"
        f"X-Locale: {locale}\n"
    )


def planned_translation_map(data: dict, locale: str) -> dict[str, str]:
    source = data["locales"]["en_US"]
    target = data["locales"][locale]
    seen: dict[str, str] = {}

    for section in ("strings", "seo"):
        for key, msgid in source[section].items():
            if not isinstance(msgid, str):
                continue
            msgstr = target[section][key] if locale != "en_US" else ""
            if msgid in seen and seen[msgid] != msgstr:
                raise ValueError(
                    f"Conflicting translation for duplicate msgid {msgid!r} in {locale}"
                )
            seen[msgid] = msgstr
    return seen


def decode_php_string(value: str) -> str:
    return value.replace("\\'", "'").replace('\\"', '"').replace("\\\\", "\\")


def translation_call_text(source: str, match: re.Match[str]) -> str:
    """Return the complete gettext call using a small string-aware scanner."""

    start = source.find("(", match.start())
    depth = 0
    quote = ""
    escaped = False
    for index in range(start, len(source)):
        character = source[index]
        if quote:
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == quote:
                quote = ""
            continue
        if character in "'\"":
            quote = character
        elif character == "(":
            depth += 1
        elif character == ")":
            depth -= 1
            if depth == 0:
                return source[match.start() : index + 1]
    raise ValueError("Unterminated gettext call")


def extract_metadata(path: Path, fields: tuple[str, ...]) -> dict[str, list[str]]:
    source = path.read_text(encoding="utf-8")
    messages: dict[str, list[str]] = {}
    for field in fields:
        match = re.search(rf"(?mi)^\s*(?:/\*+|\*)?\s*{re.escape(field)}:\s*(.+?)\s*$", source)
        if match:
            messages.setdefault(match.group(1).strip(), []).append(
                f"{path.name}:{source.count(chr(10), 0, match.start()) + 1}"
            )
    return messages


def extract_messages(component: dict) -> dict[str, list[str]]:
    messages: dict[str, list[str]] = {}
    root = component["root"]
    expected_domain = component["domain"]
    for path in sorted(root.rglob("*.php")):
        relative = path.relative_to(root).as_posix()
        source = path.read_text(encoding="utf-8")
        if PLURAL_CALL.search(source):
            raise ValueError(f"Plural gettext calls need explicit catalog support: {relative}")
        for match in TRANSLATION_CALL.finditer(source):
            call = translation_call_text(source, match)
            if not re.search(rf"['\"]{re.escape(expected_domain)}['\"]", call):
                line = source.count("\n", 0, match.start()) + 1
                raise ValueError(f"Wrong or missing text domain in {relative}:{line}")
            msgid = decode_php_string(match.group("message"))
            line = source.count("\n", 0, match.start()) + 1
            messages.setdefault(msgid, []).append(f"{relative}:{line}")
    metadata_path, fields = component["metadata"]
    for msgid, references in extract_metadata(metadata_path, fields).items():
        messages.setdefault(msgid, []).extend(references)
    return messages


def validate_translation(msgid: str, msgstr: str, locale: str) -> None:
    if not msgstr.strip():
        raise ValueError(f"{locale} has an empty translation for {msgid!r}")
    if Counter(PRINTF_PLACEHOLDER.findall(msgid)) != Counter(PRINTF_PLACEHOLDER.findall(msgstr)):
        raise ValueError(f"{locale} changes printf placeholders for {msgid!r}")
    if Counter(HTML_TAG.findall(msgid)) != Counter(HTML_TAG.findall(msgstr)):
        raise ValueError(f"{locale} changes HTML tags for {msgid!r}")


def collect_messages(component: dict, locale: str) -> list[tuple[str, str, str]]:
    messages = extract_messages(component)
    translations: dict[str, str] = {}
    if locale:
        translation_path = component["translations"][locale]
        translations = json.loads(translation_path.read_text(encoding="utf-8"))
        if not isinstance(translations, dict):
            raise TypeError(f"{translation_path} must contain a JSON object")

    missing = sorted(msgid for msgid in messages if locale and msgid not in translations)
    if missing:
        preview = "\n".join(f"  - {msgid}" for msgid in missing[:25])
        raise ValueError(
            f"{locale} is missing {len(missing)} theme translations:\n{preview}"
        )

    rows: list[tuple[str, str, str]] = []
    for msgid, references in sorted(messages.items(), key=lambda item: item[0].casefold()):
        msgstr = translations.get(msgid, "")
        if locale:
            validate_translation(msgid, msgstr, locale)
        key = "source: " + " ".join(sorted(set(references)))
        rows.append((key, msgid, msgstr))
    return rows


def write_po(path: Path, rows: list[tuple[str, str, str]], header: str) -> None:
    lines = [
        '# XIUJIN Furniture translation catalog.',
        '# Fixed theme UI only; WordPress content is translated with Polylang or WPML.',
        'msgid ""',
        'msgstr ""',
    ]
    lines.extend(f'"{po_quote(line + chr(10))}"' for line in header.rstrip("\n").split("\n"))
    lines.append("")
    for key, msgid, msgstr in sorted(rows, key=lambda row: row[1].casefold()):
        if PRINTF_PLACEHOLDER.search(msgid):
            lines.append("#, php-format")
        lines.extend(
            [
                f"#. {key}",
                f'msgid "{po_quote(msgid)}"',
                f'msgstr "{po_quote(msgstr)}"',
                "",
            ]
        )
    path.write_text("\n".join(lines), encoding="utf-8")


def write_mo(path: Path, translations: dict[str, str]) -> None:
    """Write a little-endian GNU MO catalog without external dependencies."""

    keys = sorted(translations)
    ids = [key.encode("utf-8") for key in keys]
    strings = [translations[key].encode("utf-8") for key in keys]
    count = len(keys)
    key_table_offset = 28
    value_table_offset = key_table_offset + count * 8
    key_data_offset = value_table_offset + count * 8

    key_data = b""
    key_entries: list[tuple[int, int]] = []
    for value in ids:
        key_entries.append((len(value), key_data_offset + len(key_data)))
        key_data += value + b"\0"

    value_data_offset = key_data_offset + len(key_data)
    value_data = b""
    value_entries: list[tuple[int, int]] = []
    for value in strings:
        value_entries.append((len(value), value_data_offset + len(value_data)))
        value_data += value + b"\0"

    output = bytearray()
    output.extend(
        struct.pack(
            "<7I",
            0x950412DE,
            0,
            count,
            key_table_offset,
            value_table_offset,
            0,
            0,
        )
    )
    for length, offset in key_entries:
        output.extend(struct.pack("<2I", length, offset))
    for length, offset in value_entries:
        output.extend(struct.pack("<2I", length, offset))
    output.extend(key_data)
    output.extend(value_data)
    path.write_bytes(output)


def read_mo(path: Path) -> dict[str, str]:
    """Load enough of a GNU MO file to verify the generated catalog."""

    data = path.read_bytes()
    magic, version, count, ids_offset, strings_offset, _, _ = struct.unpack(
        "<7I", data[:28]
    )
    if magic != 0x950412DE or version != 0:
        raise ValueError(f"Invalid MO header: {path}")
    messages: dict[str, str] = {}
    for index in range(count):
        id_length, id_offset = struct.unpack(
            "<2I", data[ids_offset + index * 8 : ids_offset + index * 8 + 8]
        )
        value_length, value_offset = struct.unpack(
            "<2I",
            data[strings_offset + index * 8 : strings_offset + index * 8 + 8],
        )
        messages[data[id_offset : id_offset + id_length].decode("utf-8")] = data[
            value_offset : value_offset + value_length
        ].decode("utf-8")
    return messages


def main() -> None:
    data = json.loads(SOURCE.read_text(encoding="utf-8"))
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True, exist_ok=True)
    manifest = {"source_locale": data["_meta"]["source_locale"], "components": {}}
    language_names = {
        "es_ES": data["locales"]["es_ES"]["language_name"],
        "pt_BR": data["locales"]["pt_BR"]["language_name"],
    }

    for component_name, component in COMPONENTS.items():
        output = component["output"]
        output.mkdir(parents=True, exist_ok=True)
        domain = component["domain"]
        # Remove generated locale catalogs from earlier builds, including the
        # formerly shipped plugin-style filenames in the bundled theme.
        for locale in ("es_ES", "pt_BR"):
            candidates = {
                output / f"{locale}.po",
                output / f"{locale}.mo",
                output / f"{domain}-{locale}.po",
                output / f"{domain}-{locale}.mo",
            }
            for candidate in candidates:
                candidate.unlink(missing_ok=True)
        source_rows = collect_messages(component, "")
        template_header = catalog_header(
            component["project"], domain, "", "LANGUAGE"
        )
        write_po(output / f"{domain}.pot", source_rows, template_header)

        built_files = [f"{domain}.pot"]
        for locale in ("es_ES", "pt_BR"):
            rows = collect_messages(component, locale)
            header = catalog_header(
                component["project"], domain, locale, language_names[locale]
            )
            po_path = output / catalog_filename(component, locale, "po")
            mo_path = output / catalog_filename(component, locale, "mo")
            write_po(po_path, rows, header)
            translations = {msgid: msgstr for _, msgid, msgstr in rows}
            translations[""] = header
            write_mo(mo_path, translations)
            if read_mo(mo_path) != translations:
                raise ValueError(f"MO round-trip verification failed: {mo_path}")
            built_files.extend((po_path.name, mo_path.name))

        if "staging" in component:
            component["staging"].mkdir(parents=True, exist_ok=True)
            for filename in built_files:
                shutil.copy2(output / filename, component["staging"] / filename)

        manifest["components"][component_name] = {
            "text_domain": domain,
            "message_count": len(source_rows),
            "locales": {
                "es_ES": {"translated": len(source_rows), "coverage": "100%"},
                "pt_BR": {"translated": len(source_rows), "coverage": "100%"},
            },
            "files": built_files,
        }

    (OUT / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
