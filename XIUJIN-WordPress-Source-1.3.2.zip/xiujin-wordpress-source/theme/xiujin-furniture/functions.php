<?php
/**
 * XIUJIN Furniture theme bootstrap.
 *
 * @package Xiujin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'XIUJIN_THEME_VERSION', '1.3.2' );
define( 'XIUJIN_THEME_DIR', get_template_directory() );
define( 'XIUJIN_THEME_URI', get_template_directory_uri() );

require_once XIUJIN_THEME_DIR . '/inc/setup.php';
require_once XIUJIN_THEME_DIR . '/inc/catalog-data.php';
require_once XIUJIN_THEME_DIR . '/inc/template-tags.php';
require_once XIUJIN_THEME_DIR . '/inc/customizer.php';
require_once XIUJIN_THEME_DIR . '/inc/woocommerce.php';
require_once XIUJIN_THEME_DIR . '/inc/seo.php';

