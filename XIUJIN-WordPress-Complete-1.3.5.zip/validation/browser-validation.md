# Static preview browser validation

- Checks: 122
- Passed: 122
- Failed: 0

| Viewport | Check | Result | Details |
|---|---|---:|---|
| desktop-1440 | Page responds successfully | PASS | 200 |
| desktop-1440 | 18 product cards | PASS | 18 |
| desktop-1440 | 6 real configurations | PASS | 6 |
| desktop-1440 | 10 showroom visuals | PASS | 10 |
| desktop-1440 | 4 verified factory photographs | PASS | 4 |
| desktop-1440 | 2 accessible header social icons | PASS | ["Facebook","TikTok"] |
| desktop-1440 | No visible 8011 | PASS | body.innerText |
| desktop-1440 | No visible Shopify copy | PASS | body.innerText |
| desktop-1440 | No Shopify runtime/source | PASS | HTML source |
| desktop-1440 | All images load | PASS |  |
| desktop-1440 | No horizontal page overflow | PASS | {"clientWidth":1440,"rootScrollWidth":1440,"bodyScrollWidth":1440,"offenders":[{"selector":"div.hero-orb.hero-orb--one","left":1190,"right":1570},{"selector":"div.hero-orb.hero-orb--two","left":-132,"right":161},{"selector":"div.quote-orb","left":1240,"right":1540}]} |
| desktop-1440 | 18 normalized 720 × 720 catalog images | PASS | {"count":18,"bad":[]} |
| desktop-1440 | Catalog images use contain fit | PASS | [] |
| desktop-1440 | 3-column responsive catalog grid | PASS | columns=3 |
| desktop-1440 | Catalog image areas have a consistent height | PASS | [280,280,280,280,280,280,280,280,280,280,280,280,280,280,280,280,280,280] |
| desktop-1440 | Sticky header has an opaque background | PASS | rgb(255, 255, 255) |
| desktop-1440 | Configuration selector works | PASS | {"secondPressed":"true","source":"assets/images/config-red-rgb.webp","title":"Red / black with color trim"} |
| desktop-1440 | Six photo-to-3D mappings are declared | PASS | {"mappings":["0","1","4","5","2","3"],"optionValues":["0","1","2","3","4","5"],"selectedValue":"1","activeModelIndex":"1"} |
| desktop-1440 | Photo selection synchronizes the pending 3D variant | PASS | {"mappings":["0","1","4","5","2","3"],"optionValues":["0","1","2","3","4","5"],"selectedValue":"1","activeModelIndex":"1"} |
| desktop-1440 | Showroom carousel advances | PASS | 755 |
| desktop-1440 | Enquiry link pre-fills product | PASS | 135° Reclining Gaming Chair |
| desktop-1440 | Factory photograph viewer opens, closes and restores focus | PASS | {"opened":true,"closed":true,"focusRestored":true,"lightboxTitle":"CNC cutting for wood components","expectedTitle":"CNC cutting for wood components","lightboxSource":"http://127.0.0.1:43193/assets/images/factory-cnc-wood-components.webp"} |
| desktop-1440 | Reveal motion initializes | PASS | {"root":true,"reveal":true,"transition":"opacity, transform","duration":"0.58s, 0.58s"} |
| desktop-1440 | 3D script deferred before click | PASS |  |
| desktop-1440 | 3D loads only after user action | PASS | {"ready":true,"error":false,"scripts":1,"status":"Red / black with color trim · Drag to rotate · Use buttons to zoom","variant":"red-black-color-trim","selectedValue":"1"} |
| desktop-1440 | 3D starts on the photo selected before loading | PASS | {"ready":true,"error":false,"scripts":1,"status":"Red / black with color trim · Drag to rotate · Use buttons to zoom","variant":"red-black-color-trim","selectedValue":"1"} |
| desktop-1440 | All six photos select their matching 3D variants | PASS | [] |
| desktop-1440 | No console errors | PASS |  |
| desktop-1440 | No uncaught page errors | PASS |  |
| desktop-1440 | No failed network requests | PASS |  |
| desktop-1440 | No Shopify network requests | PASS |  |
| tablet-768 | Page responds successfully | PASS | 200 |
| tablet-768 | 18 product cards | PASS | 18 |
| tablet-768 | 6 real configurations | PASS | 6 |
| tablet-768 | 10 showroom visuals | PASS | 10 |
| tablet-768 | 4 verified factory photographs | PASS | 4 |
| tablet-768 | 2 accessible header social icons | PASS | ["Facebook","TikTok"] |
| tablet-768 | No visible 8011 | PASS | body.innerText |
| tablet-768 | No visible Shopify copy | PASS | body.innerText |
| tablet-768 | No Shopify runtime/source | PASS | HTML source |
| tablet-768 | All images load | PASS |  |
| tablet-768 | No horizontal page overflow | PASS | {"clientWidth":768,"rootScrollWidth":768,"bodyScrollWidth":768,"offenders":[{"selector":"div.hero-orb.hero-orb--one","left":518,"right":898},{"selector":"div.hero-orb.hero-orb--two","left":-125,"right":165},{"selector":"div.quote-orb","left":568,"right":868}]} |
| tablet-768 | 18 normalized 720 × 720 catalog images | PASS | {"count":18,"bad":[]} |
| tablet-768 | Catalog images use contain fit | PASS | [] |
| tablet-768 | 2-column responsive catalog grid | PASS | columns=2 |
| tablet-768 | Catalog image areas have a consistent height | PASS | [270,270,270,270,270,270,270,270,270,270,270,270,270,270,270,270,270,270] |
| tablet-768 | Sticky header has an opaque background | PASS | rgb(255, 255, 255) |
| tablet-768 | Configuration selector works | PASS | {"secondPressed":"true","source":"assets/images/config-red-rgb.webp","title":"Red / black with color trim"} |
| tablet-768 | Six photo-to-3D mappings are declared | PASS | {"mappings":["0","1","4","5","2","3"],"optionValues":["0","1","2","3","4","5"],"selectedValue":"1","activeModelIndex":"1"} |
| tablet-768 | Photo selection synchronizes the pending 3D variant | PASS | {"mappings":["0","1","4","5","2","3"],"optionValues":["0","1","2","3","4","5"],"selectedValue":"1","activeModelIndex":"1"} |
| tablet-768 | Showroom carousel advances | PASS | 710 |
| tablet-768 | Enquiry link pre-fills product | PASS | 135° Reclining Gaming Chair |
| tablet-768 | Factory photograph viewer opens, closes and restores focus | PASS | {"opened":true,"closed":true,"focusRestored":true,"lightboxTitle":"CNC cutting for wood components","expectedTitle":"CNC cutting for wood components","lightboxSource":"http://127.0.0.1:43193/assets/images/factory-cnc-wood-components.webp"} |
| tablet-768 | Mobile menu opens and closes | PASS | opened=true, closed=true |
| tablet-768 | Mobile content renders without scroll-triggered reveal delays | PASS | {"root":true,"reveal":true,"transition":"none","duration":"0s"} |
| tablet-768 | No console errors | PASS |  |
| tablet-768 | No uncaught page errors | PASS |  |
| tablet-768 | No failed network requests | PASS |  |
| tablet-768 | No Shopify network requests | PASS |  |
| mobile-390 | Page responds successfully | PASS | 200 |
| mobile-390 | 18 product cards | PASS | 18 |
| mobile-390 | 6 real configurations | PASS | 6 |
| mobile-390 | 10 showroom visuals | PASS | 10 |
| mobile-390 | 4 verified factory photographs | PASS | 4 |
| mobile-390 | 2 accessible header social icons | PASS | ["Facebook","TikTok"] |
| mobile-390 | No visible 8011 | PASS | body.innerText |
| mobile-390 | No visible Shopify copy | PASS | body.innerText |
| mobile-390 | No Shopify runtime/source | PASS | HTML source |
| mobile-390 | All images load | PASS |  |
| mobile-390 | No horizontal page overflow | PASS | {"clientWidth":390,"rootScrollWidth":390,"bodyScrollWidth":390,"offenders":[{"selector":"div.quote-orb","left":190,"right":490}]} |
| mobile-390 | 18 normalized 720 × 720 catalog images | PASS | {"count":18,"bad":[]} |
| mobile-390 | Catalog images use contain fit | PASS | [] |
| mobile-390 | 1-column responsive catalog grid | PASS | columns=1 |
| mobile-390 | Catalog image areas have a consistent height | PASS | [250,250,250,250,250,250,250,250,250,250,250,250,250,250,250,250,250,250] |
| mobile-390 | Mobile catalog image areas stay compact | PASS | [250,250,250,250,250,250,250,250,250,250,250,250,250,250,250,250,250,250] |
| mobile-390 | Sticky header has an opaque background | PASS | rgb(255, 255, 255) |
| mobile-390 | Mobile quote action is a compact corner control | PASS | {"action":{"left":246,"right":378,"width":132,"height":46},"title":{"top":552,"bottom":576},"viewportWidth":390,"overlapsTitle":false,"bodyPaddingBottom":72} |
| mobile-390 | Mobile quote action does not cover the product title | PASS | {"action":{"left":246,"right":378,"width":132,"height":46},"title":{"top":552,"bottom":576},"viewportWidth":390,"overlapsTitle":false,"bodyPaddingBottom":72} |
| mobile-390 | Configuration selector works | PASS | {"secondPressed":"true","source":"assets/images/config-red-rgb.webp","title":"Red / black with color trim"} |
| mobile-390 | Six photo-to-3D mappings are declared | PASS | {"mappings":["0","1","4","5","2","3"],"optionValues":["0","1","2","3","4","5"],"selectedValue":"1","activeModelIndex":"1"} |
| mobile-390 | Photo selection synchronizes the pending 3D variant | PASS | {"mappings":["0","1","4","5","2","3"],"optionValues":["0","1","2","3","4","5"],"selectedValue":"1","activeModelIndex":"1"} |
| mobile-390 | Showroom carousel advances | PASS | 313 |
| mobile-390 | Enquiry link pre-fills product | PASS | 135° Reclining Gaming Chair |
| mobile-390 | Factory photograph viewer opens, closes and restores focus | PASS | {"opened":true,"closed":true,"focusRestored":true,"lightboxTitle":"CNC cutting for wood components","expectedTitle":"CNC cutting for wood components","lightboxSource":"http://127.0.0.1:43193/assets/images/factory-cnc-wood-components.webp"} |
| mobile-390 | Mobile menu opens and closes | PASS | opened=true, closed=true |
| mobile-390 | Mobile content renders without scroll-triggered reveal delays | PASS | {"root":true,"reveal":true,"transition":"none","duration":"0s"} |
| mobile-390 | No console errors | PASS |  |
| mobile-390 | No uncaught page errors | PASS |  |
| mobile-390 | No failed network requests | PASS |  |
| mobile-390 | No Shopify network requests | PASS |  |
| mobile-320 | Page responds successfully | PASS | 200 |
| mobile-320 | 18 product cards | PASS | 18 |
| mobile-320 | 6 real configurations | PASS | 6 |
| mobile-320 | 10 showroom visuals | PASS | 10 |
| mobile-320 | 4 verified factory photographs | PASS | 4 |
| mobile-320 | 2 accessible header social icons | PASS | ["Facebook","TikTok"] |
| mobile-320 | No visible 8011 | PASS | body.innerText |
| mobile-320 | No visible Shopify copy | PASS | body.innerText |
| mobile-320 | No Shopify runtime/source | PASS | HTML source |
| mobile-320 | All images load | PASS |  |
| mobile-320 | No horizontal page overflow | PASS | {"clientWidth":320,"rootScrollWidth":320,"bodyScrollWidth":320,"offenders":[{"selector":"div.quote-orb","left":120,"right":420}]} |
| mobile-320 | 18 normalized 720 × 720 catalog images | PASS | {"count":18,"bad":[]} |
| mobile-320 | Catalog images use contain fit | PASS | [] |
| mobile-320 | 1-column responsive catalog grid | PASS | columns=1 |
| mobile-320 | Catalog image areas have a consistent height | PASS | [232,232,232,232,232,232,232,232,232,232,232,232,232,232,232,232,232,232] |
| mobile-320 | Mobile catalog image areas stay compact | PASS | [232,232,232,232,232,232,232,232,232,232,232,232,232,232,232,232,232,232] |
| mobile-320 | Sticky header has an opaque background | PASS | rgb(255, 255, 255) |
| mobile-320 | Mobile quote action is a compact corner control | PASS | {"action":{"left":188,"right":308,"width":120,"height":44},"title":{"top":470,"bottom":518},"viewportWidth":320,"overlapsTitle":false,"bodyPaddingBottom":72} |
| mobile-320 | Mobile quote action does not cover the product title | PASS | {"action":{"left":188,"right":308,"width":120,"height":44},"title":{"top":470,"bottom":518},"viewportWidth":320,"overlapsTitle":false,"bodyPaddingBottom":72} |
| mobile-320 | Configuration selector works | PASS | {"secondPressed":"true","source":"assets/images/config-red-rgb.webp","title":"Red / black with color trim"} |
| mobile-320 | Six photo-to-3D mappings are declared | PASS | {"mappings":["0","1","4","5","2","3"],"optionValues":["0","1","2","3","4","5"],"selectedValue":"1","activeModelIndex":"1"} |
| mobile-320 | Photo selection synchronizes the pending 3D variant | PASS | {"mappings":["0","1","4","5","2","3"],"optionValues":["0","1","2","3","4","5"],"selectedValue":"1","activeModelIndex":"1"} |
| mobile-320 | Showroom carousel advances | PASS | 253 |
| mobile-320 | Enquiry link pre-fills product | PASS | 135° Reclining Gaming Chair |
| mobile-320 | Factory photograph viewer opens, closes and restores focus | PASS | {"opened":true,"closed":true,"focusRestored":true,"lightboxTitle":"CNC cutting for wood components","expectedTitle":"CNC cutting for wood components","lightboxSource":"http://127.0.0.1:43193/assets/images/factory-cnc-wood-components.webp"} |
| mobile-320 | Mobile menu opens and closes | PASS | opened=true, closed=true |
| mobile-320 | Mobile content renders without scroll-triggered reveal delays | PASS | {"root":true,"reveal":true,"transition":"none","duration":"0s"} |
| mobile-320 | No console errors | PASS |  |
| mobile-320 | No uncaught page errors | PASS |  |
| mobile-320 | No failed network requests | PASS |  |
| mobile-320 | No Shopify network requests | PASS |  |
| reduced-motion | Reduced motion preference honored | PASS | {"media":true,"opacity":"1","transform":"none","transitionDuration":"0s","animated":false} |
