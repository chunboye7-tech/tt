=== XIUJIN Store Core ===
Contributors: xiujin
Tags: woocommerce, wholesale, retail, quotation, product enquiry
Requires at least: 6.4
Requires PHP: 8.1
Requires Plugins: woocommerce
Stable tag: 1.3.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Keeps XIUJIN wholesale and retail product settings independent from the active theme and provides a secure quotation form.

== Description ==

XIUJIN Store Core adds sales mode, purchase path, minimum order quantity, lead time and internal configuration reference fields to WooCommerce products. The catalogue defaults to enquiry-only ordering for wholesale and retail, with cart and checkout disabled and no payment gateway required.

The `[xiujin_inquiry_form]` shortcode outputs an accessible, product-aware form protected by a nonce, honeypot, signed timing check, server-side validation and privacy-preserving rate limits. Valid enquiries are sent as plain-text email and are not stored in the WordPress database.

Optional Google Ads, Meta Pixel and TikTok Pixel integrations remain disabled until valid platform IDs are saved. Advertising and analytics scripts load only after visitor consent. A successfully accepted enquiry can emit one anonymous Lead event without form details or other personal data.

The consent controller governs tags loaded by this plugin. Site Kit, MonsterInsights, Google Tag Manager or another integration must be disabled or managed by the same consent platform if it loads duplicate tags before consent.

== Installation ==

1. Install and activate WooCommerce.
2. Upload and activate the XIUJIN Store Core ZIP.
3. Open Settings > XIUJIN enquiries and enter the sales recipient email.
4. Test email delivery before launch.
5. Leave online checkout disabled for an enquiry-only catalogue.
6. Edit each product, choose its sales mode, and keep its purchase path set to Quotation enquiry.
7. Optional: open Settings > XIUJIN tracking and enter only the advertising IDs you intend to use. Leave GA4 empty when another plugin already loads GA4.

== Changelog ==

= 1.3.2 =
* Keep Store Core runtime behavior unchanged while aligning the release package with the XIUJIN Furniture 1.3.2 theme.

= 1.3.1 =
* Keep Store Core runtime behavior unchanged while aligning the release package with the XIUJIN Furniture 1.3.1 theme.

= 1.3.0 =
* Replace the three illustrative factory scenes with user-supplied finished-goods warehouse footage and its verified poster image.
* Add an accessible, responsive factory video section with complete Spanish and Portuguese interface translations.

= 1.2.2 =
* Keep language switching on the corresponding translated page instead of forcing visitors back to the language home page.
* Give the Polylang language dropdown an accessible label.

= 1.2.1 =
* Restore automatic product-name prefilling when visitors open the homepage enquiry form from a chair card.

= 1.2.0 =
* Add consent-gated Google Ads, Meta Pixel and TikTok Pixel integrations.
* Count a successfully accepted quotation enquiry once with an anonymous conversion ID and no submitted personal data.
* Keep all advertising integrations disabled until an administrator saves valid platform IDs.
* Add tracking privacy guidance and Spanish and Portuguese (Brazil) interface translations.

= 1.1.0 =
* Harden enquiry input handling, redirects, email headers and privacy disclosures.
* Keep quotation links on the active Polylang or WPML language homepage.
* Default wholesale and retail products to quotation-only ordering with cart and checkout routes disabled.
* Add global and per-product opt-in gates for any future online checkout.
* Add complete Spanish and Portuguese (Brazil) translations.

= 1.0.0 =
* Initial release.

