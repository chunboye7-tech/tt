<?php
/**
 * Plugin Name:       XIUJIN Store Core
 * Description:       Adds wholesale and retail product settings plus a secure quotation form for the XIUJIN Furniture store.
 * Version:           1.2.2
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Requires Plugins:  woocommerce
 * Author:            XIUJIN Furniture
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       xiujin-store-core
 * Domain Path:       /languages
 *
 * @package XiujinStoreCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'XIUJIN_STORE_CORE_VERSION', '1.2.2' );
define( 'XIUJIN_STORE_CORE_FILE', __FILE__ );
define( 'XIUJIN_STORE_CORE_PATH', plugin_dir_path( __FILE__ ) );
define( 'XIUJIN_STORE_CORE_URL', plugin_dir_url( __FILE__ ) );

require_once XIUJIN_STORE_CORE_PATH . 'includes/class-xiujin-product-fields.php';
require_once XIUJIN_STORE_CORE_PATH . 'includes/class-xiujin-inquiry.php';
require_once XIUJIN_STORE_CORE_PATH . 'includes/class-xiujin-tracking.php';

/**
 * Return the active language's front-page URL when a supported multilingual
 * plugin is available.
 *
 * @return string
 */
function xiujin_store_home_url() {
	$url = home_url( '/' );

	if ( function_exists( 'pll_home_url' ) ) {
		$localized = pll_home_url();
		if ( is_string( $localized ) && '' !== $localized ) {
			$url = $localized;
		}
	} elseif ( has_filter( 'wpml_home_url' ) ) {
		$localized = apply_filters( 'wpml_home_url', $url );
		if ( is_string( $localized ) && '' !== $localized ) {
			$url = $localized;
		}
	}

	return esc_url_raw( $url );
}

/**
 * Load translations and register the plugin modules.
 */
function xiujin_store_core_boot() {
	load_plugin_textdomain(
		'xiujin-store-core',
		false,
		dirname( plugin_basename( XIUJIN_STORE_CORE_FILE ) ) . '/languages'
	);

	Xiujin_Product_Fields::register();
	Xiujin_Inquiry::register();
	Xiujin_Tracking::register();
}
add_action( 'init', 'xiujin_store_core_boot', 5 );

