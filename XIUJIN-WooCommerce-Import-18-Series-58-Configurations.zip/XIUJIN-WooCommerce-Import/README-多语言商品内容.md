# 商品内容：西班牙语和葡萄牙语

本目录中的两个 CSV 为 18 个英文草稿商品提供经过整理的翻译参考文案：

- `XIUJIN-product-copy-es_ES.csv`：西班牙语（西班牙）
- `XIUJIN-product-copy-pt_BR.csv`：葡萄牙语（巴西）

每行通过 `SKU`、`source_handle` 和 `source_row` 对应英文商品，包含本地化标题、短描述、完整 HTML 描述、SEO 标题、SEO 描述和标签。

## 使用方式

1. 先导入英文草稿商品。
2. 安装并设置 Polylang、WPML 或其他兼容 WooCommerce 的多语言插件。
3. 在多语言插件中为每个英文商品创建西班牙语和葡萄牙语版本，并建立翻译关系。
4. 按相同 SKU/来源行，从对应 CSV 复制本地化文案。
5. 发布前由母语人员复核品牌语气、市场用词和法规要求。

这些 CSV **不会自动建立翻译关系，也不应直接覆盖英文商品**。其中没有新增价格、材料、认证、库存或交期信息；商业资料仍需逐款确认。

`XIUJIN-product-translations-validation.json` 记录两个语言文件的行数、SKU 对应关系、HTML 结构和 SEO 长度检查结果。
