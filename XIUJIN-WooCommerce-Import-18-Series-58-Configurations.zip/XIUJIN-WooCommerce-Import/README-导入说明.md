# XIUJIN WooCommerce 商品导入包（草稿）

本目录由 `tools/build_woocommerce_import.py` 生成，包含 18 个产品系列和 58 张配置参考图。

## 导入顺序

1. 在 WordPress 后台打开 **媒体 → 添加新媒体文件**，先上传 `product-images/` 内的 58 张图片；请勿改名。
2. 打开 **商品 → 所有商品 → 导入**，选择 `XIUJIN-WooCommerce-products-DRAFT.csv`。
3. 检查 WooCommerce 自动匹配的字段；`Meta:` 开头的列应映射为自定义元数据。
4. 完成导入后，18 个商品均为草稿。逐个核对图片、文案、商品类别及 SEO，再补充经过确认的销售资料。

## 数据边界

- 价格、促销价、币种、税务状态和库存均为空。
- 58 个视觉配置是图片/询价参考，不是已经确认可售的 WooCommerce 变体。
- 发布前必须确认具体 SKU、颜色、材料、尺寸、MOQ、包装、交期、付款和运输条款。
- `XIUJIN-WooCommerce-58-configurations.csv` 记录每张图片与父商品、配置编号、原图及 SHA-256 的关系。
- SEO 元数据同时写入 Yoast SEO 与 Rank Math 常用字段；未安装对应插件时不会影响商品导入。

## 文件说明

- `XIUJIN-WooCommerce-products-DRAFT.csv`：WooCommerce 核心导入器使用的 18 个草稿产品。
- `XIUJIN-WooCommerce-58-configurations.csv`：58 个视觉配置的可审计映射。
- `product-images/`：保持原始文件内容和哈希的 58 张商品图片。
- `import-manifest.json`：输入文件、输出文件和计数摘要。
- `validation-report.json`：构建后的自动验证结果。
