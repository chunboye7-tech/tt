# XIUJIN WooCommerce 商品导入包（草稿）

本目录由 `tools/build_woocommerce_import.py` 生成，包含 18 个产品系列、58 个可追溯外观配置和源价目表内全部 118 张商品媒体。

## 导入顺序

1. 在 WordPress 后台打开 **媒体 → 添加新媒体文件**，先上传 `product-images/` 内的 118 张图片；请勿改名。
2. 打开 **商品 → 所有商品 → 导入**，选择 `XIUJIN-WooCommerce-products-DRAFT.csv`。
3. 检查 WooCommerce 自动匹配的字段；`Meta:` 开头的列应映射为自定义元数据。
4. 参照 `XIUJIN-WooCommerce-media-library.csv` 为媒体库图片填写 ALT 文本；该映射不会被 WooCommerce 商品 CSV 自动写入媒体附件。
5. 完成导入后，18 个商品均为草稿。逐个核对图片、文案、商品类别及 SEO，再补充经过确认的销售资料。

## 数据边界

- 价格、促销价、币种、税务状态和库存均为空。
- 58 个视觉配置是图片/询价参考，不是已经确认可售的 WooCommerce 变体。
- WooCommerce 在本项目中用于管理目录和商品媒体；所有商品均设置为批发和零售询价，线上结账方式为 `enquiry`，不启用在线付款。
- `_xiujin_moq` 与 `_xiujin_lead_time` 保持为空，确认工厂商业资料后再填写。
- 发布前必须确认具体 SKU、颜色、材料、尺寸、MOQ、包装、交期、付款和运输条款。
- `XIUJIN-WooCommerce-58-configurations.csv` 记录每张图片与父商品、配置编号、原图及 SHA-256 的关系。
- `XIUJIN-WooCommerce-media-library.csv` 记录全部媒体的顺序、用途、ALT 文本、原始/输出尺寸、原始/输出 SHA-256 及旋转修正。
- SEO 元数据同时写入 Yoast SEO 与 Rank Math 常用字段；未安装对应插件时不会影响商品导入。

## 文件说明

- `XIUJIN-WooCommerce-products-DRAFT.csv`：WooCommerce 核心导入器使用的 18 个草稿产品。
- `XIUJIN-WooCommerce-58-configurations.csv`：58 个视觉配置的可审计映射。
- `XIUJIN-WooCommerce-media-library.csv`：全部 118 张商品媒体及可审计来源/ALT 映射。
- `product-images/`：118 张商品图片；两张横置的 8021 图片已生成顺时针旋转 90° 的展示副本，并保留源文件哈希。
- `import-manifest.json`：输入文件、输出文件和计数摘要。
- `validation-report.json`：构建后的自动验证结果。
