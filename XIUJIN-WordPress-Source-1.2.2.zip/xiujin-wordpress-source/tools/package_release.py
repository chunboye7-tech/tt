#!/usr/bin/env python3
"""Create deterministic, upload-ready XIUJIN WordPress release archives."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import stat
import tempfile
import zipfile
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parents[1]
DELIVERY = ROOT / "delivery"
THEME = ROOT / "theme" / "xiujin-furniture"
PLUGIN = ROOT / "plugin" / "xiujin-store-core"
IMPORT = ROOT / "dist" / "woocommerce-import"
PREVIEW = ROOT / "preview"
REPORTS = ROOT / "tests" / "artifacts"
VERSION = "1.2.2"
ZIP_TIME = (2026, 10, 27, 0, 0, 0)

SOURCE_ROOT_NAME = "xiujin-wordpress-source"


def wanted(path: Path) -> bool:
    return not any(part in {"__pycache__", ".DS_Store", ".git"} for part in path.parts)


def release_names() -> dict[str, str]:
    """Return the canonical filenames used throughout the release."""

    return {
        "theme": f"XIUJIN-WordPress-Theme-{VERSION}.zip",
        "plugin": f"XIUJIN-Store-Core-{VERSION}.zip",
        "import": "XIUJIN-WooCommerce-Import-18-Series-58-Configurations.zip",
        "preview": "XIUJIN-WordPress-Preview.zip",
        "source": f"XIUJIN-WordPress-Source-{VERSION}.zip",
        "complete": f"XIUJIN-WordPress-Complete-{VERSION}.zip",
    }


def declared_versions() -> dict[str, str]:
    """Read the versions users will see in WordPress package metadata."""

    theme_text = (THEME / "style.css").read_text(encoding="utf-8")
    plugin_text = (PLUGIN / "xiujin-store-core.php").read_text(encoding="utf-8")
    functions_text = (THEME / "functions.php").read_text(encoding="utf-8")
    readme_text = (PLUGIN / "readme.txt").read_text(encoding="utf-8")
    patterns = {
        "theme": (theme_text, r"(?mi)^Version:\s*([^\s]+)\s*$"),
        "plugin": (plugin_text, r"(?mi)^\s*\*\s*Version:\s*([^\s]+)\s*$"),
        "plugin_readme": (readme_text, r"(?mi)^Stable tag:\s*([^\s]+)\s*$"),
        "theme_constant": (functions_text, r"define\(\s*'XIUJIN_THEME_VERSION'\s*,\s*'([^']+)'\s*\)"),
        "plugin_constant": (plugin_text, r"define\(\s*'XIUJIN_STORE_CORE_VERSION'\s*,\s*'([^']+)'\s*\)"),
    }
    versions: dict[str, str] = {}
    for label, (text, pattern) in patterns.items():
        match = re.search(pattern, text)
        if not match:
            raise ValueError(f"Missing {label} version metadata")
        versions[label] = match.group(1)
    return versions


def assert_version_alignment() -> None:
    versions = declared_versions()
    mismatched = {label: value for label, value in versions.items() if value != VERSION}
    if mismatched:
        detail = ", ".join(f"{label}={value}" for label, value in sorted(mismatched.items()))
        raise ValueError(f"Release version {VERSION} does not match package metadata: {detail}")


def rendered_install_guide() -> str:
    """Render package filenames in the hand-written Hostinger guide."""

    names = release_names()
    text = (ROOT / "docs" / "HOSTINGER-INSTALL-中文.md").read_text(encoding="utf-8")
    text = re.sub(r"XIUJIN-WordPress-Theme-[0-9A-Za-z_.-]+\.zip", names["theme"], text)
    text = re.sub(r"XIUJIN-Store-Core-[0-9A-Za-z_.-]+\.zip", names["plugin"], text)
    return text


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def add_file(archive: zipfile.ZipFile, source: Path, name: str) -> None:
    pure = PurePosixPath(name)
    if pure.is_absolute() or ".." in pure.parts or "\\" in name:
        raise ValueError(f"Unsafe archive path: {name}")
    info = zipfile.ZipInfo(pure.as_posix(), ZIP_TIME)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    archive.writestr(
        info,
        source.read_bytes(),
        compress_type=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    )


def zip_directory(source: Path, destination: Path, root_name: str) -> None:
    with zipfile.ZipFile(destination, "w", allowZip64=True) as archive:
        for path in sorted(source.rglob("*")):
            relative = path.relative_to(source)
            if path.is_symlink():
                raise ValueError(f"Symlinks are not permitted in release sources: {relative}")
            if path.is_file() and wanted(relative):
                add_file(archive, path, f"{root_name}/{relative.as_posix()}")


def source_bundle_files() -> dict[str, Path]:
    """Return the exact developer/source snapshot shipped with the release."""

    files: dict[str, Path] = {}
    directories = {
        "theme": ROOT / "theme",
        "plugin": ROOT / "plugin",
        "dist": ROOT / "dist",
        "preview": PREVIEW,
        "inputs": ROOT / "inputs",
        "tools": ROOT / "tools",
        "docs": ROOT / "docs",
    }
    for prefix, directory in directories.items():
        for path in sorted(directory.rglob("*")):
            relative = path.relative_to(directory)
            if path.is_symlink():
                raise ValueError(f"Symlinks are not permitted in release sources: {path.relative_to(ROOT)}")
            if path.is_file() and wanted(relative):
                files[f"{SOURCE_ROOT_NAME}/{prefix}/{relative.as_posix()}"] = path

    standalone = (
        ROOT / "Makefile",
        ROOT / "package.json",
        ROOT / "package-lock.json",
        ROOT / "requirements-dev.txt",
        ROOT / "tests" / "README.md",
        ROOT / "tests" / "static-preview.test.js",
        ROOT / "tests" / "tracking-client.test.js",
    )
    for path in standalone:
        if not path.is_file():
            raise FileNotFoundError(path)
        files[f"{SOURCE_ROOT_NAME}/{path.relative_to(ROOT).as_posix()}"] = path
    return files


def zip_source_bundle(destination: Path) -> None:
    with zipfile.ZipFile(destination, "w", allowZip64=True) as archive:
        for name, source in sorted(source_bundle_files().items()):
            add_file(archive, source, name)


def verify_zip(path: Path) -> None:
    with zipfile.ZipFile(path) as archive:
        corrupt = archive.testzip()
        if corrupt:
            raise ValueError(f"CRC failure in {path.name}: {corrupt}")
        names: set[str] = set()
        for info in archive.infolist():
            name = info.filename
            pure = PurePosixPath(name)
            mode = info.external_attr >> 16
            if (
                pure.is_absolute()
                or ".." in pure.parts
                or "\\" in name
                or "\0" in name
                or stat.S_ISLNK(mode)
            ):
                raise ValueError(f"Unsafe ZIP member in {path.name}: {name}")
            if name in names:
                raise ValueError(f"Duplicate ZIP member in {path.name}: {name}")
            names.add(name)


def validation_evidence() -> dict:
    paths = {
        "theme": REPORTS / "theme-validation.json",
        "browser": REPORTS / "browser-validation.json",
        "browser_markdown": REPORTS / "browser-validation.md",
        "tracking": REPORTS / "tracking-validation.json",
        "i18n": REPORTS / "i18n-validation.json",
        "php_ast": REPORTS / "php-ast-validation.json",
        "plugin": PLUGIN / "validation-report.json",
        "catalog": IMPORT / "validation-report.json",
        "product_translations": IMPORT / "XIUJIN-product-translations-validation.json",
    }
    translation_outputs = [
        IMPORT / "XIUJIN-product-copy-es_ES.csv",
        IMPORT / "XIUJIN-product-copy-pt_BR.csv",
    ]
    missing = [
        str(path.relative_to(ROOT))
        for path in [*paths.values(), *translation_outputs]
        if not path.is_file()
    ]
    if missing:
        raise FileNotFoundError("Missing validation evidence: " + ", ".join(missing))

    evidence = {name: load_json(path) for name, path in paths.items() if path.suffix == ".json"}
    failures = []
    if evidence["theme"].get("summary", {}).get("FAIL") != 0:
        failures.append("theme")
    if evidence["browser"].get("failed") != 0:
        failures.append("browser")
    if (
        evidence["tracking"].get("failed") != 0
        or evidence["tracking"].get("passed") != evidence["tracking"].get("checks")
    ):
        failures.append("tracking")
    if evidence["plugin"].get("summary", {}).get("failed") != 0:
        failures.append("plugin")
    if evidence["i18n"].get("status") != "passed":
        failures.append("i18n")
    if evidence["php_ast"].get("summary", {}).get("failed") != 0:
        failures.append("php_ast")
    if evidence["catalog"].get("status") != "pass":
        failures.append("catalog")
    translation_locales = evidence["product_translations"].get("locales", [])
    if (
        evidence["product_translations"].get("status") != "pass"
        or evidence["product_translations"].get("source_product_count") != 18
        or len(translation_locales) != 2
        or any(locale.get("rows") != 18 for locale in translation_locales)
    ):
        failures.append("product_translations")
    if failures:
        raise ValueError("Failed validation evidence: " + ", ".join(failures))

    freshness_groups = {
        "theme": (
            paths["theme"],
            [path for path in THEME.rglob("*") if path.is_file()]
            + [path for path in (ROOT / "inputs" / "chair-trade-studio" / "xiujin-b2b-theme" / "assets").rglob("*") if path.is_file()]
            + [ROOT / "inputs" / "chair-trade-studio" / "uploaded-home-images" / "main-9.png"]
            + [path for path in (ROOT / "inputs" / "catalog-review").iterdir() if path.is_file()]
            + [
                ROOT / "tools" / "build_theme_assets.py",
                ROOT / "tools" / "validate_wordpress_theme.py",
            ],
        ),
        "browser": (
            paths["browser"],
            [path for path in PREVIEW.rglob("*") if path.is_file()]
            + [ROOT / "tests" / "static-preview.test.js"],
        ),
        "tracking": (
            paths["tracking"],
            [
                PLUGIN / "assets" / "js" / "tracking.js",
                ROOT / "tests" / "tracking-client.test.js",
            ],
        ),
        "plugin": (
            paths["plugin"],
            [path for path in PLUGIN.rglob("*") if path.is_file() and path != paths["plugin"]]
            + [ROOT / "tools" / "validate_store_core.py"],
        ),
        "i18n": (
            paths["i18n"],
            [path for path in (THEME / "languages").rglob("*") if path.is_file()]
            + [path for path in (PLUGIN / "languages").rglob("*") if path.is_file()]
            + [
                ROOT / "tools" / "build_i18n_catalogs.py",
                ROOT / "tools" / "validate_i18n.py",
                ROOT / "tools" / "i18n_copy.json",
                ROOT / "tools" / "theme_gettext_es.json",
                ROOT / "tools" / "theme_gettext_pt_BR.json",
                ROOT / "tools" / "plugin_gettext_es_ES.json",
                ROOT / "tools" / "plugin_gettext_pt_BR.json",
            ],
        ),
        "php_ast": (
            paths["php_ast"],
            list(THEME.rglob("*.php"))
            + list(PLUGIN.rglob("*.php"))
            + [ROOT / "tools" / "validate_php_ast.js"],
        ),
        "catalog": (
            paths["catalog"],
            [
                IMPORT / "XIUJIN-WooCommerce-products-DRAFT.csv",
                IMPORT / "XIUJIN-WooCommerce-58-configurations.csv",
                IMPORT / "XIUJIN-WooCommerce-media-library.csv",
                IMPORT / "import-manifest.json",
                IMPORT / "README-导入说明.md",
            ]
            + [path for path in (IMPORT / "product-images").rglob("*") if path.is_file()]
            + [path for path in (ROOT / "inputs" / "catalog-review").iterdir() if path.is_file()]
            + [
                ROOT / "inputs" / "chair-trade-studio" / "catalog_copy.json",
                ROOT / "inputs" / "chair-trade-studio" / "delivery" / "XIUJIN-58-visual-configurations.csv",
                ROOT / "inputs" / "chair-trade-studio" / "delivery" / "XIUJIN-58-product-images.zip",
                ROOT / "tools" / "build_woocommerce_import.py",
            ],
        ),
        "product_translations": (
            paths["product_translations"],
            translation_outputs
            + [
                IMPORT / "XIUJIN-WooCommerce-products-DRAFT.csv",
                IMPORT / "README-多语言商品内容.md",
                ROOT / "tools" / "build_product_translations.py",
                ROOT / "inputs" / "chair-trade-studio" / "catalog_copy.json",
            ],
        ),
    }
    stale = []
    for label, (report, inputs) in freshness_groups.items():
        if inputs and report.stat().st_mtime + 0.01 < max(path.stat().st_mtime for path in inputs):
            stale.append(label)
    if stale:
        raise ValueError("Validation evidence is older than its source: " + ", ".join(stale))
    return evidence


def build_release(output: Path, evidence: dict | None = None) -> list[Path]:
    evidence = evidence or validation_evidence()
    assert_version_alignment()
    output.mkdir(parents=True, exist_ok=True)

    names = release_names()
    theme_zip = output / names["theme"]
    plugin_zip = output / names["plugin"]
    import_zip = output / names["import"]
    preview_zip = output / names["preview"]
    source_zip = output / names["source"]
    zip_directory(THEME, theme_zip, "xiujin-furniture")
    zip_directory(PLUGIN, plugin_zip, "xiujin-store-core")
    zip_directory(IMPORT, import_zip, "XIUJIN-WooCommerce-Import")
    zip_directory(PREVIEW, preview_zip, "XIUJIN-WordPress-Preview")
    zip_source_bundle(source_zip)

    catalog_checks = evidence["catalog"]["checks"]
    product_count = catalog_checks["product_count"]
    configuration_count = catalog_checks["configuration_count"]
    image_count = catalog_checks["image_count"]
    if (product_count, configuration_count) != (18, 58):
        raise ValueError(
            "The catalog archive filename declares 18 series and 58 configurations, "
            f"but validation reports {product_count} series and {configuration_count} configurations"
        )

    notes = output / "RELEASE-NOTES-中文.md"
    notes.write_text(
        f"# XIUJIN WordPress 网站 {VERSION}\n\n"
        "本次交付为 WordPress + WooCommerce 网站源码和安全导入数据。\n\n"
        "- WordPress 主题：完整主页、商品/归档模板、响应式布局、按需 3D、动态效果、SEO 基础和社媒入口。\n"
        "- Store Core 插件：批发与零售询价模式、MOQ、交期、配置编号和安全询价表单。\n"
        "- 询价修复：首页商品卡进入询价区时，会自动带入当前语言的商品名称。\n"
        "- 语言切换：产品页、政策页等会进入对应翻译页，不再强制返回该语言首页。\n"
        "- 广告衡量：可选的 Google Ads、Meta Pixel 和 TikTok Pixel；访客同意后才加载，成功提交的询价仅计为一次匿名 Lead。\n"
        "- 交易方式：WooCommerce 仅用于商品与目录管理；购物车、结账和在线支付保持关闭，不安装支付网关。\n"
        "- 多语言：主题和插件固定界面已提供英语、西班牙语、葡萄牙语（巴西）；商品内容需在 WordPress 中建立对应翻译。\n"
        f"- 商品包：{product_count} 个草稿商品系列、{configuration_count} 个已核对视觉配置、{image_count} 张目录媒体；价格、币种、税务和库存保持空白。\n"
        "- 预览包：可离线查看完整主页设计；预览中的询价表单不会发送。\n\n"
        "公开文案已移除 8011 编号；内部 SKU/来源字段保留编号用于目录追溯。\n"
        "工厂场景图为设计示意，网页已明确披露；获得真实工厂照片后，需替换主题素材并重新上传主题。\n",
        encoding="utf-8",
    )

    start_here = output / "START-HERE-中文.md"
    start_here.write_text(
        "# 先从这里开始\n\n"
        f"`{names['complete']}` 是交付合集，不能直接在 WordPress 的“上传主题”页面安装。\n\n"
        "完整操作步骤请先阅读 `HOSTINGER-INSTALL-中文.md`。\n\n"
        "1. 先在电脑中解压完整交付包。\n"
        f"2. WordPress 后台进入 **外观 → 主题 → 安装主题 → 上传主题**，上传 `{names['theme']}`。\n"
        f"3. 进入 **插件 → 安装插件**，先安装 WooCommerce 作为商品管理工具，再上传 `{names['plugin']}`；不要安装支付网关。\n"
        "4. 商品图片和草稿商品按照商品导入包内 `README-导入说明.md` 的顺序导入。\n"
        "5. 网站采用批发与零售询价，不启用购物车、结账或在线支付。\n"
        "6. 如需广告衡量，进入 **设置 → XIUJIN tracking** 填写平台 ID；未取得正式 ID 时保持空白。\n"
        "7. 正式发布前逐款确认价格、币种、税务、库存、SKU、MOQ、颜色、材料和交期。\n",
        encoding="utf-8",
    )

    install_guide = output / "HOSTINGER-INSTALL-中文.md"
    install_guide.write_text(rendered_install_guide(), encoding="utf-8")

    components = [theme_zip, plugin_zip, import_zip, preview_zip, source_zip]
    checksums = output / "SHA256SUMS.txt"
    checksums.write_text(
        "".join(f"{sha256(path)}  {path.name}\n" for path in components),
        encoding="utf-8",
    )

    complete = output / names["complete"]
    report_files = {
        "theme-validation.json": REPORTS / "theme-validation.json",
        "browser-validation.json": REPORTS / "browser-validation.json",
        "browser-validation.md": REPORTS / "browser-validation.md",
        "tracking-validation.json": REPORTS / "tracking-validation.json",
        "i18n-validation.json": REPORTS / "i18n-validation.json",
        "php-ast-validation.json": REPORTS / "php-ast-validation.json",
        "plugin-validation.json": PLUGIN / "validation-report.json",
        "catalog-validation.json": IMPORT / "validation-report.json",
        "product-translations-validation.json": IMPORT / "XIUJIN-product-translations-validation.json",
    }
    with zipfile.ZipFile(complete, "w", allowZip64=True) as archive:
        for path in (*components, start_here, install_guide, notes, checksums):
            add_file(archive, path, path.name)
        for name, report in report_files.items():
            add_file(archive, report, f"validation/{name}")

    theme_summary = evidence["theme"]["summary"]
    browser_summary = evidence["browser"]
    tracking_summary = evidence["tracking"]
    plugin_summary = evidence["plugin"]["summary"]
    i18n_summary = evidence["i18n"]
    ast_summary = evidence["php_ast"]["summary"]
    translation_summary = evidence["product_translations"]
    manifest = {
        "version": VERSION,
        "files": {
            path.name: {"bytes": path.stat().st_size, "sha256": sha256(path)}
            for path in (*components, complete)
        },
        "verified_counts": {
            "product_series": catalog_checks["product_count"],
            "visual_configurations": catalog_checks["configuration_count"],
            "product_images": catalog_checks["image_count"],
            "theme_validation_passed": theme_summary["PASS"],
            "theme_validation_warnings": theme_summary["WARN"],
            "browser_validation_passed": browser_summary["passed"],
            "tracking_validation_passed": tracking_summary["passed"],
            "plugin_validation_passed": plugin_summary["passed"],
            "i18n_validation_passed": i18n_summary["checks_passed"],
            "php_ast_files_parsed": ast_summary["passed"],
            "product_translation_locales": len(translation_summary["locales"]),
            "translated_product_copy_rows": sum(
                locale["rows"] for locale in translation_summary["locales"]
            ),
        },
    }
    (output / "release-manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    artifacts = [*components, complete]
    for artifact in artifacts:
        verify_zip(artifact)
    return artifacts


def main() -> None:
    for required in (THEME, PLUGIN, IMPORT, PREVIEW):
        if not required.is_dir():
            raise FileNotFoundError(required)
    evidence = validation_evidence()
    DELIVERY.parent.mkdir(parents=True, exist_ok=True)

    stage = Path(tempfile.mkdtemp(prefix=".xiujin-release-", dir=DELIVERY.parent))
    backup = DELIVERY.with_name(f".{DELIVERY.name}-previous")
    try:
        artifacts = build_release(stage, evidence)
        if backup.exists():
            if DELIVERY.exists():
                shutil.rmtree(backup)
            else:
                os.replace(backup, DELIVERY)
        if DELIVERY.exists():
            os.replace(DELIVERY, backup)
        try:
            os.replace(stage, DELIVERY)
        except Exception:
            if backup.exists() and not DELIVERY.exists():
                os.replace(backup, DELIVERY)
            raise
        if backup.exists():
            shutil.rmtree(backup)
    finally:
        if stage.exists():
            shutil.rmtree(stage)

    print(f"Built {len(artifacts)} verified release archives in {DELIVERY}")
    for path in sorted(DELIVERY.glob("*.zip")):
        print(f"{path.name}: {path.stat().st_size} bytes · {sha256(path)}")


if __name__ == "__main__":
    main()
