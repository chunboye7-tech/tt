<?php
/**
 * Actual finished-goods warehouse footage supplied by XIUJIN.
 *
 * @package Xiujin
 */
$warehouse_video  = xiujin_theme_file( 'video/factory-warehouse.mp4' );
$warehouse_poster = xiujin_theme_asset( 'factory-warehouse-poster.webp' );
$warehouse_points = array(
	__( 'Finished-goods storage', 'xiujin' ),
	__( 'Cartonized inventory', 'xiujin' ),
	__( 'Dispatch preparation', 'xiujin' ),
);
?>
<section id="factory" class="section factory-section">
	<div class="factory-grid-pattern" aria-hidden="true"></div>
	<div class="page-width">
		<?php xiujin_section_heading( __( 'Actual facility footage', 'xiujin' ), __( 'Inside the finished-goods warehouse.', 'xiujin' ), __( 'See packed inventory arranged for storage, order consolidation and dispatch preparation.', 'xiujin' ) ); ?>
		<div class="factory-media-layout">
			<figure class="factory-video-card" data-reveal>
				<div class="factory-video-shell">
					<video controls muted playsinline preload="none" poster="<?php echo esc_url( $warehouse_poster ); ?>" aria-label="<?php esc_attr_e( 'Video tour of the XIUJIN finished-goods warehouse', 'xiujin' ); ?>">
						<source src="<?php echo esc_url( $warehouse_video ); ?>" type="video/mp4">
						<a href="<?php echo esc_url( $warehouse_video ); ?>"><?php esc_html_e( 'Open the warehouse video', 'xiujin' ); ?></a>
					</video>
					<span class="factory-video-badge"><?php esc_html_e( 'Real warehouse video', 'xiujin' ); ?></span>
				</div>
				<figcaption><?php esc_html_e( 'Filmed in the XIUJIN finished-goods warehouse. The video has no audio and plays only when selected.', 'xiujin' ); ?></figcaption>
			</figure>
			<div class="factory-copy-card" data-reveal>
				<span class="eyebrow"><?php esc_html_e( 'Warehouse and dispatch', 'xiujin' ); ?></span>
				<h3><?php esc_html_e( 'Packed inventory prepared for dispatch', 'xiujin' ); ?></h3>
				<p><?php esc_html_e( 'This footage shows the actual XIUJIN finished-goods warehouse. Cartons are organized before quantities, destination, packaging and dispatch timing are confirmed for each order.', 'xiujin' ); ?></p>
				<ol class="factory-points">
					<?php foreach ( $warehouse_points as $index => $point ) : ?>
						<li><span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span><?php echo esc_html( $point ); ?></li>
					<?php endforeach; ?>
				</ol>
			</div>
		</div>
	</div>
</section>

