#!/usr/bin/env python3
"""Independent release checks for the XIUJIN WordPress/WooCommerce theme.

The validator is deliberately read-only.  It can be used before WordPress is
installed (static checks) and, with ``--url``, against a rendered preview or a
local WordPress site (browser checks).

Examples:
    python tools/validate_wordpress_theme.py
    python tools/validate_wordpress_theme.py xiujin-woocommerce
    python tools/validate_wordpress_theme.py --url http://127.0.0.1:8080
    python tools/validate_wordpress_theme.py --json validation-report.json
"""

from __future__ import annotations

import argparse
import csv
import functools
import hashlib
import http.server
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence
from urllib.parse import quote, unquote, urlparse


PROJECT_ROOT = Path(__file__).resolve().parents[1]
EXPECTED_SERIES = 18
EXPECTED_CONFIGURATIONS = 58
CONFIGURATION_ID_RE = re.compile(r"S\d{2}-R\d{3}-V\d{2}", re.I)
EXPECTED_CONFIGURATION_DISTRIBUTION = (6, 5, 2, 6, 6, 6, 1, 5, 6, 3, 2, 2, 1, 1, 1, 1, 1, 3)
EXPECTED_PRIMARY_MEDIA = {
    "S01-R002-V01": ("1_image2.png", "config-black-ivory", ("black", "ivory")),
    "S01-R002-V02": ("0_image1.png", "config-red-rgb", ("red", "black", "color trim")),
    "S01-R002-V03": ("3_image4.png", "config-blue-piping", ("blue", "white", "black")),
    "S01-R002-V04": ("4_image5.png", "config-yellow-black", ("yellow", "black")),
    "S01-R002-V05": ("5_image6.png", "config-red-bow", ("red", "black", "shaped cushion")),
    "S01-R002-V06": ("6_image7.png", "config-orange-fabric", ("orange", "black", "fabric")),
}

EXPECTED_3D_MAPPINGS = (
    ("black-ivory", 0, "black-white"),
    ("red-rgb", 1, "red-black-color-trim"),
    ("blue-piping", 4, "blue-white"),
    ("yellow-black", 5, "yellow-black"),
    ("red-bow", 2, "red-black"),
    ("orange-fabric", 3, "orange-black"),
)


TEXT_SUFFIXES = {
    ".php",
    ".css",
    ".js",
    ".json",
    ".html",
    ".htm",
    ".txt",
    ".md",
    ".pot",
    ".po",
    ".csv",
    ".xml",
    ".svg",
}
IGNORED_PARTS = {
    ".git",
    ".svn",
    "node_modules",
    "vendor",
    "dist",
    "build",
    "__pycache__",
}


@dataclass(frozen=True)
class Finding:
    status: str
    code: str
    message: str
    details: str = ""


class Report:
    def __init__(self) -> None:
        self.findings: list[Finding] = []

    def add(self, status: str, code: str, message: str, details: str = "") -> None:
        self.findings.append(Finding(status, code, message, details))

    def passed(self, code: str, message: str, details: str = "") -> None:
        self.add("PASS", code, message, details)

    def warn(self, code: str, message: str, details: str = "") -> None:
        self.add("WARN", code, message, details)

    def fail(self, code: str, message: str, details: str = "") -> None:
        self.add("FAIL", code, message, details)

    def counts(self) -> dict[str, int]:
        return {
            status: sum(item.status == status for item in self.findings)
            for status in ("PASS", "WARN", "FAIL")
        }

    def write_console(self) -> None:
        for item in self.findings:
            print(f"[{item.status:4}] {item.code}: {item.message}")
            if item.details:
                for line in item.details.splitlines():
                    print(f"       {line}")
        counts = self.counts()
        print(
            "\nValidation summary: "
            f"{counts['PASS']} passed, {counts['WARN']} warnings, "
            f"{counts['FAIL']} failed"
        )

    def to_json(self, theme_root: Path | None, browser_url: str | None) -> dict[str, Any]:
        # Keep release evidence portable and avoid leaking the build workspace.
        project_token = str(PROJECT_ROOT)

        def portable(value: str) -> str:
            return value.replace("file://" + project_token, ".").replace(project_token, ".")

        theme_label = None
        if theme_root:
            try:
                theme_label = theme_root.resolve().relative_to(PROJECT_ROOT.resolve()).as_posix()
            except ValueError:
                theme_label = theme_root.name
        return {
            "theme_root": theme_label,
            "browser_url": portable(browser_url) if browser_url else None,
            "summary": self.counts(),
            "findings": [
                {**asdict(item), "details": portable(item.details)}
                for item in self.findings
            ],
        }


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="utf-8", errors="replace")


def iter_files(root: Path, suffixes: set[str] | None = None) -> Iterable[Path]:
    if not root.exists():
        return
    for path in sorted(root.rglob("*")):
        if not path.is_file() or any(part in IGNORED_PARTS for part in path.parts):
            continue
        if suffixes is None or path.suffix.lower() in suffixes:
            yield path


def combined_text(files: Sequence[Path]) -> str:
    return "\n".join(read_text(path) for path in files)


def relative_list(root: Path, paths: Iterable[Path]) -> str:
    return ", ".join(str(path.relative_to(root)) for path in paths)


def discover_theme(explicit: str | None) -> Path | None:
    if explicit:
        candidate = Path(explicit).expanduser().resolve()
        return candidate if candidate.is_dir() else None

    preferred = (
        PROJECT_ROOT / "xiujin-woocommerce",
        PROJECT_ROOT / "xiujin-furniture",
        PROJECT_ROOT / "theme",
        PROJECT_ROOT / "wordpress-theme",
    )
    for candidate in preferred:
        if (candidate / "style.css").is_file() and (candidate / "functions.php").is_file():
            return candidate.resolve()

    for style in PROJECT_ROOT.rglob("style.css"):
        if any(part in IGNORED_PARTS or part == "tools" for part in style.parts):
            continue
        header = read_text(style)[:5000]
        if re.search(r"(?mi)^\s*Theme Name\s*:", header):
            return style.parent.resolve()
    return None


def extract_style_header(style_text: str) -> dict[str, str]:
    fields = (
        "Theme Name",
        "Theme URI",
        "Author",
        "Description",
        "Version",
        "Requires at least",
        "Requires PHP",
        "Text Domain",
        "License",
    )
    output: dict[str, str] = {}
    for field in fields:
        match = re.search(rf"(?mi)^\s*{re.escape(field)}\s*:\s*(.+?)\s*$", style_text[:8000])
        if match:
            output[field] = match.group(1).strip(" */\t")
    return output


def check_theme_files(theme: Path, report: Report) -> str:
    core = ("style.css", "index.php", "functions.php", "header.php", "footer.php")
    production = (
        "front-page.php",
        "page.php",
        "single.php",
        "archive.php",
        "search.php",
        "404.php",
        "theme.json",
    )
    missing_core = [name for name in core if not (theme / name).is_file()]
    missing_production = [name for name in production if not (theme / name).is_file()]
    if missing_core:
        report.fail("files.core", "Required theme files are missing", ", ".join(missing_core))
    else:
        report.passed("files.core", "Core WordPress theme files are present")
    if missing_production:
        report.fail(
            "files.templates",
            "Production templates or theme.json are missing",
            ", ".join(missing_production),
        )
    else:
        report.passed("files.templates", "Page, archive, search and error templates are present")

    screenshots = [theme / "screenshot.png", theme / "screenshot.jpg"]
    screenshot = next((path for path in screenshots if path.is_file()), None)
    if screenshot:
        try:
            from PIL import Image

            with Image.open(screenshot) as image:
                width, height = image.size
            if width >= 1200 and height >= 900:
                report.passed("files.screenshot", f"Theme screenshot is present ({width}×{height})")
            else:
                report.warn(
                    "files.screenshot",
                    "Theme screenshot is smaller than the recommended 1200×900",
                    f"{width}×{height}",
                )
        except (ImportError, OSError):
            report.passed("files.screenshot", "Theme screenshot is present")
    else:
        report.warn("files.screenshot", "Theme screenshot is missing")

    if not (theme / "languages").is_dir():
        report.fail("files.languages", "languages/ directory is missing")
    if not (theme / "assets").is_dir():
        report.fail("files.assets", "assets/ directory is missing")

    style_path = theme / "style.css"
    if not style_path.is_file():
        return ""
    header = extract_style_header(read_text(style_path))
    required_headers = ("Theme Name", "Version", "Text Domain", "Requires PHP")
    missing = [field for field in required_headers if not header.get(field)]
    if missing:
        report.fail("style.header", "style.css has an incomplete WordPress header", ", ".join(missing))
    else:
        report.passed("style.header", "style.css WordPress header is complete")
    domain = header.get("Text Domain", "").strip()
    if re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", domain):
        report.passed("style.text_domain", f"Text domain is a valid slug: {domain}")
    else:
        report.fail(
            "style.text_domain",
            "Text domain must be a non-empty lowercase slug",
            f"Found: {domain or '(missing)'}",
        )
    return domain


def check_php_structure(theme: Path, report: Report, php_files: Sequence[Path], all_php: str) -> None:
    header = read_text(theme / "header.php") if (theme / "header.php").exists() else ""
    footer = read_text(theme / "footer.php") if (theme / "footer.php").exists() else ""
    requirements = {
        "language_attributes()": r"\blanguage_attributes\s*\(",
        "bloginfo('charset')": r"bloginfo\s*\(\s*['\"]charset['\"]",
        "viewport meta": r"<meta[^>]+name\s*=\s*['\"]viewport['\"]",
        "body_class()": r"\bbody_class\s*\(",
        "wp_body_open()": r"\bwp_body_open\s*\(",
        "wp_head()": r"\bwp_head\s*\(",
    }
    missing = [name for name, pattern in requirements.items() if not re.search(pattern, header, re.I)]
    if missing:
        report.fail("php.header_api", "header.php misses WordPress integration calls", ", ".join(missing))
    else:
        report.passed("php.header_api", "Header uses the required WordPress document APIs")
    if re.search(r"\bwp_footer\s*\(", footer):
        report.passed("php.footer_api", "footer.php calls wp_footer()")
    else:
        report.fail("php.footer_api", "footer.php must call wp_footer()")

    setup_checks = {
        "after_setup_theme": r"add_action\s*\(\s*['\"]after_setup_theme['\"]",
        "wp_enqueue_scripts": r"add_action\s*\(\s*['\"]wp_enqueue_scripts['\"]",
        "title-tag": r"add_theme_support\s*\(\s*['\"]title-tag['\"]",
        "post-thumbnails": r"add_theme_support\s*\(\s*['\"]post-thumbnails['\"]",
        "HTML5 markup": r"add_theme_support\s*\(\s*['\"]html5['\"]",
        "custom-logo": r"add_theme_support\s*\(\s*['\"]custom-logo['\"]",
        "navigation menus": r"register_nav_menus?\s*\(",
    }
    missing = [name for name, pattern in setup_checks.items() if not re.search(pattern, all_php, re.I)]
    if missing:
        report.fail("php.theme_setup", "Theme setup is incomplete", ", ".join(missing))
    else:
        report.passed("php.theme_setup", "Theme support and enqueue hooks are registered")

    gallery_features = (
        "wc-product-gallery-zoom",
        "wc-product-gallery-lightbox",
        "wc-product-gallery-slider",
    )
    missing_gallery = [
        feature
        for feature in gallery_features
        if not re.search(rf"add_theme_support\s*\(\s*['\"]{re.escape(feature)}['\"]", all_php, re.I)
    ]
    if missing_gallery:
        report.warn(
            "php.product_gallery",
            "Recommended WooCommerce gallery features are incomplete",
            ", ".join(missing_gallery),
        )
    else:
        report.passed("php.product_gallery", "WooCommerce zoom, lightbox and gallery slider are enabled")

    direct_includes = [
        path for path in php_files
        if re.search(r"(?<![\w])(?:include|require)(?:_once)?\s*\(?\s*['\"]", read_text(path))
    ]
    if direct_includes:
        report.warn(
            "php.includes",
            "Literal PHP includes found; get_theme_file_path() is safer for child-theme aware code",
            relative_list(theme, direct_includes),
        )


def check_theme_hygiene(theme: Path, report: Report, text_files: Sequence[Path]) -> None:
    forbidden_dirs = []
    for name in ("node_modules", ".git", ".svn", "__pycache__"):
        forbidden_dirs.extend(path for path in theme.rglob(name) if path.is_dir())
    temporary = [
        path
        for path in theme.rglob("*")
        if path.is_file() and (path.name.endswith(("~", ".tmp", ".bak", ".orig")) or path.name == ".DS_Store")
    ]
    liquid = list(theme.rglob("*.liquid"))
    offenders = forbidden_dirs + temporary + liquid
    if offenders:
        report.fail(
            "hygiene.files",
            "Theme contains development, temporary, or Shopify-only files",
            relative_list(theme, offenders),
        )
    else:
        report.passed("hygiene.files", "No development, temporary, or Liquid files are packaged")

    text = combined_text(text_files)
    shopify_markers = re.findall(
        r"(?:cdn\.shopify\.com|myshopify\.com|shopify\.section|routes\.cart|\{\{\s*(?:product|section|settings)\.)",
        text,
        re.I,
    )
    if shopify_markers:
        report.fail(
            "hygiene.shopify",
            "Shopify/Liquid runtime markers remain in the WordPress theme",
            f"Found {len(shopify_markers)} occurrence(s)",
        )
    else:
        report.passed("hygiene.shopify", "No Shopify runtime dependencies were found")


def check_php_lint(theme: Path, report: Report, php_files: Sequence[Path]) -> None:
    php = shutil.which("php")
    if not php:
        ast_report = PROJECT_ROOT / "tests" / "artifacts" / "php-ast-validation.json"
        try:
            payload = json.loads(ast_report.read_text(encoding="utf-8"))
            passed_files = {
                item["file"]
                for item in payload.get("results", [])
                if item.get("passed") is True
            }
            expected_files = {
                path.relative_to(PROJECT_ROOT).as_posix()
                for path in php_files
            }
        except (OSError, ValueError, KeyError, TypeError):
            passed_files = set()
            expected_files = set()
        if expected_files and expected_files.issubset(passed_files):
            report.passed(
                "php.lint",
                f"PHP AST parsing succeeded for all {len(php_files)} theme files",
                "Validated with nikic-compatible php-parser because PHP CLI is unavailable.",
            )
        else:
            report.warn("php.lint", "PHP CLI is unavailable and no current AST report covers every theme file")
        return
    failures: list[str] = []
    for path in php_files:
        result = subprocess.run(
            [php, "-l", str(path)],
            capture_output=True,
            text=True,
            timeout=20,
            check=False,
        )
        if result.returncode:
            output = (result.stdout + result.stderr).strip().replace("\n", " | ")
            failures.append(f"{path.relative_to(theme)}: {output}")
    if failures:
        report.fail("php.lint", f"PHP syntax failed in {len(failures)} file(s)", "\n".join(failures))
    else:
        report.passed("php.lint", f"PHP syntax is valid in {len(php_files)} file(s)")


def check_literal_assets(theme: Path, report: Report, text_files: Sequence[Path]) -> None:
    references: list[tuple[Path, str]] = []
    helper_references: list[tuple[Path, str]] = []
    php_patterns = (
        r"(?:get_template_directory_uri|get_stylesheet_directory_uri)\s*\(\s*\)\s*\.\s*['\"](?P<path>/[^'\"]+)['\"]",
        r"get_theme_file_uri\s*\(\s*['\"](?P<path>[^'\"]+)['\"]\s*\)",
        r"get_theme_file_path\s*\(\s*['\"](?P<path>[^'\"]+)['\"]\s*\)",
    )
    css_pattern = re.compile(r"url\(\s*['\"]?(?P<path>[^)'\"]+)['\"]?\s*\)", re.I)
    for source in text_files:
        text = read_text(source)
        if source.suffix.lower() == ".php":
            for pattern in php_patterns:
                references.extend((source, match.group("path")) for match in re.finditer(pattern, text))
            helper_references.extend(
                (source, match.group("path"))
                for match in re.finditer(r"xiujin_theme_asset\s*\(\s*['\"](?P<path>[^'\"]+)['\"]\s*\)", text)
            )
        if source.suffix.lower() == ".css":
            references.extend((source, match.group("path")) for match in css_pattern.finditer(text))

    missing: list[str] = []
    for source, reference in references:
        clean = reference.split("?", 1)[0].split("#", 1)[0].strip()
        if not clean or clean.startswith(("data:", "http://", "https://", "//", "var(")):
            continue
        target = (theme / clean.lstrip("/")) if source.suffix.lower() == ".php" else (source.parent / clean)
        if not target.resolve().is_file():
            missing.append(f"{source.relative_to(theme)} -> {clean}")
    for source, clean in helper_references:
        target = theme / "assets" / "images" / clean.lstrip("/")
        if not target.is_file():
            missing.append(f"{source.relative_to(theme)} -> assets/images/{clean}")
    if missing:
        report.fail("assets.references", "Theme contains missing literal asset references", "\n".join(sorted(set(missing))))
    else:
        report.passed(
            "assets.references",
            f"Checked {len(references) + len(helper_references)} literal local asset references",
        )


def check_i18n(
    theme: Path,
    report: Report,
    php_files: Sequence[Path],
    all_php: str,
    text_domain: str,
) -> None:
    load_pattern = rf"load_theme_textdomain\s*\(\s*['\"]{re.escape(text_domain)}['\"]" if text_domain else r"a^"
    if re.search(load_pattern, all_php):
        report.passed("i18n.load", "Theme loads its gettext text domain")
    else:
        report.fail("i18n.load", f"Theme does not load text domain {text_domain or '(missing)'}")

    translation_calls = re.findall(
        r"\b(?:__|_e|_x|esc_html__|esc_html_e|esc_attr__|esc_attr_e|_n)\s*\(", all_php
    )
    if len(translation_calls) >= 20:
        report.passed("i18n.functions", f"Found {len(translation_calls)} gettext calls")
    else:
        report.fail(
            "i18n.functions",
            "Too few translatable UI strings were found",
            f"Found {len(translation_calls)}; expected at least 20",
        )

    literal_domains = set(
        re.findall(
            r"\b(?:__|_e|_x|esc_html__|esc_html_e|esc_attr__|esc_attr_e)\s*\([^;]*?,\s*['\"]([\w-]+)['\"]\s*\)",
            all_php,
        )
    )
    wrong = sorted(domain for domain in literal_domains if domain != text_domain)
    if wrong:
        report.fail("i18n.domain_consistency", "Inconsistent gettext text domains found", ", ".join(wrong))
    else:
        report.passed("i18n.domain_consistency", "Gettext calls use a consistent text domain")

    language_dir = theme / "languages"
    pot_files = list(language_dir.glob("*.pot")) if language_dir.exists() else []
    if not pot_files:
        report.fail("i18n.pot", "A gettext POT template is required")
    else:
        pot = read_text(pot_files[0])
        msgid_count = len(re.findall(r"(?m)^msgid\s+\"(?!\")", pot))
        if msgid_count >= 20:
            report.passed("i18n.pot", f"POT template contains {msgid_count} source messages")
        else:
            report.fail(
                "i18n.pot",
                "POT template is incomplete or has the wrong project domain",
                f"Messages: {msgid_count}",
            )

    required_runtime_catalogs = (language_dir / "es_ES.mo", language_dir / "pt_BR.mo")
    stale_theme_catalogs = (
        language_dir / "xiujin-es_ES.mo",
        language_dir / "xiujin-pt_BR.mo",
    )
    missing_runtime = [path.name for path in required_runtime_catalogs if not path.is_file()]
    stale_runtime = [path.name for path in stale_theme_catalogs if path.exists()]
    if not missing_runtime and not stale_runtime:
        report.passed(
            "i18n.languages",
            "Bundled theme catalogs use WordPress runtime filenames es_ES.mo and pt_BR.mo",
        )
    else:
        details = []
        if missing_runtime:
            details.append("missing=" + ", ".join(missing_runtime))
        if stale_runtime:
            details.append("invalid bundled-theme names=" + ", ".join(stale_runtime))
        report.fail(
            "i18n.languages",
            "Required WordPress runtime translation catalogs are incorrect",
            "; ".join(details),
        )

    html_literal = re.compile(r">\s*([A-Za-z][A-Za-z0-9 ,.&'!?/-]{3,})\s*<")
    offenders: list[str] = []
    for path in php_files:
        rel = path.relative_to(theme)
        if rel.name in {"functions.php"} or "inc" in rel.parts:
            continue
        stripped = re.sub(r"<\?php.*?\?>", "", read_text(path), flags=re.S)
        samples = [
            sample
            for sample in html_literal.findall(stripped)
            if sample.strip().upper() != sample.strip()
            and sample.strip().lower() not in {"xiujin", "facebook", "instagram", "tiktok", "whatsapp", "messenger"}
        ]
        if samples:
            offenders.append(f"{rel}: {samples[0][:70]}")
    if offenders:
        report.warn(
            "i18n.literals",
            "Possible untranslated literal text remains in templates",
            "\n".join(offenders[:12]),
        )
    else:
        report.passed("i18n.literals", "No obvious untranslated English HTML literals found")


def check_seo(theme: Path, report: Report, all_text: str, all_php: str) -> None:
    checks = {
        "document title": r"(?:add_theme_support\s*\(\s*['\"]title-tag|wp_get_document_title\s*\()",
        "meta description": r"<meta[^>]+name\s*=\s*['\"]description|meta_description",
        "Open Graph": r"property\s*=\s*['\"]og:(?:title|description|image)|og:title",
        "Twitter Card": r"name\s*=\s*['\"]twitter:card|twitter:card",
        "JSON-LD": r"application/ld\+json|schema\.org",
    }
    missing = [name for name, pattern in checks.items() if not re.search(pattern, all_text, re.I)]
    if missing:
        report.fail("seo.basics", "SEO output is incomplete", ", ".join(missing))
    else:
        report.passed("seo.basics", "Title, description, social cards and JSON-LD are implemented")

    if re.search(r"rel\s*=\s*['\"]canonical|rel_canonical|wp_get_canonical_url", all_text, re.I):
        report.passed("seo.canonical", "Canonical URL handling is explicit")
    elif re.search(r"\bwp_head\s*\(", all_php):
        report.warn(
            "seo.canonical",
            "Canonical output relies on WordPress core or an SEO plugin; verify the homepage canonical after install",
        )
    else:
        report.fail("seo.canonical", "No canonical URL path was found")

    schema_types = ("Organization", "WebSite")
    missing_schema = [
        name
        for name in schema_types
        if not re.search(rf"['\"]@type['\"]\s*=>?\s*['\"]{name}|\"@type\"\s*:\s*\"{name}\"", all_text)
    ]
    if missing_schema:
        report.fail("seo.schema", "Required organization/site Schema.org types are missing", ", ".join(missing_schema))
    else:
        report.passed("seo.schema", "Organization and WebSite schemas are represented")

    product_schema = re.search(r"['\"]@type['\"]\s*=>?\s*['\"]Product|woocommerce_structured_data_product", all_text, re.I)
    woo_delegation = re.search(r"add_theme_support\s*\(\s*['\"]woocommerce['\"]", all_php, re.I)
    if product_schema:
        report.passed("seo.product_schema", "Dynamic Product schema integration is represented")
    elif woo_delegation:
        report.passed("seo.product_schema", "Product schema is delegated to WooCommerce")
    else:
        report.fail("seo.product_schema", "No Product schema owner was found")

    if re.search(r"BreadcrumbList|woocommerce_breadcrumb|rank_math_the_breadcrumbs|yoast_breadcrumb", all_text, re.I):
        report.passed("seo.breadcrumb_schema", "Breadcrumb output/schema integration is represented")
    else:
        report.warn("seo.breadcrumb_schema", "No explicit breadcrumb integration was found")

    plugin_guard = re.search(
        r"(?:WPSEO_VERSION|wpseo_|Rank_Math|rank_math|SEOPRESS|seopress|AIOSEO|aioseo|Yoast)",
        all_php,
        re.I,
    )
    custom_meta = re.search(r"(?:og:title|twitter:card|meta_description|canonical)", all_php, re.I)
    if custom_meta and not plugin_guard:
        report.fail(
            "seo.plugin_guard",
            "Custom SEO tags need a guard to avoid duplicates with major SEO plugins",
        )
    else:
        report.passed("seo.plugin_guard", "SEO output accounts for major SEO plugins")

    fabricated_rating = re.search(r"AggregateRating|reviewRating|ratingValue|reviewCount", all_text, re.I)
    if fabricated_rating:
        report.fail(
            "seo.claims",
            "Rating/review schema found; remove it unless sourced from real WooCommerce reviews",
        )
    else:
        report.passed("seo.claims", "No fabricated rating or review schema was found")


def check_responsive_and_motion(theme: Path, report: Report, css_files: Sequence[Path], js_files: Sequence[Path]) -> None:
    css = combined_text(css_files)
    js = combined_text(js_files)
    media_queries = len(re.findall(r"@media\s*\(", css, re.I))
    breakpoints = set(re.findall(r"(?:min|max)-width\s*:\s*(\d+)px", css, re.I))
    if media_queries >= 3 and len(breakpoints) >= 2:
        report.passed(
            "responsive.breakpoints",
            f"Responsive CSS contains {media_queries} media queries across {len(breakpoints)} breakpoints",
        )
    else:
        report.fail(
            "responsive.breakpoints",
            "Responsive coverage is too small",
            f"Media queries: {media_queries}; unique width breakpoints: {len(breakpoints)}",
        )

    if re.search(r"img\s*\{[^}]*max-width\s*:\s*100%", css, re.I | re.S):
        report.passed("responsive.images", "Images have a fluid max-width rule")
    else:
        report.fail("responsive.images", "Global image CSS needs max-width: 100%")

    if re.search(r"overflow-x\s*:\s*(?:clip|hidden)", css, re.I):
        report.passed("responsive.overflow_guard", "A horizontal overflow guard is present")
    else:
        report.warn("responsive.overflow_guard", "No CSS horizontal overflow guard was found")

    reduced = re.search(r"@media\s*\(\s*prefers-reduced-motion\s*:\s*reduce\s*\)", css, re.I)
    reduced_body = css[reduced.end():reduced.end() + 2500] if reduced else ""
    if reduced and re.search(r"animation(?:-duration)?\s*:\s*(?:none|0(?:\.0+)?(?:ms|s)|0\.01ms)|animation-iteration-count\s*:\s*1", reduced_body, re.I):
        report.passed("motion.reduced_css", "CSS disables or minimizes animation for reduced-motion users")
    else:
        report.fail("motion.reduced_css", "A complete prefers-reduced-motion CSS override is required")

    if "matchMedia" in js and "prefers-reduced-motion" in js:
        report.passed("motion.reduced_js", "JavaScript respects prefers-reduced-motion")
    elif re.search(r"requestAnimationFrame|setInterval|\.animate\s*\(", js):
        report.fail("motion.reduced_js", "Animated JavaScript does not visibly honor reduced-motion")
    else:
        report.passed("motion.reduced_js", "No continuous JavaScript animation requires a motion preference guard")

    keyframes = len(re.findall(r"@keyframes\s+[\w-]+", css, re.I))
    if keyframes >= 4:
        report.passed("motion.variety", f"Theme includes {keyframes} CSS animation sequences")
    elif keyframes:
        report.warn("motion.variety", f"Theme includes only {keyframes} CSS animation sequence(s)")
    else:
        report.fail("motion.variety", "No CSS animation sequences were found")

    expensive: list[str] = []
    for match in re.finditer(r"@keyframes\s+([\w-]+)\s*\{(.*?)\n?\}", css, re.I | re.S):
        if re.search(r"(?:^|[;{])\s*(?:top|left|right|bottom|width|height)\s*:", match.group(2), re.I):
            expensive.append(match.group(1))
    if expensive:
        report.warn(
            "motion.performance",
            "Some keyframes animate layout properties; prefer transform and opacity",
            ", ".join(sorted(set(expensive))),
        )
    else:
        report.passed("motion.performance", "CSS keyframes avoid obvious layout-changing properties")

    if re.search(r"\bsetInterval\s*\(", js):
        report.fail("motion.intervals", "Continuous setInterval animation is disallowed; use CSS or requestAnimationFrame")
    else:
        report.passed("motion.intervals", "No continuous setInterval animation was found")

    high_frequency_events = re.search(r"addEventListener\s*\(\s*['\"](?:scroll|pointermove|mousemove|touchmove)['\"]", js)
    if high_frequency_events and "requestAnimationFrame" not in js:
        report.fail("motion.throttle", "Scroll/pointer animation handlers need requestAnimationFrame throttling")
    else:
        report.passed("motion.throttle", "High-frequency animation handlers are absent or requestAnimationFrame-throttled")

    reveals = re.search(r"reveal|parallax|three|3d|model", js, re.I)
    if reveals and "IntersectionObserver" not in js:
        report.warn("motion.lazy_init", "Reveal/3D behavior should initialize through IntersectionObserver")
    elif reveals:
        report.passed("motion.lazy_init", "Animated/reveal content uses IntersectionObserver")


def _catalog_counts_from_csv(path: Path) -> tuple[int, int] | None:
    try:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.DictReader(handle))
    except (OSError, csv.Error, UnicodeDecodeError):
        return None
    if not rows:
        return None
    config_key = next(
        (key for key in ("visual_configuration_id", "configuration_id", "config_id") if key in rows[0]),
        None,
    )
    series_key = next(
        (key for key in ("series_order", "series_id", "series", "source_start_row") if key in rows[0]),
        None,
    )
    if not config_key or not series_key:
        return None
    configs = {row.get(config_key, "").strip() for row in rows if row.get(config_key, "").strip()}
    series = {row.get(series_key, "").strip() for row in rows if row.get(series_key, "").strip()}
    return len(series), len(configs)


def _count_json_records(value: Any) -> list[int]:
    output: list[int] = []
    if isinstance(value, list):
        output.append(len(value))
        for item in value:
            output.extend(_count_json_records(item))
    elif isinstance(value, dict):
        for item in value.values():
            output.extend(_count_json_records(item))
    return output


def check_catalog(theme: Path, report: Report, text_files: Sequence[Path]) -> None:
    csv_results: list[tuple[Path, int, int]] = []
    for path in iter_files(theme, {".csv"}):
        counts = _catalog_counts_from_csv(path)
        if counts:
            csv_results.append((path, counts[0], counts[1]))

    json_lengths: list[tuple[Path, list[int]]] = []
    for path in iter_files(theme, {".json"}):
        try:
            value = json.loads(read_text(path))
        except json.JSONDecodeError:
            continue
        json_lengths.append((path, _count_json_records(value)))

    text = combined_text(text_files)
    unique_config_ids = set(CONFIGURATION_ID_RE.findall(text))
    exact_csv = next((item for item in csv_results if item[1:] == (EXPECTED_SERIES, EXPECTED_CONFIGURATIONS)), None)
    has_json_18 = any(EXPECTED_SERIES in lengths for _, lengths in json_lengths)
    has_json_58 = any(EXPECTED_CONFIGURATIONS in lengths for _, lengths in json_lengths)

    if exact_csv:
        report.passed(
            "catalog.counts",
            f"Catalog contains exactly {EXPECTED_SERIES} series and {EXPECTED_CONFIGURATIONS} configurations",
            str(exact_csv[0].relative_to(theme)),
        )
    elif has_json_18 and has_json_58:
        sources = [str(path.relative_to(theme)) for path, lengths in json_lengths if 18 in lengths or 58 in lengths]
        report.passed(
            "catalog.counts",
            f"JSON catalog exposes {EXPECTED_SERIES} series and {EXPECTED_CONFIGURATIONS} configurations",
            ", ".join(sources),
        )
    elif len(unique_config_ids) == EXPECTED_CONFIGURATIONS:
        report.passed(
            "catalog.counts",
            f"Found {EXPECTED_CONFIGURATIONS} unique configuration IDs in theme data",
        )
        report.warn("catalog.series_count", "Could not independently establish the 18-series grouping")
    else:
        details = [f"Unique configuration IDs found: {len(unique_config_ids)}"]
        details.extend(
            f"{path.relative_to(theme)}: {series} series / {configs} configurations"
            for path, series, configs in csv_results
        )
        report.fail(
            "catalog.counts",
            f"Theme must package {EXPECTED_SERIES} series and {EXPECTED_CONFIGURATIONS} configurations",
            "\n".join(details),
        )

    if unique_config_ids:
        actual_distribution = tuple(
            sum(config_id.upper().startswith(f"S{series:02d}-") for config_id in unique_config_ids)
            for series in range(1, EXPECTED_SERIES + 1)
        )
        if actual_distribution == EXPECTED_CONFIGURATION_DISTRIBUTION:
            report.passed(
                "catalog.distribution",
                "All 58 configurations have the expected 18-series distribution",
                str(actual_distribution),
            )
        else:
            report.fail(
                "catalog.distribution",
                "Configuration distribution across the 18 series is incorrect",
                f"Expected {EXPECTED_CONFIGURATION_DISTRIBUTION}; found {actual_distribution}",
            )
        row_171 = {f"S18-R171-V{number:02d}" for number in range(1, 4)}
        present = {config_id.upper() for config_id in unique_config_ids}
        if row_171.issubset(present):
            report.passed("catalog.row171", "The three row-171 configurations are included")
        else:
            report.fail(
                "catalog.row171",
                "The catalog is missing one or more row-171 configurations",
                ", ".join(sorted(row_171 - present)),
            )

    mapping_errors: list[str] = []
    lower_text = text.lower()
    for config_id, (source_name, theme_alias, terms) in EXPECTED_PRIMARY_MEDIA.items():
        positions = [match.start() for match in re.finditer(re.escape(config_id.lower()), lower_text)]
        snippets: list[str] = []
        for position in positions:
            next_match = CONFIGURATION_ID_RE.search(text, position + len(config_id))
            end = min(len(text), next_match.start() if next_match else position + 1200)
            snippets.append(lower_text[position:end])
        alias_positions = [match.start() for match in re.finditer(re.escape(theme_alias), lower_text)]
        for position in alias_positions:
            snippets.append(lower_text[max(0, position - 400):min(len(text), position + 900)])
        joined = "\n".join(snippets)
        packaged_name = f"series-01-row-002-8011-config-{int(config_id[-2:]):02d}"
        if not joined:
            mapping_errors.append(f"{config_id}: record/alias {theme_alias} not found")
            continue
        if source_name.lower() not in joined and packaged_name not in joined and theme_alias not in joined:
            mapping_errors.append(f"{config_id}: expected media {source_name} / {packaged_name} / {theme_alias}")
        missing_terms = [term for term in terms if term not in joined]
        if missing_terms:
            mapping_errors.append(f"{config_id}: label missing {', '.join(missing_terms)}")
        if config_id.endswith("V01") and "gray" in joined:
            mapping_errors.append(f"{config_id}: obsolete black-and-gray label remains; use black and white")
    if mapping_errors:
        report.fail(
            "catalog.primary_mapping",
            "The six primary chair color/media mappings are inconsistent",
            "\n".join(mapping_errors),
        )
    else:
        report.passed(
            "catalog.primary_mapping",
            "Six primary chair configurations match their actual media and color labels",
        )

    catalog_data = read_text(theme / "inc" / "catalog-data.php") if (theme / "inc" / "catalog-data.php").exists() else ""
    model_script = read_text(theme / "assets" / "js" / "chair-model.js") if (theme / "assets" / "js" / "chair-model.js").exists() else ""
    template_path = theme / "template-parts" / "home" / "configurations.php"
    configuration_template = read_text(template_path) if template_path.exists() else ""
    theme_script = read_text(theme / "assets" / "js" / "theme.js") if (theme / "assets" / "js" / "theme.js").exists() else ""
    model_mapping_errors: list[str] = []
    for config_key, model_index, variant_key in EXPECTED_3D_MAPPINGS:
        record_pattern = re.compile(
            rf"['\"]key['\"]\s*=>\s*['\"]{re.escape(config_key)}['\"][^\n]{{0,900}}?"
            rf"['\"]model_index['\"]\s*=>\s*{model_index}\s*,[^\n]{{0,300}}?"
            rf"['\"]model_key['\"]\s*=>\s*['\"]{re.escape(variant_key)}['\"]",
            re.I,
        )
        if not record_pattern.search(catalog_data):
            model_mapping_errors.append(
                f"{config_key}: expected model_index {model_index} and model_key {variant_key}"
            )
        if variant_key not in model_script:
            model_mapping_errors.append(f"{config_key}: 3D variant {variant_key} missing from renderer")
    payload_match = re.search(r"const payload=(\{.*?\});\s*let selected=", model_script, re.S)
    if not payload_match:
        model_mapping_errors.append("3D renderer payload could not be inspected")
    else:
        try:
            payload = json.loads(payload_match.group(1))
            actual_variant_order = [item.get("key") for item in payload.get("variants", [])]
        except (json.JSONDecodeError, AttributeError, TypeError) as exc:
            model_mapping_errors.append(f"3D renderer payload is invalid: {exc}")
        else:
            expected_by_model_index = [
                variant_key
                for _, _, variant_key in sorted(EXPECTED_3D_MAPPINGS, key=lambda item: item[1])
            ]
            if actual_variant_order != expected_by_model_index:
                model_mapping_errors.append(
                    "3D renderer model-index order is "
                    + ", ".join(str(item) for item in actual_variant_order)
                    + "; expected "
                    + ", ".join(expected_by_model_index)
                )
    wiring_tokens = ("data-model-index", "model_index")
    if any(token not in configuration_template for token in wiring_tokens):
        model_mapping_errors.append("configuration template does not expose all model indices")
    if "dataset.modelIndex" not in theme_script or "dispatchEvent" not in theme_script:
        model_mapping_errors.append("theme script does not synchronize photo choices with the 3D selector")
    if model_mapping_errors:
        report.fail(
            "catalog.model_mapping",
            "The six product photos and 3D variants are not mapped consistently",
            "\n".join(model_mapping_errors),
        )
    else:
        report.passed(
            "catalog.model_mapping",
            "All six product photos declare matching 3D variants",
            "thumbnail model indices: 0, 1, 4, 5, 2, 3",
        )

    # The theme carries the configuration index, while the complete media set
    # is shipped once in the WooCommerce import package. Duplicating all source
    # photos inside the theme adds upload and backup weight without a runtime
    # benefit. The delivery validator below checks every mapped media file.
    legacy_media = theme / "assets" / "catalog-configurations"
    if legacy_media.exists():
        report.warn(
            "catalog.theme_media",
            "Legacy catalog media is still bundled in the theme",
            "Remove assets/catalog-configurations; the WooCommerce import package is the media owner.",
        )
    else:
        report.passed(
            "catalog.theme_media",
            "Full catalog media is kept out of the runtime theme package",
        )

    home_templates = [theme / "front-page.php"]
    home_templates.extend((theme / "template-parts" / "home").glob("*.php") if (theme / "template-parts" / "home").exists() else [])
    visible_8011 = [path for path in home_templates if path.exists() and "8011" in read_text(path)]
    if visible_8011:
        report.fail(
            "catalog.visible_8011",
            "The removed 8011 number still appears in homepage presentation templates",
            relative_list(theme, visible_8011),
        )
    else:
        report.passed("catalog.visible_8011", "The 8011 number is absent from homepage presentation templates")


def check_social(theme: Path, report: Report, all_text: str, all_php: str) -> None:
    networks = {
        "Facebook": r"facebook",
        "Instagram": r"instagram",
        "TikTok": r"tiktok",
        "WhatsApp": r"whatsapp|wa\.me",
        "Messenger": r"messenger|m\.me",
    }
    missing = [name for name, pattern in networks.items() if not re.search(pattern, all_text, re.I)]
    if missing:
        report.fail("social.networks", "Required social entrances are missing", ", ".join(missing))
    else:
        report.passed("social.networks", "Facebook, Instagram, TikTok, WhatsApp and Messenger are represented")

    customizer = re.search(r"customize_register|get_theme_mod|register_setting", all_php, re.I)
    network_names_in_admin = sum(bool(re.search(pattern, all_php, re.I)) for pattern in networks.values())
    if customizer and network_names_in_admin == len(networks):
        report.passed("social.settings", "Social URLs are represented as administrator-configurable settings")
    else:
        report.fail("social.settings", "Social links need editable Customizer/theme settings")

    if "target=\"_blank\"" in all_text or "target='_blank'" in all_text:
        if re.search(r"rel\s*=\s*['\"][^'\"]*(?:noopener|noreferrer)", all_text, re.I):
            report.passed("social.external_safety", "New-tab links use rel=noopener/noreferrer")
        else:
            report.fail("social.external_safety", "New-tab links must use rel=noopener or noreferrer")

    retired_whatsapp = re.search(r"(?:\+?852[\s-]*9019[\s-]*9249|wa\.me/85290199249)", all_text, re.I)
    if "https://wa.me/8618406845852" in all_text and "header-whatsapp" in all_text and not retired_whatsapp:
        report.passed(
            "social.whatsapp_verified",
            "The verified WhatsApp contact is exposed in the header and the retired number is absent",
        )
    else:
        report.fail(
            "social.whatsapp_verified",
            "The header must use the verified WhatsApp URL and omit the retired number",
        )


def check_woocommerce(theme: Path, report: Report, all_php: str) -> None:
    support = re.search(r"add_theme_support\s*\(\s*['\"]woocommerce['\"]", all_php, re.I)
    if support:
        report.passed("woocommerce.support", "WooCommerce theme support is registered")
    else:
        report.fail("woocommerce.support", "add_theme_support('woocommerce') is missing")

    hook_names = (
        "woocommerce_before_main_content",
        "woocommerce_after_main_content",
        "woocommerce_product_query",
        "woocommerce_single_product_summary",
    )
    found = [name for name in hook_names if name in all_php]
    registered = set(
        re.findall(
            r"(?:add_action|add_filter)\s*\(\s*['\"](woocommerce_[\w-]+)['\"]",
            all_php,
            re.I,
        )
    )
    wrapper_pair = {
        "woocommerce_before_main_content",
        "woocommerce_after_main_content",
    }.issubset(set(found))
    if wrapper_pair and len(registered) >= 3:
        report.passed("woocommerce.hooks", f"WooCommerce integration registers {len(registered)} hooks/filters")
    else:
        report.fail(
            "woocommerce.hooks",
            "WooCommerce integration hooks are incomplete",
            f"Found core integration points: {', '.join(found) or '(none)'}; registered hooks: {len(registered)}",
        )

    product_templates = list((theme / "woocommerce").rglob("*.php")) if (theme / "woocommerce").exists() else []
    has_product_output = bool(
        re.search(
            r"woocommerce_content\s*\(|wc_get_template|woocommerce_template_(?:single|loop)|the_product",
            all_php,
            re.I,
        )
        or product_templates
    )
    if has_product_output:
        report.passed("woocommerce.products", "Product/archive rendering integration is present")
    else:
        report.fail("woocommerce.products", "No WooCommerce product rendering integration was found")

    catalog_filters = {
        "woocommerce_is_purchasable",
        "woocommerce_variation_is_purchasable",
    }
    has_catalog_mode = catalog_filters.issubset(registered) and bool(
        re.search(r"function\s+xiujin_catalog_only_purchasable\s*\([^)]*\)\s*\{\s*return\s+false", all_php, re.I | re.S)
    )
    exposes_cart = bool(re.search(r"wc_get_cart_url|xiujin_cart_link|woocommerce_add_to_cart_fragments", all_php, re.I))
    if has_catalog_mode and not exposes_cart:
        report.passed("woocommerce.enquiry_mode", "WooCommerce is configured as an enquiry-only catalog without cart UI")
    elif exposes_cart:
        report.fail("woocommerce.enquiry_mode", "Cart or add-to-cart UI remains in this no-online-payment theme")
    else:
        report.fail("woocommerce.enquiry_mode", "Catalog-only purchasability filters are incomplete")

    if re.search(r"class_exists\s*\(\s*['\"]WooCommerce['\"]|function_exists\s*\(\s*['\"]WC", all_php, re.I):
        report.passed("woocommerce.guard", "WooCommerce-dependent code has an availability guard")
    else:
        report.warn("woocommerce.guard", "Add a guard so the theme still loads when WooCommerce is inactive")


def check_quote_security(theme: Path, report: Report, all_php: str) -> None:
    has_quote = bool(re.search(r"quote|enquiry|inquiry|wholesale", all_php, re.I))
    if not has_quote:
        report.fail("quote.present", "No B2B wholesale enquiry workflow was found")
        return
    report.passed("quote.present", "A B2B wholesale enquiry workflow is represented")

    ajax = re.findall(r"wp_ajax_(?:nopriv_)?([\w-]+)", all_php, re.I)
    has_form_handler = bool(ajax or re.search(r"admin_post_(?:nopriv_)?[\w-]+", all_php, re.I))
    if not has_form_handler:
        report.warn(
            "quote.handler",
            "No native AJAX/admin-post quote handler found; confirm the form intentionally delegates to a plugin",
        )
        return

    security_checks = {
        "nonce verification": r"wp_verify_nonce|check_ajax_referer|check_admin_referer",
        "text sanitization": r"sanitize_text_field|sanitize_textarea_field",
        "email validation": r"sanitize_email|is_email",
        "JSON/redirect response": r"wp_send_json_(?:success|error)|wp_safe_redirect",
    }
    missing = [name for name, pattern in security_checks.items() if not re.search(pattern, all_php, re.I)]
    if missing:
        report.fail("quote.security", "Quote handler security checks are incomplete", ", ".join(missing))
    else:
        report.passed("quote.security", "Quote handler verifies nonces, sanitizes fields and returns safely")

    if ajax:
        actions = set(ajax)
        public = set(re.findall(r"wp_ajax_nopriv_([\w-]+)", all_php, re.I))
        privileged = set(re.findall(r"wp_ajax_(?!nopriv_)([\w-]+)", all_php, re.I))
        unpaired = sorted((public | privileged) - (public & privileged))
        if unpaired:
            report.fail(
                "quote.ajax_access",
                "AJAX quote actions must support signed-in and signed-out visitors",
                ", ".join(unpaired),
            )
        else:
            report.passed("quote.ajax_access", "AJAX quote actions support public and signed-in users")

    secret_pattern = re.compile(
        r"(?:api[_-]?key|secret|access[_-]?token|password)\s*['\"]?\s*(?:=>|=|:)\s*['\"][A-Za-z0-9_\-]{16,}['\"]",
        re.I,
    )
    if secret_pattern.search(all_php):
        report.fail("security.secrets", "A possible hard-coded API key, token or password was found")
    else:
        report.passed("security.secrets", "No obvious hard-coded secret was found")


def check_accessibility_static(theme: Path, report: Report, php_files: Sequence[Path], all_php: str) -> None:
    front_files = [path for path in php_files if path.name == "front-page.php" or "template-parts" in path.parts]
    front = combined_text(front_files)
    semantic = {
        "main landmark": r"<main\b",
        "navigation landmark": r"<nav\b",
        "footer landmark": r"<footer\b",
        "primary heading": r"<h1\b",
    }
    missing = [name for name, pattern in semantic.items() if not re.search(pattern, all_php, re.I)]
    if missing:
        report.fail("a11y.landmarks", "Semantic page landmarks are incomplete", ", ".join(missing))
    else:
        report.passed("a11y.landmarks", "Main, navigation, footer and H1 semantics are present")

    css = combined_text(list(iter_files(theme, {".css"})))
    if re.search(r":focus-visible|:focus\s*\{", css, re.I):
        report.passed("a11y.focus", "Visible keyboard focus styling is defined")
    else:
        report.fail("a11y.focus", "Visible :focus or :focus-visible styling is missing")

    front_without_php = re.sub(r"<\?php.*?\?>", "PHP_VALUE", front, flags=re.S)
    image_tags = re.findall(r"<img\b[^>]*>", front_without_php, re.I | re.S)
    missing_alt = [tag[:120] for tag in image_tags if not re.search(r"\balt\s*=", tag, re.I)]
    missing_size = [
        tag[:120]
        for tag in image_tags
        if not (
            re.search(r"\bwidth\s*=", tag, re.I)
            and re.search(r"\bheight\s*=", tag, re.I)
        )
        and "wp_get_attachment_image" not in tag
    ]
    if missing_alt:
        report.fail("a11y.image_alt", "Homepage image tags are missing alt attributes", "\n".join(missing_alt[:8]))
    else:
        report.passed("a11y.image_alt", f"All {len(image_tags)} static homepage image tags include alt")
    if missing_size:
        report.warn(
            "performance.image_dimensions",
            "Some static homepage images lack width/height and may cause layout shift",
            "\n".join(missing_size[:8]),
        )
    else:
        report.passed("performance.image_dimensions", "Static homepage images reserve intrinsic space")


def check_content_requirements(theme: Path, report: Report, all_text: str, all_php: str) -> None:
    required_concepts = {
        "factory-direct positioning": r"factory[ -]?direct|manufacturer",
        "wholesale": r"wholesale|b2b",
        "retail": r"retail|add to cart",
        "quotation CTA": r"request (?:a )?(?:quote|quotation)|wholesale (?:quote|enquiry|inquiry)",
    }
    missing = [name for name, pattern in required_concepts.items() if not re.search(pattern, all_text, re.I)]
    if missing:
        report.fail("content.positioning", "Required B2B and retail positioning is incomplete", ", ".join(missing))
    else:
        report.passed("content.positioning", "Factory-direct, wholesale, retail and quotation messaging is present")

    factory_assets = [
        path
        for path in iter_files(theme)
        if "factory" in path.name.lower()
        and path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".avif", ".mp4", ".webm"}
    ]
    provenance_path = theme / "data" / "factory-media.json"
    if provenance_path.is_file():
        try:
            provenance = json.loads(read_text(provenance_path))
            media_paths = {
                "video": theme / "assets" / "video" / provenance["video"]["filename"],
                "poster": theme / "assets" / "images" / provenance["poster"]["filename"],
            }
            invalid = []
            for media_type, path in media_paths.items():
                if not path.is_file():
                    invalid.append(f"missing {path.relative_to(theme)}")
                    continue
                actual_hash = hashlib.sha256(path.read_bytes()).hexdigest()
                if actual_hash != provenance[media_type]["sha256"]:
                    invalid.append(f"hash mismatch {path.relative_to(theme)}")
            poster_path = media_paths["poster"]
            if poster_path.is_file():
                try:
                    from PIL import Image

                    with Image.open(poster_path) as poster_image:
                        expected_poster_size = (
                            int(provenance["poster"]["width"]),
                            int(provenance["poster"]["height"]),
                        )
                        if poster_image.size != expected_poster_size:
                            invalid.append(
                                f"poster dimensions {poster_image.size} do not match {expected_poster_size}"
                            )
                except (OSError, TypeError, ValueError) as exc:
                    invalid.append(f"poster metadata could not be verified: {exc}")
            video_path = media_paths["video"]
            ffprobe = shutil.which("ffprobe")
            if video_path.is_file() and ffprobe:
                try:
                    probe = subprocess.run(
                        [
                            ffprobe,
                            "-v",
                            "error",
                            "-show_entries",
                            "format=duration:stream=codec_type,width,height",
                            "-of",
                            "json",
                            str(video_path),
                        ],
                        check=True,
                        capture_output=True,
                        text=True,
                    )
                    video_data = json.loads(probe.stdout)
                    streams = video_data.get("streams", [])
                    video_streams = [stream for stream in streams if stream.get("codec_type") == "video"]
                    audio_streams = [stream for stream in streams if stream.get("codec_type") == "audio"]
                    expected_video_size = (
                        int(provenance["video"]["width"]),
                        int(provenance["video"]["height"]),
                    )
                    actual_video_size = (
                        int(video_streams[0].get("width", 0)),
                        int(video_streams[0].get("height", 0)),
                    ) if video_streams else (0, 0)
                    if actual_video_size != expected_video_size:
                        invalid.append(
                            f"video dimensions {actual_video_size} do not match {expected_video_size}"
                        )
                    if audio_streams or not provenance["video"].get("audio_removed"):
                        invalid.append("factory video must have no audio track")
                    actual_duration = float(video_data.get("format", {}).get("duration", 0))
                    expected_duration = float(provenance["video"]["duration_seconds"])
                    if abs(actual_duration - expected_duration) > 0.05:
                        invalid.append(
                            f"video duration {actual_duration:.3f}s does not match {expected_duration:.3f}s"
                        )
                except (KeyError, TypeError, ValueError, json.JSONDecodeError, subprocess.CalledProcessError) as exc:
                    invalid.append(f"video metadata could not be verified: {exc}")
            elif video_path.is_file():
                invalid.append("ffprobe is required to verify factory video dimensions and audio state")
            source_is_actual = provenance.get("source") == "user_supplied_actual_facility_footage"
            copy_is_factual = all(
                phrase in all_text
                for phrase in (
                    "Actual facility footage",
                    "finished-goods warehouse",
                    "Real warehouse video",
                )
            )
            old_ai_assets = [
                theme / "assets" / "images" / name
                for name in ("factory-assembly.webp", "factory-quality.webp", "factory-packing.webp")
                if (theme / "assets" / "images" / name).exists()
            ]
            if not source_is_actual:
                invalid.append("factory media source is not verified as user supplied")
            if not copy_is_factual:
                invalid.append("factory media copy does not identify the actual warehouse footage")
            if old_ai_assets:
                invalid.append("superseded AI factory images remain packaged")
            if invalid:
                report.fail("content.factory_disclosure", "Factory media provenance verification failed", "; ".join(invalid))
            else:
                report.passed("content.factory_disclosure", "User-supplied facility video and derived poster have verified provenance and hashes")
        except (KeyError, TypeError, json.JSONDecodeError) as exc:
            report.fail("content.factory_disclosure", "Factory media provenance manifest is invalid", str(exc))
    elif factory_assets:
        disclosure = re.search(r"illustration|illustrative|visual reference|artist(?:ic)? rendering|示意|ilustraci[oó]n|ilustra[cç][aã]o", all_text, re.I)
        if disclosure:
            report.passed("content.factory_disclosure", "Factory imagery has an illustration/reference disclosure")
        else:
            report.fail(
                "content.factory_disclosure",
                "Factory media requires either verified provenance or a visible illustration disclosure",
                relative_list(theme, factory_assets[:8]),
            )
    else:
        report.warn("content.factory_disclosure", "No factory-named media asset was found to verify")

    hard_price = re.search(
        r"(?:['\"]price['\"]\s*(?:=>|:)\s*['\"]?\d+(?:\.\d+)?|priceCurrency['\"]?\s*(?:=>|:)\s*['\"](?:USD|EUR|GBP|CNY))",
        all_php,
        re.I,
    )
    hard_availability = re.search(
        r"availability['\"]?\s*(?:=>|:)\s*['\"]https?://schema\.org/(?:InStock|OutOfStock)",
        all_php,
        re.I,
    )
    if hard_price or hard_availability:
        report.fail(
            "content.commercial_schema",
            "Product schema contains a hard-coded price, currency or availability",
        )
    else:
        report.passed("content.commercial_schema", "No unconfirmed commercial values are hard-coded in Product schema")


def check_performance(theme: Path, report: Report, php_files: Sequence[Path], js_files: Sequence[Path]) -> None:
    large: list[str] = []
    total_assets = 0
    for path in iter_files(theme):
        if path.suffix.lower() not in {".css", ".js", ".png", ".jpg", ".jpeg", ".webp", ".avif", ".gif", ".woff", ".woff2"}:
            continue
        size = path.stat().st_size
        total_assets += size
        threshold = 500_000 if path.suffix.lower() in {".css", ".js"} else 1_500_000
        if size > threshold:
            large.append(f"{path.relative_to(theme)} ({size / 1_000_000:.2f} MB)")
    if large:
        report.warn("performance.asset_size", "Large front-end assets may cause slow loading", "\n".join(large))
    else:
        report.passed("performance.asset_size", "No unusually large individual front-end asset was found")
    if total_assets > 25_000_000:
        report.warn("performance.total_assets", f"Front-end assets total {total_assets / 1_000_000:.1f} MB")
    else:
        report.passed("performance.total_assets", f"Front-end assets total {total_assets / 1_000_000:.1f} MB")

    php = combined_text(php_files)
    enqueued_footer = re.search(r"wp_enqueue_script\s*\([^;]*(?:true|['\"]strategy['\"]\s*=>\s*['\"]defer['\"])[^;]*\)", php, re.I | re.S)
    if js_files and not enqueued_footer:
        report.warn("performance.scripts", "Could not confirm that theme scripts load deferred or in the footer")
    else:
        report.passed("performance.scripts", "Theme scripts are absent or load deferred/in the footer")

    template_text = combined_text([path for path in php_files if "template" in str(path) or path.name == "front-page.php"])
    template_text = re.sub(r"<\?php.*?\?>", "PHP_VALUE", template_text, flags=re.S)
    image_tags = re.findall(r"<img\b[^>]*>", template_text, re.I | re.S)
    lazy_count = sum(bool(re.search(r"loading\s*=\s*['\"]lazy['\"]", tag, re.I)) for tag in image_tags)
    if len(image_tags) <= 2 or lazy_count >= max(1, len(image_tags) // 2):
        report.passed("performance.lazy_images", f"Lazy-loading found on {lazy_count}/{len(image_tags)} static image tags")
    else:
        report.warn("performance.lazy_images", f"Only {lazy_count}/{len(image_tags)} static image tags use loading=lazy")


def check_project_i18n_source(report: Report, text_domain: str) -> None:
    path = PROJECT_ROOT / "tools" / "i18n_copy.json"
    if not path.is_file():
        report.warn("i18n.source_copy", "tools/i18n_copy.json is missing; locale key parity was not checked")
        return
    try:
        value = json.loads(read_text(path))
    except json.JSONDecodeError as exc:
        report.fail("i18n.source_copy", "tools/i18n_copy.json is invalid JSON", str(exc))
        return
    locales = value.get("locales", {}) if isinstance(value, dict) else {}
    required = ("en_US", "es_ES", "pt_BR")
    if not all(isinstance(locales.get(locale), dict) for locale in required):
        report.fail("i18n.source_copy", "English, Spanish and Portuguese locale dictionaries are required")
        return
    def flatten(mapping: dict[str, Any], prefix: str = "") -> dict[str, Any]:
        flattened: dict[str, Any] = {}
        for key, item in mapping.items():
            path_key = f"{prefix}.{key}" if prefix else key
            if isinstance(item, dict):
                flattened.update(flatten(item, path_key))
            elif key not in {"language_name", "locale_code"}:
                flattened[path_key] = item
        return flattened

    flattened = {locale: flatten(locales[locale]) for locale in required}
    keysets = {locale: set(flattened[locale]) for locale in required}
    baseline = keysets["en_US"]
    mismatches = {
        locale: sorted(baseline ^ keysets[locale])
        for locale in required[1:]
        if keysets[locale] != baseline
    }
    empty_values = {
        locale: sorted(key for key, item in flattened[locale].items() if not str(item).strip())
        for locale in required
    }
    empty_values = {locale: keys for locale, keys in empty_values.items() if keys}
    meta_domain = str(value.get("_meta", {}).get("text_domain", ""))
    if mismatches or empty_values or (meta_domain and meta_domain != text_domain):
        details = []
        if mismatches:
            details.append("Key differences: " + json.dumps(mismatches, ensure_ascii=False))
        if empty_values:
            details.append("Empty values: " + json.dumps(empty_values, ensure_ascii=False))
        if meta_domain and meta_domain != text_domain:
            details.append(f"Metadata domain {meta_domain!r} differs from style.css {text_domain!r}")
        report.fail("i18n.source_copy", "Locale source dictionaries are inconsistent", "\n".join(details))
    elif len(baseline) < 50:
        report.fail("i18n.source_copy", "Locale source dictionaries are unexpectedly small", str(len(baseline)))
    else:
        report.passed(
            "i18n.source_copy",
            f"English, Spanish and Portuguese share {len(baseline)} complete UI keys",
        )


def check_woocommerce_import(report: Report) -> None:
    delivery = PROJECT_ROOT / "dist" / "woocommerce-import"
    product_files = sorted(delivery.glob("*products*.csv")) if delivery.exists() else []
    config_files = sorted(delivery.glob("*configurations*.csv")) if delivery.exists() else []
    if not product_files or not config_files:
        report.warn(
            "delivery.woocommerce_csv",
            "WooCommerce product/configuration CSV delivery files are not both present",
        )
        return
    try:
        with product_files[0].open(encoding="utf-8-sig", newline="") as handle:
            products = list(csv.DictReader(handle))
        with config_files[0].open(encoding="utf-8-sig", newline="") as handle:
            configurations = list(csv.DictReader(handle))
    except (OSError, csv.Error, UnicodeDecodeError) as exc:
        report.fail("delivery.woocommerce_csv", "Could not parse WooCommerce delivery CSV", str(exc))
        return

    required_headers = {
        "Type",
        "SKU",
        "Name",
        "Published",
        "Visibility in catalog",
        "Short description",
        "Description",
        "Regular price",
        "Categories",
        "Tags",
        "Images",
    }
    missing_headers = sorted(required_headers - set(products[0] if products else {}))
    if len(products) != EXPECTED_SERIES or len(configurations) != EXPECTED_CONFIGURATIONS or missing_headers:
        report.fail(
            "delivery.woocommerce_csv",
            "WooCommerce delivery CSV shape is incorrect",
            f"Products: {len(products)}; configurations: {len(configurations)}; missing headers: {missing_headers}",
        )
    else:
        report.passed(
            "delivery.woocommerce_csv",
            "WooCommerce CSV contains 18 draft products and 58 configuration records",
        )

    published = [row.get("Published", "").strip() for row in products]
    non_draft = [value for value in published if value not in {"-1", "0", "draft", "Draft"}]
    priced = [row.get("SKU", "") for row in products if row.get("Regular price", "").strip() or row.get("Sale price", "").strip()]
    if non_draft or priced:
        report.fail(
            "delivery.commercial_safety",
            "Unconfirmed products must remain drafts with blank prices",
            f"Non-draft values: {non_draft}; priced SKUs: {priced}",
        )
    else:
        report.passed("delivery.commercial_safety", "All import products are drafts with blank prices")

    image_dir = delivery / "product-images"
    missing_images: list[str] = []
    referenced_images: set[str] = set()
    for row in products:
        for name in (item.strip() for item in row.get("Images", "").split(",")):
            if name:
                referenced_images.add(name)
            if name and not (image_dir / name).is_file():
                missing_images.append(name)
    if missing_images:
        report.fail("delivery.product_images", "WooCommerce CSV references missing images", "\n".join(missing_images))
    else:
        report.passed("delivery.product_images", "Every WooCommerce CSV image reference exists")

    mapped_images = {
        row.get("media_library_filename", "").strip()
        for row in configurations
        if row.get("media_library_filename", "").strip()
    }
    missing_mapped = sorted(name for name in mapped_images if not (image_dir / name).is_file())
    if len(mapped_images) != EXPECTED_CONFIGURATIONS or missing_mapped:
        report.fail(
            "delivery.configuration_images",
            "The 58 configuration records must each map to a packaged media file",
            f"Mapped names: {len(mapped_images)}; missing: {', '.join(missing_mapped)}",
        )
        return

    corrupt: list[str] = []
    hash_mismatches: list[str] = []
    unique_hashes: set[str] = set()
    try:
        from hashlib import sha256
        from PIL import Image

        rows_by_name = {row["media_library_filename"].strip(): row for row in configurations}
        for name in sorted(mapped_images):
            path = image_dir / name
            try:
                with Image.open(path) as image:
                    image.verify()
                digest = sha256(path.read_bytes()).hexdigest()
                unique_hashes.add(digest)
                row = rows_by_name[name]
                expected = (row.get("output_sha256") or row.get("sha256") or "").strip().lower()
                if expected and digest != expected:
                    hash_mismatches.append(f"{name}: expected {expected}; found {digest}")
            except Exception as exc:
                corrupt.append(f"{name}: {exc}")
    except ImportError:
        unique_hashes = {str((image_dir / name).stat().st_size) + name for name in mapped_images}
        report.warn("delivery.images_decoder", "Pillow is unavailable; image decoding was not verified")

    if corrupt:
        report.fail("delivery.images_decode", "One or more configuration images cannot be decoded", "\n".join(corrupt))
    elif hash_mismatches:
        report.fail("delivery.images_hash", "Configuration image hashes do not match their mapping", "\n".join(hash_mismatches))
    elif len(unique_hashes) != EXPECTED_CONFIGURATIONS:
        report.fail(
            "delivery.images_unique",
            "Configuration media must contain 58 unique binaries",
            f"Files: {len(mapped_images)}; unique hashes: {len(unique_hashes)}",
        )
    else:
        report.passed(
            "delivery.configuration_images",
            "Decoded and hash-verified 58 unique configuration images in the import package",
        )

    extra_media = {
        path.name
        for path in image_dir.iterdir()
        if path.is_file() and path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".avif"}
    } - referenced_images
    if extra_media:
        report.warn(
            "delivery.unreferenced_media",
            "The import package contains media that is not referenced by the product CSV",
            f"Unreferenced files: {len(extra_media)}",
        )
    else:
        report.passed("delivery.media_mapping", "All packaged product media is referenced by the product CSV")


def _browser_script() -> str:
    return """() => {
      const root = document.documentElement;
      const body = document.body;
      const width = Math.max(root.scrollWidth, body ? body.scrollWidth : 0);
      const overflow = Math.max(0, width - window.innerWidth);
      const offenders = [...document.querySelectorAll('body *')]
        .filter((el) => {
          const r = el.getBoundingClientRect();
          return r.right > window.innerWidth + 1 || r.left < -1;
        })
        .slice(0, 12)
        .map((el) => ({
          tag: el.tagName.toLowerCase(),
          id: el.id || '',
          classes: typeof el.className === 'string' ? el.className.slice(0, 100) : '',
          left: Math.round(el.getBoundingClientRect().left),
          right: Math.round(el.getBoundingClientRect().right)
        }));
      return { width, viewport: window.innerWidth, overflow, offenders };
    }"""


def check_browser(url: str, report: Report) -> None:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        report.warn("browser.available", "Python Playwright is unavailable; browser checks were skipped")
        return

    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https", "file"}:
        report.fail("browser.url", "Browser URL must use http, https or file")
        return

    static_server: http.server.ThreadingHTTPServer | None = None
    if parsed.scheme == "file":
        file_path = Path(unquote(parsed.path)).resolve()
        if not file_path.is_file():
            report.fail("browser.url", "Static preview file does not exist", str(file_path))
            return

        class QuietHandler(http.server.SimpleHTTPRequestHandler):
            def log_message(self, _format: str, *args: Any) -> None:
                return

        handler = functools.partial(QuietHandler, directory=str(file_path.parent))
        static_server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
        threading.Thread(target=static_server.serve_forever, daemon=True).start()
        url = f"http://127.0.0.1:{static_server.server_port}/{quote(file_path.name)}"

    console_errors: set[str] = set()
    page_errors: set[str] = set()
    overflow_failures: list[str] = []
    broken_images: set[str] = set()
    accessibility_errors: set[str] = set()
    shopify_requests: set[str] = set()
    failed_requests: set[str] = set()
    reduced_animations: int | None = None
    layout_shift = 0.0
    long_task_ms = 0.0
    chromium_path = shutil.which("chromium") or shutil.which("chromium-browser")

    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(
                headless=True,
                executable_path=chromium_path,
                args=["--disable-gpu", "--no-sandbox"],
            )
            for width, height in ((320, 720), (360, 800), (390, 844), (768, 1024), (1024, 900), (1440, 1000)):
                context = browser.new_context(viewport={"width": width, "height": height})
                context.add_init_script(
                    """(() => {
                      window.__xiujinMetrics = { cls: 0, longTask: 0 };
                      try {
                        new PerformanceObserver((list) => {
                          for (const entry of list.getEntries()) {
                            if (!entry.hadRecentInput) window.__xiujinMetrics.cls += entry.value;
                          }
                        }).observe({ type: 'layout-shift', buffered: true });
                      } catch (error) {}
                      try {
                        new PerformanceObserver((list) => {
                          for (const entry of list.getEntries()) window.__xiujinMetrics.longTask += entry.duration;
                        }).observe({ type: 'longtask', buffered: true });
                      } catch (error) {}
                    })()"""
                )
                page = context.new_page()
                page.on("console", lambda msg: console_errors.add(msg.text) if msg.type == "error" else None)
                page.on("pageerror", lambda error: page_errors.add(str(error)))
                page.on(
                    "request",
                    lambda request: shopify_requests.add(request.url)
                    if re.search(r"(?:myshopify\.com|cdn\.shopify\.com)", request.url, re.I)
                    else None,
                )
                page.on("requestfailed", lambda request: failed_requests.add(request.url))
                page.goto(url, wait_until="domcontentloaded", timeout=45_000)
                page.wait_for_timeout(900)
                result = page.evaluate(_browser_script())
                if result["overflow"] > 1:
                    overflow_failures.append(
                        f"{width}px viewport: {result['overflow']}px overflow; "
                        + json.dumps(result["offenders"], ensure_ascii=False)
                    )
                if width == 390:
                    page_data = page.evaluate(
                        """() => ({
                          h1: document.querySelectorAll('h1').length,
                          main: document.querySelectorAll('main').length,
                          nav: document.querySelectorAll('nav').length,
                          broken: [...document.images]
                            .filter((img) => img.complete && img.naturalWidth === 0)
                            .map((img) => img.currentSrc || img.src || img.alt || '(unknown)'),
                          imagesWithoutAlt: [...document.images]
                            .filter((img) => !img.hasAttribute('alt'))
                            .map((img) => img.currentSrc || img.src || '(unknown)'),
                          placeholderSocial: [...document.querySelectorAll('a')]
                            .filter((a) => /facebook|instagram|tiktok|whatsapp|messenger/i.test(
                              `${a.textContent} ${a.getAttribute('aria-label') || ''} ${a.className}`
                            ) && (!a.getAttribute('href') || a.getAttribute('href') === '#'))
                            .map((a) => a.outerHTML.slice(0, 180)),
                          visible8011: (document.body.innerText || '').includes('8011'),
                          metrics: window.__xiujinMetrics || { cls: 0, longTask: 0 }
                        })"""
                    )
                    broken_images.update(page_data["broken"])
                    if page_data["h1"] != 1:
                        accessibility_errors.add(f"Expected one H1, found {page_data['h1']}")
                    if page_data["main"] != 1:
                        accessibility_errors.add(f"Expected one main landmark, found {page_data['main']}")
                    if page_data["nav"] < 1:
                        accessibility_errors.add("No navigation landmark found")
                    if page_data["imagesWithoutAlt"]:
                        accessibility_errors.add(
                            "Images without alt: " + ", ".join(page_data["imagesWithoutAlt"][:8])
                        )
                    if page_data["placeholderSocial"]:
                        accessibility_errors.add(
                            "Placeholder social links: " + ", ".join(page_data["placeholderSocial"][:5])
                        )
                    if page_data["visible8011"]:
                        accessibility_errors.add("Removed model number 8011 remains in visible homepage text")
                    layout_shift = float(page_data["metrics"].get("cls", 0))
                    long_task_ms = float(page_data["metrics"].get("longTask", 0))
                context.close()

            context = browser.new_context(
                viewport={"width": 390, "height": 844},
                reduced_motion="reduce",
            )
            page = context.new_page()
            page.goto(url, wait_until="domcontentloaded", timeout=45_000)
            page.wait_for_timeout(1000)
            reduced_animations = page.evaluate(
                """() => document.getAnimations().filter((animation) => {
                  const timing = animation.effect && animation.effect.getComputedTiming
                    ? animation.effect.getComputedTiming() : null;
                  return animation.playState === 'running' && timing &&
                    (timing.iterations === Infinity || timing.duration > 100);
                }).length"""
            )
            context.close()
            browser.close()
    except Exception as exc:  # Browser failures should have a useful report, not a traceback.
        report.fail("browser.run", "Browser validation failed", str(exc))
        return
    finally:
        if static_server:
            static_server.shutdown()

    if overflow_failures:
        report.fail("browser.overflow", "Rendered page has horizontal overflow", "\n".join(overflow_failures))
    else:
        report.passed("browser.overflow", "No horizontal overflow at 320, 360, 390, 768, 1024 and 1440px")
    if reduced_animations:
        report.fail(
            "browser.reduced_motion",
            f"{reduced_animations} long-running animation(s) remain with reduced motion enabled",
        )
    else:
        report.passed("browser.reduced_motion", "No long-running animation remains in reduced-motion mode")
    if page_errors or console_errors:
        details = [f"Page error: {item}" for item in sorted(page_errors)]
        details.extend(f"Console error: {item}" for item in sorted(console_errors))
        report.fail("browser.console", "Rendered page emitted JavaScript/console errors", "\n".join(details[:20]))
    else:
        report.passed("browser.console", "Rendered page emitted no JavaScript console errors")
    if broken_images:
        report.fail("browser.images", "Rendered page contains broken images", "\n".join(sorted(broken_images)))
    else:
        report.passed("browser.images", "All rendered images decoded successfully")
    if accessibility_errors:
        report.fail(
            "browser.accessibility",
            "Rendered semantic/accessibility checks failed",
            "\n".join(sorted(accessibility_errors)),
        )
    else:
        report.passed("browser.accessibility", "Rendered page has one H1, landmarks and image alt text")
    if shopify_requests:
        report.fail(
            "browser.shopify_requests",
            "WordPress preview made a Shopify network request",
            "\n".join(sorted(shopify_requests)),
        )
    else:
        report.passed("browser.shopify_requests", "Rendered page made no Shopify network requests")
    if failed_requests:
        report.warn("browser.failed_requests", "Rendered page had failed network requests", "\n".join(sorted(failed_requests)))
    else:
        report.passed("browser.failed_requests", "Rendered page had no failed network requests")
    if layout_shift > 0.1:
        report.fail("browser.cls", "Cumulative layout shift exceeds 0.1", f"CLS: {layout_shift:.4f}")
    else:
        report.passed("browser.cls", f"Cumulative layout shift is within budget ({layout_shift:.4f})")
    if long_task_ms > 600:
        report.warn("browser.long_tasks", "Main-thread long tasks may cause visible jank", f"Total: {long_task_ms:.0f} ms")
    else:
        report.passed("browser.long_tasks", f"Main-thread long-task time is within budget ({long_task_ms:.0f} ms)")


def auto_preview_url(theme: Path) -> str | None:
    candidates = (
        PROJECT_ROOT / "preview" / "index.html",
        theme / "preview" / "index.html",
        PROJECT_ROOT / "static-preview" / "index.html",
    )
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve().as_uri()
    return None


def validate(theme: Path, report: Report, browser_url: str | None) -> None:
    php_files = list(iter_files(theme, {".php"}))
    css_files = list(iter_files(theme, {".css"}))
    js_files = list(iter_files(theme, {".js"}))
    text_files = list(iter_files(theme, TEXT_SUFFIXES))
    all_php = combined_text(php_files)
    all_text = combined_text(text_files)

    report.passed("theme.detected", "Theme directory detected", str(theme))
    text_domain = check_theme_files(theme, report)
    check_theme_hygiene(theme, report, text_files)
    check_php_structure(theme, report, php_files, all_php)
    check_php_lint(theme, report, php_files)
    check_literal_assets(theme, report, text_files)
    check_i18n(theme, report, php_files, all_php, text_domain)
    check_seo(theme, report, all_text, all_php)
    check_responsive_and_motion(theme, report, css_files, js_files)
    check_catalog(theme, report, text_files)
    check_social(theme, report, all_text, all_php)
    check_woocommerce(theme, report, all_php)
    check_quote_security(theme, report, all_php)
    check_accessibility_static(theme, report, php_files, all_php)
    check_content_requirements(theme, report, all_text, all_php)
    check_performance(theme, report, php_files, js_files)
    check_project_i18n_source(report, text_domain)
    check_woocommerce_import(report)

    if browser_url:
        check_browser(browser_url, report)
    else:
        report.warn(
            "browser.skipped",
            "Rendered browser checks were skipped; pass --url or add preview/index.html",
        )


def parse_args(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("theme", nargs="?", help="Path to the WordPress theme directory")
    parser.add_argument("--url", help="Rendered site/preview URL for browser checks")
    parser.add_argument("--json", dest="json_path", help="Write a machine-readable JSON report")
    parser.add_argument(
        "--strict-warnings",
        action="store_true",
        help="Return non-zero when warnings are present",
    )
    parser.add_argument(
        "--no-auto-preview",
        action="store_true",
        help="Do not automatically test preview/index.html when present",
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv if argv is not None else sys.argv[1:])
    report = Report()
    theme = discover_theme(args.theme)
    browser_url = args.url

    if theme is None:
        report.fail(
            "theme.detected",
            "Could not find a WordPress theme directory",
            "Pass the theme path explicitly after the script name.",
        )
    else:
        if not browser_url and not args.no_auto_preview:
            browser_url = auto_preview_url(theme)
        validate(theme, report, browser_url)

    report.write_console()
    if args.json_path:
        output = Path(args.json_path).expanduser()
        if not output.is_absolute():
            output = Path.cwd() / output
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(
            json.dumps(report.to_json(theme, browser_url), ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        print(f"JSON report: {output}")

    counts = report.counts()
    if counts["FAIL"]:
        return 1
    if args.strict_warnings and counts["WARN"]:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
