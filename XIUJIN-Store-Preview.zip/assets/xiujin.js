(() => {
  let revealObserver;
  const init = (root = document) => {
    root.querySelectorAll('[data-menu-toggle]').forEach(button => {
      if (button.dataset.ready) return;
      button.dataset.ready = 'true';
      button.addEventListener('click', () => {
        const menu = document.getElementById(button.getAttribute('aria-controls'));
        if (!menu) return;
        const open = button.getAttribute('aria-expanded') === 'true';
        button.setAttribute('aria-expanded', String(!open));
        menu.hidden = open;
      });
    });
    root.querySelectorAll('[data-mobile-menu] a').forEach(link => {
      if (link.dataset.ready) return;
      link.dataset.ready = 'true';
      link.addEventListener('click', () => {
        const menu = link.closest('[data-mobile-menu]');
        menu.hidden = true;
        document.querySelectorAll('[data-menu-toggle]').forEach(button => button.setAttribute('aria-expanded', 'false'));
      });
    });
    root.querySelectorAll('[data-enquiry-product]').forEach(link => {
      if (link.dataset.ready) return;
      link.dataset.ready = 'true';
      link.addEventListener('click', () => {
        const form = document.querySelector('[data-quote-form]');
        const input = form?.querySelector('[data-product-field]');
        if (input) input.value = link.dataset.enquiryProduct;
      });
    });
    root.querySelectorAll('[data-showroom]').forEach(showroom => {
      if (showroom.dataset.ready) return;
      showroom.dataset.ready = 'true';
      const track = showroom.querySelector('[data-showroom-track]');
      if (!track) return;
      showroom.querySelectorAll('[data-showroom-direction]').forEach(button => {
        button.addEventListener('click', () => {
          const direction = Number(button.dataset.showroomDirection || 1);
          const distance = Math.max(280, track.clientWidth * 0.82);
          const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
          track.scrollBy({ left: distance * direction, behavior: reduced ? 'auto' : 'smooth' });
        });
      });
    });
    root.querySelectorAll('[data-gallery-thumbnail]').forEach(button => {
      if (button.dataset.ready) return;
      button.dataset.ready = 'true';
      button.addEventListener('click', () => {
        const gallery = button.closest('[data-gallery]');
        const main = gallery?.querySelector('[data-gallery-main]');
        if (!main) return;
        main.src = button.dataset.image;
        main.srcset = '';
        main.alt = button.dataset.alt || '';
        gallery.querySelectorAll('[data-gallery-thumbnail]').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
      });
    });
    root.querySelectorAll('[data-retail-variant]').forEach(select => {
      if (select.dataset.ready) return;
      select.dataset.ready = 'true';
      select.addEventListener('change', () => {
        const option = select.selectedOptions[0];
        const form = select.closest('[data-retail-form]');
        const price = form?.parentElement.querySelector('[data-retail-price]');
        const button = form?.querySelector('[name="add"]');
        if (price && option?.dataset.price) price.textContent = option.dataset.price;
        if (button && option) {
          const available = option.dataset.available === 'true';
          button.disabled = !available;
          button.textContent = available ? (button.dataset.addText || 'Add to cart') : (button.dataset.soldText || 'Sold out');
        }
      });
    });
    const revealTargets = root.querySelectorAll('.section-heading,.category-card,.showroom-card,.product-card,.option-item,.step,.quote-copy,.quote-form,.model-copy,.model-panel');
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window)) {
      revealTargets.forEach(target => target.classList.add('is-visible'));
    } else {
      document.documentElement.classList.add('motion-enabled');
      if (!revealObserver) revealObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add('is-visible');
          revealObserver.unobserve(entry.target);
        });
      }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
      revealTargets.forEach((target, index) => {
        if (target.dataset.revealReady) return;
        target.dataset.revealReady = 'true';
        target.dataset.reveal = '';
        target.style.setProperty('--reveal-delay', `${Math.min(index % 4, 3) * 70}ms`);
        revealObserver.observe(target);
      });
    }
    if (document.body.dataset.preview === 'true') {
      root.querySelectorAll('[data-quote-form]').forEach(form => {
        if (form.dataset.ready) return;
        form.dataset.ready = 'true';
        form.addEventListener('submit', event => {
          event.preventDefault();
          const status = form.querySelector('[data-preview-status]');
          if (status) { status.hidden = false; status.focus(); }
        });
      });
    }
  };
  document.addEventListener('DOMContentLoaded', () => init());
  document.addEventListener('shopify:section:load', event => init(event.target));
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    const menu = document.querySelector('[data-mobile-menu]:not([hidden])');
    if (menu) {
      menu.hidden = true;
      const toggle = document.querySelector('[data-menu-toggle]');
      toggle?.setAttribute('aria-expanded', 'false');
      toggle?.focus();
    }
  });
})();
