=== XIUJIN Store Core ===
Contributors: xiujin
Tags: woocommerce, wholesale, retail, quotation, product enquiry
Requires at least: 6.4
Requires PHP: 8.1
Requires Plugins: woocommerce
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Keeps XIUJIN wholesale and retail product settings independent from the active theme and provides a secure quotation form.

== Description ==

XIUJIN Store Core adds sales mode, minimum order quantity, lead time and internal configuration reference fields to WooCommerce products. Wholesale-only products use an enquiry path while retail and combined products retain standard WooCommerce purchasing.

The `[xiujin_inquiry_form]` shortcode outputs an accessible, product-aware form protected by a nonce, honeypot, signed timing check, server-side validation and privacy-preserving rate limits. Valid enquiries are sent as plain-text email and are not stored in the WordPress database.

== Installation ==

1. Install and activate WooCommerce.
2. Upload and activate the XIUJIN Store Core ZIP.
3. Open Settings > XIUJIN enquiries and enter the sales recipient email.
4. Test email delivery before launch.
5. Edit each product and choose its sales mode.

== Changelog ==

= 1.0.0 =
* Initial release.

