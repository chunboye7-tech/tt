<?php
/**
 * Remove plugin-owned settings when the plugin is deleted.
 *
 * @package XiujinStoreCore
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'xiujin_inquiry_recipient_email' );

