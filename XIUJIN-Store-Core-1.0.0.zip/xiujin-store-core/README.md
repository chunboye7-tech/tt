# XIUJIN Store Core

Companion plugin for the XIUJIN Furniture WordPress theme.

## Features

- Keeps wholesale/retail mode, MOQ, lead time and internal configuration IDs outside the theme.
- Disables direct checkout for wholesale-only products while preserving ordinary WooCommerce checkout for retail products.
- Adds the `[xiujin_inquiry_form]` shortcode.
- Protects enquiries with a WordPress nonce, honeypot, signed timing check, hourly rate limit, server-side validation and safe plain-text email headers.
- Sends no enquiry until the visitor explicitly submits the form and accepts the consent statement.
- Does not store enquiry contents in the WordPress database.

## Setup

1. Install and activate WooCommerce.
2. Upload and activate this plugin ZIP.
3. Go to **Settings → XIUJIN enquiries** and set the sales recipient.
4. Test outbound email delivery before launch. A transactional SMTP provider is recommended for production.
5. Edit each WooCommerce product and choose its sales mode. Leave price empty for quotation-only products; never enter a placeholder zero price.

The shortcode can be placed on any page. Product links append a product ID so the homepage enquiry form is prefilled automatically.

