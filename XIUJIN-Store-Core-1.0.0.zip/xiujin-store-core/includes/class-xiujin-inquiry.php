<?php
/**
 * Secure, privacy-conscious product enquiry form.
 *
 * @package XiujinStoreCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the enquiry shortcode, handler and recipient setting.
 */
final class Xiujin_Inquiry {
	const OPTION_RECIPIENT = 'xiujin_inquiry_recipient_email';
	const ACTION           = 'xiujin_submit_inquiry';
	const NONCE_ACTION     = 'xiujin_inquiry_submit';
	const NONCE_NAME       = '_xiujin_inquiry_nonce';
	const RATE_LIMIT       = 5;
	const IP_RATE_LIMIT    = 10;

	/**
	 * Attach hooks.
	 */
	public static function register() {
		add_shortcode( 'xiujin_inquiry_form', array( __CLASS__, 'render_shortcode' ) );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle_submission' ) );
		add_action( 'admin_post_nopriv_' . self::ACTION, array( __CLASS__, 'handle_submission' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_styles' ) );
		add_action( 'admin_menu', array( __CLASS__, 'register_settings_page' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * Load the small form stylesheet.
	 */
	public static function enqueue_styles() {
		wp_enqueue_style(
			'xiujin-store-core',
			XIUJIN_STORE_CORE_URL . 'assets/css/inquiry.css',
			array(),
			XIUJIN_STORE_CORE_VERSION
		);
	}

	/**
	 * Render a product-aware enquiry form.
	 *
	 * @param array $attributes Shortcode attributes.
	 * @return string
	 */
	public static function render_shortcode( $attributes ) {
		$attributes = shortcode_atts(
			array(
				'product'      => '',
				'button_label' => esc_html__( 'Send enquiry', 'xiujin-store-core' ),
			),
			$attributes,
			'xiujin_inquiry_form'
		);

		$product_name = sanitize_text_field( $attributes['product'] );
		$product_id   = isset( $_GET['product_id'] ) ? absint( wp_unslash( $_GET['product_id'] ) ) : 0;
		if ( ! $product_name && $product_id && 'product' === get_post_type( $product_id ) && 'publish' === get_post_status( $product_id ) ) {
			$product_name = get_the_title( $product_id );
		}

		if ( ! $product_name && function_exists( 'is_product' ) && is_product() ) {
			$product_name = get_the_title();
		}

		$status  = isset( $_GET['xiujin_inquiry'] ) ? sanitize_key( wp_unslash( $_GET['xiujin_inquiry'] ) ) : '';
		$started = time();
		$stamp   = self::sign_timestamp( $started );
		$form_id = wp_unique_id( 'xiujin-inquiry-' );

		ob_start();
		?>
		<div class="xiujin-inquiry-wrap">
			<?php self::render_status_message( $status ); ?>
			<form id="<?php echo esc_attr( $form_id ); ?>" class="xiujin-inquiry-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" accept-charset="UTF-8">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
				<input type="hidden" name="xiujin_started" value="<?php echo esc_attr( (string) $started ); ?>">
				<input type="hidden" name="xiujin_stamp" value="<?php echo esc_attr( $stamp ); ?>">
				<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>

				<div class="xiujin-inquiry-trap" aria-hidden="true">
					<label for="<?php echo esc_attr( $form_id ); ?>-website"><?php esc_html_e( 'Leave this field empty', 'xiujin-store-core' ); ?></label>
					<input id="<?php echo esc_attr( $form_id ); ?>-website" name="website" type="text" value="" tabindex="-1" autocomplete="off">
				</div>

				<div class="xiujin-inquiry-grid">
					<p class="xiujin-inquiry-field xiujin-inquiry-field--wide">
						<label for="<?php echo esc_attr( $form_id ); ?>-product"><?php esc_html_e( 'Product or chair category', 'xiujin-store-core' ); ?> <span aria-hidden="true">*</span></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-product" name="product" type="text" value="<?php echo esc_attr( $product_name ); ?>" maxlength="160" required autocomplete="off">
					</p>

					<p class="xiujin-inquiry-field">
						<label for="<?php echo esc_attr( $form_id ); ?>-quantity"><?php esc_html_e( 'Estimated quantity', 'xiujin-store-core' ); ?> <span aria-hidden="true">*</span></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-quantity" name="quantity" type="number" min="1" max="100000000" step="1" required inputmode="numeric">
					</p>

					<p class="xiujin-inquiry-field">
						<label for="<?php echo esc_attr( $form_id ); ?>-destination"><?php esc_html_e( 'Destination country or port', 'xiujin-store-core' ); ?> <span aria-hidden="true">*</span></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-destination" name="destination" type="text" maxlength="160" required autocomplete="country-name">
					</p>

					<p class="xiujin-inquiry-field">
						<label for="<?php echo esc_attr( $form_id ); ?>-company"><?php esc_html_e( 'Company', 'xiujin-store-core' ); ?></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-company" name="company" type="text" maxlength="160" autocomplete="organization">
					</p>

					<p class="xiujin-inquiry-field">
						<label for="<?php echo esc_attr( $form_id ); ?>-name"><?php esc_html_e( 'Contact name', 'xiujin-store-core' ); ?> <span aria-hidden="true">*</span></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-name" name="name" type="text" maxlength="120" required autocomplete="name">
					</p>

					<p class="xiujin-inquiry-field">
						<label for="<?php echo esc_attr( $form_id ); ?>-email"><?php esc_html_e( 'Business email', 'xiujin-store-core' ); ?> <span aria-hidden="true">*</span></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-email" name="email" type="email" maxlength="190" required autocomplete="email">
					</p>

					<p class="xiujin-inquiry-field">
						<label for="<?php echo esc_attr( $form_id ); ?>-whatsapp"><?php esc_html_e( 'WhatsApp or phone', 'xiujin-store-core' ); ?></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-whatsapp" name="whatsapp" type="tel" maxlength="80" autocomplete="tel">
					</p>

					<p class="xiujin-inquiry-field xiujin-inquiry-field--wide">
						<label for="<?php echo esc_attr( $form_id ); ?>-requirements"><?php esc_html_e( 'Configuration and order requirements', 'xiujin-store-core' ); ?> <span aria-hidden="true">*</span></label>
						<textarea id="<?php echo esc_attr( $form_id ); ?>-requirements" name="requirements" rows="5" minlength="10" maxlength="2000" required></textarea>
					</p>
				</div>

				<label class="xiujin-inquiry-consent">
					<input type="checkbox" name="consent" value="1" required>
					<span><?php echo wp_kses_post( self::consent_copy() ); ?></span>
				</label>

				<p class="xiujin-inquiry-note"><?php esc_html_e( 'Required fields are marked with an asterisk. Product specifications, availability, lead time and pricing are confirmed in the quotation.', 'xiujin-store-core' ); ?></p>
				<button class="button button--gold xiujin-inquiry-submit" type="submit"><?php echo esc_html( $attributes['button_label'] ); ?></button>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Return localized consent copy, including the privacy-policy link when set.
	 *
	 * @return string
	 */
	private static function consent_copy() {
		$privacy_url = get_privacy_policy_url();
		if ( $privacy_url ) {
			return sprintf(
				/* translators: %s: privacy policy URL. */
				__( 'I agree that XIUJIN may use these details to respond to my enquiry. Read the <a href="%s" target="_blank" rel="privacy-policy noopener">privacy policy</a>.', 'xiujin-store-core' ),
				esc_url( $privacy_url )
			);
		}

		return esc_html__( 'I agree that XIUJIN may use these details to respond to my enquiry.', 'xiujin-store-core' );
	}

	/**
	 * Show an allowlisted result message.
	 *
	 * @param string $status Status slug.
	 */
	private static function render_status_message( $status ) {
		$messages = array(
			'success'      => array( 'success', esc_html__( 'Thank you. Your enquiry has been sent to our sales team.', 'xiujin-store-core' ) ),
			'invalid'      => array( 'error', esc_html__( 'Please review the required fields and try again.', 'xiujin-store-core' ) ),
			'expired'      => array( 'error', esc_html__( 'The form expired. Please reload the page and try again.', 'xiujin-store-core' ) ),
			'rate_limited' => array( 'error', esc_html__( 'Too many enquiries were submitted. Please wait before trying again.', 'xiujin-store-core' ) ),
			'failed'       => array( 'error', esc_html__( 'We could not send the enquiry. Please contact us by email or WhatsApp.', 'xiujin-store-core' ) ),
		);

		if ( ! isset( $messages[ $status ] ) ) {
			return;
		}

		printf(
			'<div class="xiujin-inquiry-message xiujin-inquiry-message--%1$s" role="status" aria-live="polite">%2$s</div>',
			esc_attr( $messages[ $status ][0] ),
			esc_html( $messages[ $status ][1] )
		);
	}

	/**
	 * Validate, rate limit and send a plain-text enquiry email.
	 */
	public static function handle_submission() {
		if ( 'POST' !== strtoupper( isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '' ) ) {
			self::redirect_with_status( 'invalid' );
		}

		$nonce = isset( $_POST[ self::NONCE_NAME ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::NONCE_NAME ] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			self::redirect_with_status( 'expired' );
		}

		$honeypot = isset( $_POST['website'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['website'] ) ) ) : '';
		if ( '' !== $honeypot ) {
			self::redirect_with_status( 'success' );
		}

		$started = isset( $_POST['xiujin_started'] ) ? absint( wp_unslash( $_POST['xiujin_started'] ) ) : 0;
		$stamp   = isset( $_POST['xiujin_stamp'] ) ? sanitize_text_field( wp_unslash( $_POST['xiujin_stamp'] ) ) : '';
		$age     = time() - $started;
		if ( ! $started || ! hash_equals( self::sign_timestamp( $started ), $stamp ) || $age < 2 || $age > DAY_IN_SECONDS ) {
			self::redirect_with_status( 'expired' );
		}

		$data = self::validated_submission();
		if ( ! $data ) {
			self::redirect_with_status( 'invalid' );
		}

		if ( self::is_rate_limited( $data['email'] ) ) {
			self::redirect_with_status( 'rate_limited' );
		}

		$recipient = self::recipient_email();
		if ( ! is_email( $recipient ) ) {
			self::redirect_with_status( 'failed' );
		}

		/* translators: %s: requested product or category. */
		$subject = sprintf( __( 'New XIUJIN enquiry: %s', 'xiujin-store-core' ), $data['product'] );
		$subject = str_replace( array( "\r", "\n" ), '', $subject );
		$message = self::email_body( $data );
		$name    = str_replace( array( "\r", "\n", '<', '>' ), '', $data['name'] );
		$headers = array(
			'Content-Type: text/plain; charset=UTF-8',
			sprintf( 'Reply-To: %s <%s>', $name, $data['email'] ),
		);

		$sent = wp_mail( $recipient, $subject, $message, $headers );
		self::redirect_with_status( $sent ? 'success' : 'failed' );
	}

	/**
	 * Return sanitized data only when required fields are valid.
	 *
	 * @return array|false
	 */
	private static function validated_submission() {
		$data = array(
			'product'      => self::post_text( 'product', 160 ),
			'quantity'     => isset( $_POST['quantity'] ) ? absint( wp_unslash( $_POST['quantity'] ) ) : 0,
			'destination'  => self::post_text( 'destination', 160 ),
			'company'      => self::post_text( 'company', 160 ),
			'name'         => self::post_text( 'name', 120 ),
			'email'        => isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '',
			'whatsapp'     => self::post_text( 'whatsapp', 80 ),
			'requirements' => isset( $_POST['requirements'] ) ? sanitize_textarea_field( wp_unslash( $_POST['requirements'] ) ) : '',
			'consent'      => isset( $_POST['consent'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['consent'] ) ),
		);

		$data['requirements'] = function_exists( 'mb_substr' ) ? mb_substr( $data['requirements'], 0, 2000 ) : substr( $data['requirements'], 0, 2000 );

		if (
			! $data['product'] ||
			$data['quantity'] < 1 ||
			$data['quantity'] > 100000000 ||
			! $data['destination'] ||
			! $data['name'] ||
			! is_email( $data['email'] ) ||
			self::text_length( $data['requirements'] ) < 10 ||
			! $data['consent']
		) {
			return false;
		}

		return $data;
	}

	/**
	 * Read and length-limit one plain-text POST value.
	 *
	 * @param string $key    Field key.
	 * @param int    $length Maximum characters.
	 * @return string
	 */
	private static function post_text( $key, $length ) {
		$value = isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, $length ) : substr( $value, 0, $length );
	}

	/**
	 * Count text characters when the multibyte extension is available.
	 *
	 * @param string $value Text to count.
	 * @return int
	 */
	private static function text_length( $value ) {
		return function_exists( 'mb_strlen' ) ? mb_strlen( $value ) : strlen( $value );
	}

	/**
	 * Create a signed form-start timestamp.
	 *
	 * @param int $started Unix timestamp.
	 * @return string
	 */
	private static function sign_timestamp( $started ) {
		return hash_hmac( 'sha256', (string) $started, wp_salt( 'nonce' ) );
	}

	/**
	 * Apply privacy-preserving per-address and per-email hourly limits.
	 *
	 * @param string $email Validated email address.
	 * @return bool
	 */
	private static function is_rate_limited( $email ) {
		$ip       = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
		$salt      = wp_salt( 'auth' );
		$email_key = 'xiujin_em_' . substr( hash_hmac( 'sha256', strtolower( $email ), $salt ), 0, 32 );
		$ip_key    = 'xiujin_ip_' . substr( hash_hmac( 'sha256', $ip, $salt ), 0, 32 );
		$email_hits = absint( get_transient( $email_key ) );
		$ip_hits    = absint( get_transient( $ip_key ) );

		if ( $email_hits >= self::RATE_LIMIT || $ip_hits >= self::IP_RATE_LIMIT ) {
			return true;
		}

		set_transient( $email_key, $email_hits + 1, HOUR_IN_SECONDS );
		set_transient( $ip_key, $ip_hits + 1, HOUR_IN_SECONDS );
		return false;
	}

	/**
	 * Build the sales email without HTML or untrusted headers.
	 *
	 * @param array $data Validated submission.
	 * @return string
	 */
	private static function email_body( $data ) {
		$labels = array(
			'product'      => __( 'Product or category', 'xiujin-store-core' ),
			'quantity'     => __( 'Estimated quantity', 'xiujin-store-core' ),
			'destination'  => __( 'Destination', 'xiujin-store-core' ),
			'company'      => __( 'Company', 'xiujin-store-core' ),
			'name'         => __( 'Contact name', 'xiujin-store-core' ),
			'email'        => __( 'Email', 'xiujin-store-core' ),
			'whatsapp'     => __( 'WhatsApp or phone', 'xiujin-store-core' ),
			'requirements' => __( 'Requirements', 'xiujin-store-core' ),
		);
		$lines  = array( __( 'New website enquiry', 'xiujin-store-core' ), str_repeat( '-', 28 ) );

		foreach ( $labels as $key => $label ) {
			$value   = isset( $data[ $key ] ) && '' !== (string) $data[ $key ] ? (string) $data[ $key ] : __( 'Not provided', 'xiujin-store-core' );
			$lines[] = $label . ': ' . $value;
		}

		$referer = wp_get_referer();
		if ( $referer ) {
			$lines[] = __( 'Source page', 'xiujin-store-core' ) . ': ' . esc_url_raw( $referer );
		}

		return implode( "\n", $lines );
	}

	/**
	 * Return the configured valid recipient or the site administrator email.
	 *
	 * @return string
	 */
	private static function recipient_email() {
		$recipient = sanitize_email( get_option( self::OPTION_RECIPIENT, '' ) );
		return is_email( $recipient ) ? $recipient : sanitize_email( get_option( 'admin_email' ) );
	}

	/**
	 * Redirect back to a same-site page with an allowlisted status.
	 *
	 * @param string $status Result slug.
	 */
	private static function redirect_with_status( $status ) {
		$allowed = array( 'success', 'invalid', 'expired', 'rate_limited', 'failed' );
		$status  = in_array( $status, $allowed, true ) ? $status : 'failed';
		$referer = wp_get_referer();
		$target  = wp_validate_redirect( $referer ? $referer : '', home_url( '/' ) );
		$target  = remove_query_arg( 'xiujin_inquiry', $target );
		$target  = add_query_arg( 'xiujin_inquiry', $status, $target );
		$target  = strtok( $target, '#' ) . '#quote';

		wp_safe_redirect( $target, 303, 'XIUJIN Store Core' );
		exit;
	}

	/**
	 * Register the recipient setting.
	 */
	public static function register_settings() {
		register_setting(
			'xiujin_inquiry_settings',
			self::OPTION_RECIPIENT,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( __CLASS__, 'sanitize_recipient' ),
				'default'           => '',
			)
		);

		add_settings_section(
			'xiujin_inquiry_delivery',
			esc_html__( 'Enquiry delivery', 'xiujin-store-core' ),
			'__return_false',
			'xiujin-inquiries'
		);

		add_settings_field(
			self::OPTION_RECIPIENT,
			esc_html__( 'Recipient email', 'xiujin-store-core' ),
			array( __CLASS__, 'render_recipient_field' ),
			'xiujin-inquiries',
			'xiujin_inquiry_delivery'
		);
	}

	/**
	 * Add the plugin page under Settings.
	 */
	public static function register_settings_page() {
		add_options_page(
			esc_html__( 'XIUJIN enquiries', 'xiujin-store-core' ),
			esc_html__( 'XIUJIN enquiries', 'xiujin-store-core' ),
			'manage_options',
			'xiujin-inquiries',
			array( __CLASS__, 'render_settings_page' )
		);
	}

	/**
	 * Validate the configured recipient.
	 *
	 * @param string $value Submitted email.
	 * @return string
	 */
	public static function sanitize_recipient( $value ) {
		$raw   = trim( (string) $value );
		$email = sanitize_email( $raw );
		if ( $raw && ! is_email( $email ) ) {
			add_settings_error(
				self::OPTION_RECIPIENT,
				'xiujin_invalid_recipient',
				esc_html__( 'Enter a valid recipient email address.', 'xiujin-store-core' )
			);
			return '';
		}
		return $email;
	}

	/**
	 * Render the recipient field.
	 */
	public static function render_recipient_field() {
		$value = get_option( self::OPTION_RECIPIENT, '' );
		printf(
			'<input class="regular-text" type="email" name="%1$s" value="%2$s" autocomplete="email"><p class="description">%3$s</p>',
			esc_attr( self::OPTION_RECIPIENT ),
			esc_attr( $value ),
			esc_html__( 'Leave empty to use the WordPress administration email.', 'xiujin-store-core' )
		);
	}

	/**
	 * Render the settings page.
	 */
	public static function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'XIUJIN enquiry settings', 'xiujin-store-core' ); ?></h1>
			<p><?php esc_html_e( 'Choose where validated website enquiries are delivered. Test mail delivery before launching the site.', 'xiujin-store-core' ); ?></p>
			<form action="options.php" method="post">
				<?php
				settings_fields( 'xiujin_inquiry_settings' );
				do_settings_sections( 'xiujin-inquiries' );
				submit_button();
				?>
			</form>
		</div>
		<?php
	}
}

