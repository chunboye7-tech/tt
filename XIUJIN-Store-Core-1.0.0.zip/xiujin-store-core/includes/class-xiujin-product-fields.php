<?php
/**
 * WooCommerce product business fields and storefront behaviour.
 *
 * @package XiujinStoreCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores durable business data outside the theme.
 */
final class Xiujin_Product_Fields {
	const META_SALES_MODE = '_xiujin_sales_mode';
	const META_MOQ        = '_xiujin_moq';
	const META_LEAD_TIME  = '_xiujin_lead_time';
	const META_CONFIG_ID  = '_xiujin_config_id';

	/**
	 * Attach WordPress and WooCommerce hooks.
	 */
	public static function register() {
		add_action( 'woocommerce_product_options_general_product_data', array( __CLASS__, 'render_admin_fields' ) );
		add_action( 'woocommerce_admin_process_product_object', array( __CLASS__, 'save_admin_fields' ) );
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'render_business_details' ), 24 );
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'render_enquiry_cta' ), 31 );

		add_filter( 'woocommerce_is_purchasable', array( __CLASS__, 'filter_purchasable' ), 10, 2 );
		add_filter( 'woocommerce_variation_is_purchasable', array( __CLASS__, 'filter_purchasable' ), 10, 2 );
		add_filter( 'woocommerce_get_price_html', array( __CLASS__, 'filter_price_html' ), 10, 2 );
		add_filter( 'woocommerce_loop_add_to_cart_link', array( __CLASS__, 'filter_loop_button' ), 10, 3 );
	}

	/**
	 * Output fields on the WooCommerce product editor.
	 */
	public static function render_admin_fields() {
		if ( ! function_exists( 'woocommerce_wp_select' ) || ! function_exists( 'woocommerce_wp_text_input' ) ) {
			return;
		}

		$product_id = get_the_ID();
		wp_nonce_field( 'xiujin_save_product_fields_' . $product_id, 'xiujin_product_fields_nonce' );

		echo '<div class="options_group xiujin-business-fields">';

		woocommerce_wp_select(
			array(
				'id'          => self::META_SALES_MODE,
				'label'       => esc_html__( 'Sales mode', 'xiujin-store-core' ),
				'description' => esc_html__( 'Choose how this product can be ordered.', 'xiujin-store-core' ),
				'desc_tip'    => true,
				'value'       => self::get_sales_mode( $product_id ),
				'options'     => array(
					'wholesale' => esc_html__( 'Wholesale enquiry only', 'xiujin-store-core' ),
					'retail'    => esc_html__( 'Retail purchase', 'xiujin-store-core' ),
					'both'      => esc_html__( 'Wholesale and retail', 'xiujin-store-core' ),
				),
			)
		);

		woocommerce_wp_text_input(
			array(
				'id'                => self::META_MOQ,
				'label'             => esc_html__( 'Minimum order quantity', 'xiujin-store-core' ),
				'description'       => esc_html__( 'Leave empty when the quantity is confirmed by quotation.', 'xiujin-store-core' ),
				'desc_tip'          => true,
				'type'              => 'number',
				'custom_attributes' => array(
					'min'  => '1',
					'step' => '1',
				),
			)
		);

		woocommerce_wp_text_input(
			array(
				'id'          => self::META_LEAD_TIME,
				'label'       => esc_html__( 'Lead time', 'xiujin-store-core' ),
				'placeholder' => esc_attr__( 'Confirmed with quotation', 'xiujin-store-core' ),
				'description' => esc_html__( 'Use current, qualified wording such as “Confirmed with quotation”.', 'xiujin-store-core' ),
				'desc_tip'    => true,
			)
		);

		woocommerce_wp_text_input(
			array(
				'id'          => self::META_CONFIG_ID,
				'label'       => esc_html__( 'Internal configuration ID', 'xiujin-store-core' ),
				'placeholder' => 'S01-R002-V01',
				'description' => esc_html__( 'Internal catalogue reference. It is not shown as a public product title.', 'xiujin-store-core' ),
				'desc_tip'    => true,
			)
		);

		echo '</div>';
	}

	/**
	 * Persist product fields after WooCommerce has validated the product edit.
	 *
	 * @param WC_Product $product Product being saved.
	 */
	public static function save_admin_fields( $product ) {
		$product_id = is_object( $product ) && method_exists( $product, 'get_id' ) ? (int) $product->get_id() : 0;
		$nonce      = isset( $_POST['xiujin_product_fields_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['xiujin_product_fields_nonce'] ) ) : '';

		if ( ! $product_id || ! current_user_can( 'edit_post', $product_id ) ) {
			return;
		}

		if ( ! wp_verify_nonce( $nonce, 'xiujin_save_product_fields_' . $product_id ) ) {
			return;
		}

		$mode = isset( $_POST[ self::META_SALES_MODE ] ) ? sanitize_key( wp_unslash( $_POST[ self::META_SALES_MODE ] ) ) : 'both';
		if ( ! in_array( $mode, array( 'wholesale', 'retail', 'both' ), true ) ) {
			$mode = 'both';
		}
		$product->update_meta_data( self::META_SALES_MODE, $mode );

		$moq_raw = isset( $_POST[ self::META_MOQ ] ) ? trim( sanitize_text_field( wp_unslash( $_POST[ self::META_MOQ ] ) ) ) : '';
		if ( '' === $moq_raw ) {
			$product->delete_meta_data( self::META_MOQ );
		} else {
			$product->update_meta_data( self::META_MOQ, max( 1, absint( $moq_raw ) ) );
		}

		$lead_time = isset( $_POST[ self::META_LEAD_TIME ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::META_LEAD_TIME ] ) ) : '';
		$lead_time = function_exists( 'mb_substr' ) ? mb_substr( $lead_time, 0, 120 ) : substr( $lead_time, 0, 120 );
		if ( '' === $lead_time ) {
			$product->delete_meta_data( self::META_LEAD_TIME );
		} else {
			$product->update_meta_data( self::META_LEAD_TIME, $lead_time );
		}

		$config_id = isset( $_POST[ self::META_CONFIG_ID ] ) ? strtoupper( sanitize_text_field( wp_unslash( $_POST[ self::META_CONFIG_ID ] ) ) ) : '';
		$config_id = preg_replace( '/[^A-Z0-9._-]/', '', $config_id );
		$config_id = substr( $config_id, 0, 80 );
		if ( '' === $config_id ) {
			$product->delete_meta_data( self::META_CONFIG_ID );
		} else {
			$product->update_meta_data( self::META_CONFIG_ID, $config_id );
		}
	}

	/**
	 * Get a validated sales mode for a product or variation.
	 *
	 * @param int|WC_Product $product Product or ID.
	 * @return string
	 */
	public static function get_sales_mode( $product ) {
		$product_id = is_object( $product ) && method_exists( $product, 'get_id' ) ? (int) $product->get_id() : absint( $product );
		$mode       = $product_id ? get_post_meta( $product_id, self::META_SALES_MODE, true ) : '';

		if ( ! $mode && is_object( $product ) && method_exists( $product, 'get_parent_id' ) && $product->get_parent_id() ) {
			$mode = get_post_meta( $product->get_parent_id(), self::META_SALES_MODE, true );
		}

		return in_array( $mode, array( 'wholesale', 'retail', 'both' ), true ) ? $mode : 'both';
	}

	/**
	 * Disable direct checkout for enquiry-only products.
	 *
	 * @param bool       $purchasable Current status.
	 * @param WC_Product $product     Product object.
	 * @return bool
	 */
	public static function filter_purchasable( $purchasable, $product ) {
		return 'wholesale' === self::get_sales_mode( $product ) ? false : $purchasable;
	}

	/**
	 * Present a useful price state without inventing prices.
	 *
	 * @param string     $price_html Existing price HTML.
	 * @param WC_Product $product    Product object.
	 * @return string
	 */
	public static function filter_price_html( $price_html, $product ) {
		$mode = self::get_sales_mode( $product );
		if ( 'wholesale' === $mode ) {
			return '<span class="xiujin-price-on-request">' . esc_html__( 'Request a current quotation', 'xiujin-store-core' ) . '</span>';
		}

		if ( '' === trim( wp_strip_all_tags( $price_html ) ) ) {
			return '<span class="xiujin-price-on-request">' . esc_html__( 'Contact us for current pricing', 'xiujin-store-core' ) . '</span>';
		}

		return $price_html;
	}

	/**
	 * Replace the archive cart button for wholesale-only products.
	 *
	 * @param string     $html    Existing HTML.
	 * @param WC_Product $product Product object.
	 * @param array      $args    Button arguments.
	 * @return string
	 */
	public static function filter_loop_button( $html, $product, $args ) {
		if ( 'wholesale' !== self::get_sales_mode( $product ) ) {
			return $html;
		}

		return sprintf(
			'<a href="%1$s" class="%2$s">%3$s</a>',
			esc_url( $product->get_permalink() ),
			esc_attr( isset( $args['class'] ) ? $args['class'] : 'button' ),
			esc_html__( 'View and enquire', 'xiujin-store-core' )
		);
	}

	/**
	 * Show verified B2B attributes on a product page.
	 */
	public static function render_business_details() {
		global $product;

		if ( ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) {
			return;
		}

		$product_id = (int) $product->get_id();
		$mode       = self::get_sales_mode( $product );
		$moq        = absint( get_post_meta( $product_id, self::META_MOQ, true ) );
		$lead_time  = get_post_meta( $product_id, self::META_LEAD_TIME, true );
		$labels     = array(
			'wholesale' => esc_html__( 'Wholesale enquiry', 'xiujin-store-core' ),
			'retail'    => esc_html__( 'Retail purchase', 'xiujin-store-core' ),
			'both'      => esc_html__( 'Wholesale and retail', 'xiujin-store-core' ),
		);

		echo '<dl class="xiujin-product-facts">';
		echo '<div><dt>' . esc_html__( 'Ordering', 'xiujin-store-core' ) . '</dt><dd>' . esc_html( $labels[ $mode ] ) . '</dd></div>';
		if ( $moq ) {
			echo '<div><dt>' . esc_html__( 'Minimum order', 'xiujin-store-core' ) . '</dt><dd>' . esc_html( number_format_i18n( $moq ) ) . '</dd></div>';
		}
		if ( $lead_time ) {
			echo '<div><dt>' . esc_html__( 'Lead time', 'xiujin-store-core' ) . '</dt><dd>' . esc_html( $lead_time ) . '</dd></div>';
		}
		echo '</dl>';
	}

	/**
	 * Add the product-aware quotation call to action.
	 */
	public static function render_enquiry_cta() {
		global $product;

		if ( ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) {
			return;
		}

		$mode = self::get_sales_mode( $product );
		$url  = add_query_arg(
			array( 'product_id' => (int) $product->get_id() ),
			home_url( '/' )
		);
		$url .= '#quote';

		echo '<div class="xiujin-product-enquiry">';
		if ( 'wholesale' === $mode ) {
			echo '<strong>' . esc_html__( 'Factory-direct wholesale enquiry', 'xiujin-store-core' ) . '</strong>';
			echo '<p>' . esc_html__( 'Tell us your quantity, destination and preferred configuration for a current quotation.', 'xiujin-store-core' ) . '</p>';
		} else {
			echo '<strong>' . esc_html__( 'Planning a bulk order?', 'xiujin-store-core' ) . '</strong>';
			echo '<p>' . esc_html__( 'Ask about quantity, configuration and delivery for your market.', 'xiujin-store-core' ) . '</p>';
		}
		printf(
			'<a class="button" href="%1$s">%2$s</a>',
			esc_url( $url ),
			esc_html__( 'Request a quotation', 'xiujin-store-core' )
		);
		echo '</div>';
	}
}

