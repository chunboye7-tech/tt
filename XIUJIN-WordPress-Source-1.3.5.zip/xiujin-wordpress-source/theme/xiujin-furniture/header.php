<?php
/**
 * Site header.
 *
 * @package Xiujin
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'xiujin' ); ?></a>
<div class="announcement-bar">
	<div class="page-width announcement-inner">
		<p><?php echo esc_html( get_theme_mod( 'xiujin_announcement', __( 'Factory-direct chair supply · Wholesale and retail enquiries', 'xiujin' ) ) ); ?></p>
		<?php xiujin_language_switcher(); ?>
	</div>
</div>
<header class="site-header" data-site-header>
	<div class="page-width header-inner">
			<a class="site-brand" href="<?php echo esc_url( xiujin_home_url() ); ?>" rel="home">
			<?php if ( has_custom_logo() ) : ?>
				<span class="brand-logo"><?php echo wp_get_attachment_image( (int) get_theme_mod( 'custom_logo' ), 'thumbnail', false, array( 'alt' => get_bloginfo( 'name' ), 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '(max-width: 620px) 64px, 82px' ) ); ?></span>
			<?php else : ?>
				<span class="brand-mark" aria-hidden="true">X</span>
				<span class="brand-copy"><strong>XIUJIN</strong><small><?php esc_html_e( 'Office & gaming chairs', 'xiujin' ); ?></small></span>
			<?php endif; ?>
		</a>
		<nav class="primary-nav" aria-label="<?php esc_attr_e( 'Primary navigation', 'xiujin' ); ?>">
			<?php
			if ( has_nav_menu( 'primary' ) ) {
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'primary-menu',
						'fallback_cb'    => false,
						'depth'          => 2,
					)
				);
			} else {
				?>
				<ul class="primary-menu">
					<li><a href="<?php echo esc_url( xiujin_home_url( 'collections' ) ); ?>"><?php esc_html_e( 'Chairs', 'xiujin' ); ?></a></li>
					<li><a href="<?php echo esc_url( xiujin_home_url( 'wholesale-retail' ) ); ?>"><?php esc_html_e( 'Wholesale & retail', 'xiujin' ); ?></a></li>
					<li><a href="<?php echo esc_url( xiujin_home_url( 'factory' ) ); ?>"><?php esc_html_e( 'Factory & quality', 'xiujin' ); ?></a></li>
					<li><a href="<?php echo esc_url( xiujin_home_url( 'process' ) ); ?>"><?php esc_html_e( 'How to order', 'xiujin' ); ?></a></li>
				</ul>
				<?php
			}
			?>
		</nav>
		<div class="header-actions">
			<?php xiujin_render_header_social_links(); ?>
			<a class="header-whatsapp" href="<?php echo esc_url( xiujin_whatsapp_url() ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'WhatsApp', 'xiujin' ); ?>">
				<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 2a9.72 9.72 0 0 0-8.43 14.57L2.3 21.2l4.74-1.24A9.7 9.7 0 1 0 12 2Zm0 17.45a7.72 7.72 0 0 1-3.94-1.08l-.28-.17-2.82.74.75-2.74-.18-.29A7.73 7.73 0 1 1 12 19.45Zm4.24-5.79c-.23-.12-1.37-.68-1.58-.75-.21-.08-.36-.12-.52.12-.15.23-.59.75-.72.9-.13.16-.27.18-.5.06-.23-.11-.98-.36-1.86-1.15a7 7 0 0 1-1.29-1.6c-.13-.23-.01-.36.1-.47.1-.1.23-.27.35-.4.11-.14.15-.24.23-.4.08-.15.04-.29-.02-.4-.06-.12-.52-1.25-.71-1.71-.19-.45-.38-.39-.52-.4h-.44c-.15 0-.4.06-.61.29-.21.23-.8.78-.8 1.9s.82 2.2.93 2.35c.12.16 1.6 2.45 3.88 3.44.54.23.96.37 1.29.48.54.17 1.04.15 1.43.09.44-.07 1.37-.56 1.56-1.1.19-.55.19-1.02.13-1.11-.06-.1-.21-.16-.44-.27Z"/></svg>
				<span><?php esc_html_e( 'WhatsApp', 'xiujin' ); ?></span>
			</a>
			<a class="button button--compact" href="<?php echo esc_url( xiujin_home_url( 'quote' ) ); ?>"><?php esc_html_e( 'Request a quote', 'xiujin' ); ?><span class="arrow" aria-hidden="true"></span></a>
			<button class="menu-toggle" type="button" aria-expanded="false" aria-controls="MobileNavigation" data-menu-toggle><span class="menu-icon" aria-hidden="true"></span><span class="screen-reader-text"><?php esc_html_e( 'Open navigation', 'xiujin' ); ?></span></button>
		</div>
	</div>
	<nav id="MobileNavigation" class="mobile-navigation" aria-label="<?php esc_attr_e( 'Mobile navigation', 'xiujin' ); ?>" data-mobile-menu hidden>
		<?php
		if ( has_nav_menu( 'primary' ) ) {
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'mobile-menu',
					'fallback_cb'    => false,
					'depth'          => 2,
				)
			);
		} else {
			?>
			<a href="<?php echo esc_url( xiujin_home_url( 'collections' ) ); ?>"><?php esc_html_e( 'Chairs', 'xiujin' ); ?></a>
			<a href="<?php echo esc_url( xiujin_home_url( 'wholesale-retail' ) ); ?>"><?php esc_html_e( 'Wholesale & retail', 'xiujin' ); ?></a>
			<a href="<?php echo esc_url( xiujin_home_url( 'factory' ) ); ?>"><?php esc_html_e( 'Factory & quality', 'xiujin' ); ?></a>
			<a href="<?php echo esc_url( xiujin_home_url( 'process' ) ); ?>"><?php esc_html_e( 'How to order', 'xiujin' ); ?></a>
			<a href="<?php echo esc_url( xiujin_home_url( 'quote' ) ); ?>"><?php esc_html_e( 'Request a quote', 'xiujin' ); ?></a>
			<?php
		}
		?>
	</nav>
</header>

