XIUJIN product media package
============================

This package contains 58 representative images mapped to 18 source product series from 领航价目表(1).xlsx. Keep each source series as one product and use its mapped images as media/configuration references.

Row 171 is included with three visual configurations: pink five-star, gray five-star, and beige four-leg.

Prices and option availability are not included because the source currency, commercial terms, and exact option pairings still require confirmation. Visible color descriptions are working labels and must be confirmed before publication.
