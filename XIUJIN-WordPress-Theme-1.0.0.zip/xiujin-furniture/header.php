<?php
/**
 * Site header.
 *
 * @package Xiujin
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'xiujin' ); ?></a>
<div class="announcement-bar">
	<div class="page-width announcement-inner">
		<p><?php echo esc_html( get_theme_mod( 'xiujin_announcement', __( 'Factory-direct chair supply · Wholesale enquiries and retail-ready products', 'xiujin' ) ) ); ?></p>
		<?php xiujin_language_switcher(); ?>
	</div>
</div>
<header class="site-header" data-site-header>
	<div class="page-width header-inner">
		<a class="site-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php if ( has_custom_logo() ) : ?>
				<span class="brand-logo"><?php echo wp_get_attachment_image( (int) get_theme_mod( 'custom_logo' ), 'full', false, array( 'alt' => get_bloginfo( 'name' ) ) ); ?></span>
			<?php else : ?>
				<span class="brand-mark" aria-hidden="true">X</span>
				<span class="brand-copy"><strong>XIUJIN</strong><small><?php esc_html_e( 'Office & gaming chairs', 'xiujin' ); ?></small></span>
			<?php endif; ?>
		</a>
		<nav class="primary-nav" aria-label="<?php esc_attr_e( 'Primary navigation', 'xiujin' ); ?>">
			<?php
			if ( has_nav_menu( 'primary' ) ) {
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'primary-menu',
						'fallback_cb'    => false,
						'depth'          => 2,
					)
				);
			} else {
				?>
				<ul class="primary-menu">
					<li><a href="<?php echo esc_url( home_url( '/#collections' ) ); ?>"><?php esc_html_e( 'Chairs', 'xiujin' ); ?></a></li>
					<li><a href="<?php echo esc_url( home_url( '/#wholesale-retail' ) ); ?>"><?php esc_html_e( 'Wholesale & retail', 'xiujin' ); ?></a></li>
					<li><a href="<?php echo esc_url( home_url( '/#factory' ) ); ?>"><?php esc_html_e( 'Factory & quality', 'xiujin' ); ?></a></li>
					<li><a href="<?php echo esc_url( home_url( '/#process' ) ); ?>"><?php esc_html_e( 'How to order', 'xiujin' ); ?></a></li>
				</ul>
				<?php
			}
			?>
		</nav>
		<div class="header-actions">
			<?php xiujin_cart_link(); ?>
			<a class="button button--compact" href="<?php echo esc_url( home_url( '/#quote' ) ); ?>"><?php esc_html_e( 'Request a quote', 'xiujin' ); ?><span class="arrow" aria-hidden="true"></span></a>
			<button class="menu-toggle" type="button" aria-expanded="false" aria-controls="MobileNavigation" data-menu-toggle><span class="menu-icon" aria-hidden="true"></span><span class="screen-reader-text"><?php esc_html_e( 'Open navigation', 'xiujin' ); ?></span></button>
		</div>
	</div>
	<nav id="MobileNavigation" class="mobile-navigation" aria-label="<?php esc_attr_e( 'Mobile navigation', 'xiujin' ); ?>" data-mobile-menu hidden>
		<?php
		if ( has_nav_menu( 'primary' ) ) {
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'mobile-menu',
					'fallback_cb'    => false,
					'depth'          => 2,
				)
			);
		} else {
			?>
			<a href="<?php echo esc_url( home_url( '/#collections' ) ); ?>"><?php esc_html_e( 'Chairs', 'xiujin' ); ?></a>
			<a href="<?php echo esc_url( home_url( '/#wholesale-retail' ) ); ?>"><?php esc_html_e( 'Wholesale & retail', 'xiujin' ); ?></a>
			<a href="<?php echo esc_url( home_url( '/#factory' ) ); ?>"><?php esc_html_e( 'Factory & quality', 'xiujin' ); ?></a>
			<a href="<?php echo esc_url( home_url( '/#process' ) ); ?>"><?php esc_html_e( 'How to order', 'xiujin' ); ?></a>
			<a href="<?php echo esc_url( home_url( '/#quote' ) ); ?>"><?php esc_html_e( 'Request a quote', 'xiujin' ); ?></a>
			<?php
		}
		?>
	</nav>
</header>

