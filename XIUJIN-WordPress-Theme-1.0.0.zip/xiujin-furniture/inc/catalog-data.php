<?php
/**
 * Source-checked starter catalog used until WooCommerce products are published.
 * Public titles intentionally omit internal source numbers.
 *
 * @package Xiujin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function xiujin_catalog_series() {
	return array(
		array( 'title' => __( '135° Reclining Gaming Chair', 'xiujin' ), 'category' => __( 'Gaming chairs', 'xiujin' ), 'detail' => __( 'Recline · linked armrests', 'xiujin' ), 'image' => 'chair-8011.webp' ),
		array( 'title' => __( 'Mesh Gaming Chair', 'xiujin' ), 'category' => __( 'Gaming chairs', 'xiujin' ), 'detail' => __( 'Mesh upholstery · reclining backrest', 'xiujin' ), 'image' => 'chair-8031.webp' ),
		array( 'title' => __( '180° Reclining Gaming Chair', 'xiujin' ), 'category' => __( 'Gaming chairs', 'xiujin' ), 'detail' => __( 'Deep recline · adjustable armrests', 'xiujin' ), 'image' => 'chair-8051.webp' ),
		array( 'title' => __( 'Mesh Office Chair', 'xiujin' ), 'category' => __( 'Office chairs', 'xiujin' ), 'detail' => __( 'Mesh back · seat-height adjustment', 'xiujin' ), 'image' => 'chair-110.webp' ),
		array( 'title' => __( 'Steel-Frame Gaming Chair', 'xiujin' ), 'category' => __( 'Gaming chairs', 'xiujin' ), 'detail' => __( 'Steel frame · linked armrests', 'xiujin' ), 'image' => 'chair-8021.webp' ),
		array( 'title' => __( 'Adjustable Gaming Chair', 'xiujin' ), 'category' => __( 'Gaming chairs', 'xiujin' ), 'detail' => __( 'Tilt function · adjustable armrests', 'xiujin' ), 'image' => 'chair-8061.webp' ),
		array( 'title' => __( 'Mesh Office Chair with Fixed Armrests', 'xiujin' ), 'category' => __( 'Mesh office chairs', 'xiujin' ), 'detail' => __( 'Height adjustment · swivel · steel base', 'xiujin' ), 'image' => 'chair-row42.webp' ),
		array( 'title' => __( 'Mesh Task Chair with Fixed Armrests', 'xiujin' ), 'category' => __( 'Mesh office chairs', 'xiujin' ), 'detail' => __( 'Mesh upholstery · optional headrest', 'xiujin' ), 'image' => 'chair-mesh-a.webp' ),
		array( 'title' => __( 'Swivel Mesh Office Chair', 'xiujin' ), 'category' => __( 'Mesh office chairs', 'xiujin' ), 'detail' => __( 'Fixed armrests · steel base', 'xiujin' ), 'image' => 'chair-row81.webp' ),
		array( 'title' => __( 'Height-Adjustable Mesh Task Chair', 'xiujin' ), 'category' => __( 'Mesh office chairs', 'xiujin' ), 'detail' => __( 'Height adjustment · optional headrest', 'xiujin' ), 'image' => 'chair-row91.webp' ),
		array( 'title' => __( 'Mesh Office Chair with Headrest', 'xiujin' ), 'category' => __( 'Mesh office chairs', 'xiujin' ), 'detail' => __( 'Headrest configuration · polypropylene base', 'xiujin' ), 'image' => 'chair-row101.webp' ),
		array( 'title' => __( 'Reclining Mesh Office Chair', 'xiujin' ), 'category' => __( 'Mesh office chairs', 'xiujin' ), 'detail' => __( 'Reclining function · optional footrest', 'xiujin' ), 'image' => 'chair-row111.webp' ),
		array( 'title' => __( 'Reclining Executive Chair with 3D Armrests', 'xiujin' ), 'category' => __( 'Executive chairs', 'xiujin' ), 'detail' => __( 'Padded 3D armrests · steel base', 'xiujin' ), 'image' => 'chair-executive.webp' ),
		array( 'title' => __( 'Padded Reclining Executive Chair', 'xiujin' ), 'category' => __( 'Executive chairs', 'xiujin' ), 'detail' => __( 'Reclining function · padded seating', 'xiujin' ), 'image' => 'chair-row131.webp' ),
		array( 'title' => __( 'High-Back Reclining Executive Chair', 'xiujin' ), 'category' => __( 'Executive chairs', 'xiujin' ), 'detail' => __( 'High-back profile · optional footrest', 'xiujin' ), 'image' => 'chair-row141.webp' ),
		array( 'title' => __( 'Reclining Office Chair with Padded Armrests', 'xiujin' ), 'category' => __( 'Executive chairs', 'xiujin' ), 'detail' => __( 'Padded armrests · steel base', 'xiujin' ), 'image' => 'chair-row151.webp' ),
		array( 'title' => __( 'Height-Adjustable Reclining Office Chair', 'xiujin' ), 'category' => __( 'Executive chairs', 'xiujin' ), 'detail' => __( 'Height adjustment · optional footrest', 'xiujin' ), 'image' => 'chair-row161.webp' ),
		array( 'title' => __( 'Mesh Reclining Swivel Desk Chair', 'xiujin' ), 'category' => __( 'Mesh office chairs', 'xiujin' ), 'detail' => __( 'Mesh upholstery · recline · polypropylene base', 'xiujin' ), 'image' => 'chair-row171.webp' ),
	);
}

function xiujin_photo_configurations() {
	return array(
		array( 'key' => 'black-ivory', 'title' => __( 'Black / ivory', 'xiujin' ), 'image' => 'config-black-ivory.webp', 'alt' => __( 'Black and ivory reclining gaming chair catalog photo', 'xiujin' ) ),
		array( 'key' => 'red-rgb', 'title' => __( 'Red / black with color trim', 'xiujin' ), 'image' => 'config-red-rgb.webp', 'alt' => __( 'Red and black gaming chair with color trim catalog photo', 'xiujin' ) ),
		array( 'key' => 'blue-piping', 'title' => __( 'Black / white with blue piping', 'xiujin' ), 'image' => 'config-blue-piping.webp', 'alt' => __( 'Black and white gaming chair with blue piping catalog photo', 'xiujin' ) ),
		array( 'key' => 'yellow-black', 'title' => __( 'Black / yellow', 'xiujin' ), 'image' => 'config-yellow-black.webp', 'alt' => __( 'Black and yellow gaming chair catalog photo', 'xiujin' ) ),
		array( 'key' => 'red-bow', 'title' => __( 'Red / black with shaped cushions', 'xiujin' ), 'image' => 'config-red-bow.webp', 'alt' => __( 'Red and black gaming chair with shaped cushions catalog photo', 'xiujin' ) ),
		array( 'key' => 'orange-fabric', 'title' => __( 'Black / orange fabric', 'xiujin' ), 'image' => 'config-orange-fabric.webp', 'alt' => __( 'Black and orange fabric gaming chair catalog photo', 'xiujin' ) ),
	);
}

