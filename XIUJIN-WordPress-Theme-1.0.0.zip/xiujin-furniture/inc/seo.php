<?php
/**
 * Lightweight fallback metadata. Dedicated SEO plugins take precedence.
 *
 * @package Xiujin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function xiujin_has_seo_plugin() {
	return defined( 'WPSEO_VERSION' )
		|| defined( 'RANK_MATH_VERSION' )
		|| defined( 'AIOSEO_VERSION' )
		|| defined( 'THE_SEO_FRAMEWORK_VERSION' )
		|| defined( 'SEOPRESS_VERSION' )
		|| defined( 'SLIM_SEO_VER' );
}

function xiujin_fallback_meta() {
	if ( xiujin_has_seo_plugin() || ! is_front_page() ) {
		return;
	}
	$description = __( 'Explore XIUJIN factory-direct office and gaming chairs for wholesale enquiries and retail-ready products.', 'xiujin' );
	$image       = xiujin_theme_asset( 'hero-chair-collection.webp' );
	?>
	<meta name="description" content="<?php echo esc_attr( $description ); ?>">
	<meta property="og:type" content="website">
	<meta property="og:title" content="<?php echo esc_attr( wp_get_document_title() ); ?>">
	<meta property="og:description" content="<?php echo esc_attr( $description ); ?>">
	<meta property="og:url" content="<?php echo esc_url( home_url( '/' ) ); ?>">
	<meta property="og:image" content="<?php echo esc_url( $image ); ?>">
	<meta name="twitter:card" content="summary_large_image">
	<?php
}
add_action( 'wp_head', 'xiujin_fallback_meta', 2 );

function xiujin_organization_schema() {
	if ( xiujin_has_seo_plugin() || ! is_front_page() ) {
		return;
	}
	$organization = array(
		'@type' => 'Organization',
		'@id'   => home_url( '/#organization' ),
		'name'  => xiujin_company_name(),
		'url'   => home_url( '/' ),
	);
	$logo_id = get_theme_mod( 'custom_logo' );
	if ( $logo_id ) {
		$logo = wp_get_attachment_image_url( $logo_id, 'full' );
		if ( $logo ) {
			$organization['logo'] = $logo;
		}
	}
	$social  = xiujin_social_links();
	$same_as = array();
	foreach ( array( 'facebook', 'instagram', 'tiktok' ) as $network ) {
		if ( isset( $social[ $network ]['url'] ) ) {
			$same_as[] = $social[ $network ]['url'];
		}
	}
	if ( $same_as ) {
		$organization['sameAs'] = $same_as;
	}
	$phone = sanitize_text_field( (string) get_theme_mod( 'xiujin_phone', '' ) );
	$email = sanitize_email( (string) get_theme_mod( 'xiujin_email', '' ) );
	if ( $phone || $email ) {
		$organization['contactPoint'] = array_filter(
			array(
				'@type'       => 'ContactPoint',
				'telephone'   => $phone,
				'email'       => $email,
				'contactType' => 'sales',
			)
		);
	}
	$data = array(
		'@context' => 'https://schema.org',
		'@graph'   => array(
			$organization,
			array(
				'@type'     => 'WebSite',
				'@id'       => home_url( '/#website' ),
				'url'       => home_url( '/' ),
				'name'      => get_bloginfo( 'name' ),
				'publisher' => array( '@id' => home_url( '/#organization' ) ),
			),
		),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
add_action( 'wp_head', 'xiujin_organization_schema', 30 );

