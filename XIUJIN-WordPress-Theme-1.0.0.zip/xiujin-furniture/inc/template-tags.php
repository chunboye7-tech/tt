<?php
/**
 * Reusable theme output helpers.
 *
 * @package Xiujin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function xiujin_theme_asset( $filename ) {
	return XIUJIN_THEME_URI . '/assets/images/' . ltrim( $filename, '/' );
}

function xiujin_company_name() {
	return (string) get_theme_mod( 'xiujin_company_name', 'Bazhou Xiujin Furniture Co., Ltd' );
}

function xiujin_social_links() {
	$networks = array(
		'facebook'  => __( 'Facebook', 'xiujin' ),
		'instagram' => __( 'Instagram', 'xiujin' ),
		'tiktok'    => __( 'TikTok', 'xiujin' ),
		'whatsapp'  => __( 'WhatsApp', 'xiujin' ),
		'messenger' => __( 'Messenger', 'xiujin' ),
	);
	$links = array();
	foreach ( $networks as $key => $label ) {
		$url = get_theme_mod( 'xiujin_' . $key . '_url', '' );
		if ( $url ) {
			$links[ $key ] = array( 'label' => $label, 'url' => $url );
		}
	}
	return $links;
}

function xiujin_language_switcher() {
	if ( function_exists( 'pll_the_languages' ) ) {
		echo '<div class="language-switcher" aria-label="' . esc_attr__( 'Language selection', 'xiujin' ) . '">';
		pll_the_languages(
			array(
				'show_flags' => 0,
				'show_names' => 1,
				'dropdown'   => 1,
			)
		);
		echo '</div>';
		return;
	}
	if ( has_action( 'wpml_add_language_selector' ) ) {
		echo '<div class="language-switcher" aria-label="' . esc_attr__( 'Language selection', 'xiujin' ) . '">';
		do_action( 'wpml_add_language_selector' );
		echo '</div>';
	}
}

/**
 * Avoid duplicate menu-item IDs when the primary menu is rendered for both
 * desktop and mobile navigation.
 *
 * @param string   $menu_id Menu item ID.
 * @param WP_Post  $item    Menu item object.
 * @param stdClass $args    Menu arguments.
 * @return string
 */
function xiujin_mobile_menu_item_id( $menu_id, $item, $args ) {
	unset( $item );
	if ( isset( $args->menu_class ) && 'mobile-menu' === $args->menu_class ) {
		return '';
	}
	return $menu_id;
}
add_filter( 'nav_menu_item_id', 'xiujin_mobile_menu_item_id', 10, 3 );

function xiujin_section_heading( $eyebrow, $heading, $intro = '' ) {
	?>
	<div class="section-heading" data-reveal>
		<div>
			<span class="eyebrow"><?php echo esc_html( $eyebrow ); ?></span>
			<h2><?php echo esc_html( $heading ); ?></h2>
		</div>
		<?php if ( $intro ) : ?>
			<p><?php echo esc_html( $intro ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

function xiujin_render_social_links( $class_name = 'social-links' ) {
	$links = xiujin_social_links();
	if ( ! $links ) {
		return;
	}
	echo '<div class="' . esc_attr( $class_name ) . '">';
	foreach ( $links as $key => $item ) {
		printf(
			'<a class="social-link social-link--%1$s" href="%2$s" target="_blank" rel="noopener noreferrer"><span>%3$s</span></a>',
			esc_attr( $key ),
			esc_url( $item['url'] ),
			esc_html( $item['label'] )
		);
	}
	echo '</div>';
}

