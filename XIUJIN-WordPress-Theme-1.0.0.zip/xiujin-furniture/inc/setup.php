<?php
/**
 * Theme setup and assets.
 *
 * @package Xiujin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function xiujin_theme_setup() {
	load_theme_textdomain( 'xiujin', XIUJIN_THEME_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/theme.css' );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 100,
			'width'       => 320,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);
	register_nav_menus(
		array(
			'primary' => __( 'Primary navigation', 'xiujin' ),
			'footer'  => __( 'Footer navigation', 'xiujin' ),
		)
	);
	add_image_size( 'xiujin-card', 720, 720, false );
}
add_action( 'after_setup_theme', 'xiujin_theme_setup' );

function xiujin_asset_version( $relative_path ) {
	$file = XIUJIN_THEME_DIR . '/' . ltrim( $relative_path, '/' );
	return is_file( $file ) ? (string) filemtime( $file ) : XIUJIN_THEME_VERSION;
}

function xiujin_enqueue_assets() {
	wp_enqueue_style( 'xiujin-style', get_stylesheet_uri(), array(), XIUJIN_THEME_VERSION );
	wp_enqueue_style(
		'xiujin-theme',
		XIUJIN_THEME_URI . '/assets/css/theme.css',
		array( 'xiujin-style' ),
		xiujin_asset_version( 'assets/css/theme.css' )
	);
	wp_enqueue_script(
		'xiujin-theme',
		XIUJIN_THEME_URI . '/assets/js/theme.js',
		array(),
		xiujin_asset_version( 'assets/js/theme.js' ),
		true
	);
	wp_script_add_data( 'xiujin-theme', 'strategy', 'defer' );
	wp_localize_script(
		'xiujin-theme',
		'xiujinTheme',
		array(
			'modelScript' => esc_url_raw( XIUJIN_THEME_URI . '/assets/js/chair-model.js' ),
			'modelLoading' => __( 'Loading interactive view…', 'xiujin' ),
			'modelError'  => __( 'The interactive view could not load. The catalog photo remains available as the product reference.', 'xiujin' ),
			'menuOpen'    => __( 'Open navigation', 'xiujin' ),
			'menuClose'   => __( 'Close navigation', 'xiujin' ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'xiujin_enqueue_assets' );

function xiujin_body_classes( $classes ) {
	$classes[] = 'xiujin-site';
	if ( class_exists( 'WooCommerce' ) ) {
		$classes[] = 'xiujin-has-woocommerce';
	}
	return $classes;
}
add_filter( 'body_class', 'xiujin_body_classes' );

