<?php
/**
 * Fallback template.
 *
 * @package Xiujin
 */
get_header();
?>
<main id="primary" class="site-main page-width content-index">
	<header class="archive-header"><span class="eyebrow"><?php esc_html_e( 'XIUJIN Journal', 'xiujin' ); ?></span><h1><?php bloginfo( 'name' ); ?></h1></header>
	<?php if ( have_posts() ) : ?>
		<div class="post-grid">
		<?php while ( have_posts() ) : the_post(); ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
				<?php if ( has_post_thumbnail() ) : ?><a class="post-card-image" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'large', array( 'loading' => 'lazy' ) ); ?></a><?php endif; ?>
				<div><p class="post-meta"><?php echo esc_html( get_the_date() ); ?></p><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><?php the_excerpt(); ?></div>
			</article>
		<?php endwhile; ?>
		</div>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<p><?php esc_html_e( 'No content was found.', 'xiujin' ); ?></p>
	<?php endif; ?>
</main>
<?php get_footer(); ?>

