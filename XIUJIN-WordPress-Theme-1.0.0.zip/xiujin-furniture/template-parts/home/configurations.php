<?php
/**
 * Real photo configurations and one clearly scoped 3D reference.
 *
 * @package Xiujin
 */
$configurations = xiujin_photo_configurations();
$first_config   = $configurations[0];
?>
<section id="configurations" class="section configuration-section" data-config-gallery>
	<div class="page-width">
		<?php xiujin_section_heading( __( 'Real product references', 'xiujin' ), __( 'Compare the actual finishes. Inspect one 3D reference.', 'xiujin' ), __( 'The supplied catalog photos are the reference for color and upholstery. The interactive view is deliberately limited to the matching black and ivory configuration.', 'xiujin' ) ); ?>
		<div class="configuration-layout">
			<figure class="reference-card" data-reveal>
				<div class="reference-image"><img data-config-image src="<?php echo esc_url( xiujin_theme_asset( $first_config['image'] ) ); ?>" width="910" height="1451" loading="lazy" decoding="async" alt="<?php echo esc_attr( $first_config['alt'] ); ?>"></div>
				<figcaption><span><?php esc_html_e( 'Actual catalog photo', 'xiujin' ); ?></span><strong data-config-title aria-live="polite"><?php echo esc_html( $first_config['title'] ); ?></strong><small><?php esc_html_e( 'Use the photo to confirm visible color and upholstery details.', 'xiujin' ); ?></small></figcaption>
			</figure>
			<div class="model-card" data-model-loader data-model-src="<?php echo esc_url( XIUJIN_THEME_URI . '/assets/js/chair-model.js' ); ?>" data-reveal>
				<div class="model-heading"><span><?php esc_html_e( 'Interactive 3D reference', 'xiujin' ); ?></span><strong><?php esc_html_e( 'Black / ivory only', 'xiujin' ); ?></strong></div>
				<div class="model-shell" data-chair-model data-drag-zoom="<?php esc_attr_e( 'Drag to rotate · Use buttons to zoom', 'xiujin' ); ?>" data-selected-finish="<?php esc_attr_e( 'Black / ivory reference', 'xiujin' ); ?>" data-error-text="<?php esc_attr_e( 'The 3D view could not load.', 'xiujin' ); ?>" data-unavailable-text="<?php esc_attr_e( '3D is unavailable in this browser.', 'xiujin' ); ?>">
					<img class="model-poster" src="<?php echo esc_url( xiujin_theme_asset( 'config-black-ivory.webp' ) ); ?>" width="910" height="1451" loading="lazy" decoding="async" alt="">
					<label class="screen-reader-text" for="ChairReferenceSelect"><?php esc_html_e( '3D appearance', 'xiujin' ); ?></label><select class="screen-reader-text" id="ChairReferenceSelect" tabindex="-1" aria-hidden="true"><option value="0"><?php esc_html_e( 'Black / ivory', 'xiujin' ); ?></option></select>
					<canvas tabindex="0" aria-label="<?php esc_attr_e( 'Interactive 3D chair reference. Use arrow keys to rotate and plus or minus to zoom.', 'xiujin' ); ?>" aria-keyshortcuts="ArrowLeft ArrowRight ArrowUp ArrowDown + -" role="img"><?php esc_html_e( 'Interactive chair reference', 'xiujin' ); ?></canvas>
					<button class="model-load-button button button--gold" type="button" data-model-load><?php esc_html_e( 'Load 3D view', 'xiujin' ); ?><span class="arrow" aria-hidden="true"></span></button>
					<div class="model-controls" role="group" aria-label="<?php esc_attr_e( 'Choose viewing angle', 'xiujin' ); ?>">
						<button type="button" data-angle="0" aria-pressed="true" disabled><?php esc_html_e( 'Front', 'xiujin' ); ?></button><button type="button" data-angle="3.1415926536" aria-pressed="false" disabled><?php esc_html_e( 'Back', 'xiujin' ); ?></button><button type="button" data-angle="-1.5707963268" aria-pressed="false" disabled><?php esc_html_e( 'Left', 'xiujin' ); ?></button><button type="button" data-angle="1.5707963268" aria-pressed="false" disabled><?php esc_html_e( 'Right', 'xiujin' ); ?></button><button type="button" data-zoom="0.82" disabled><?php esc_html_e( 'Zoom in', 'xiujin' ); ?></button><button type="button" data-zoom="1.22" disabled><?php esc_html_e( 'Zoom out', 'xiujin' ); ?></button>
					</div>
					<span class="model-status" data-status aria-live="polite"><?php esc_html_e( 'Load the 3D view when you want to inspect the reference.', 'xiujin' ); ?></span>
				</div>
				<p class="model-disclosure"><?php esc_html_e( 'The 3D object is an approximate visual reference reconstructed from supplied photos. Confirm construction and dimensions against production specifications.', 'xiujin' ); ?></p>
			</div>
		</div>
		<div class="configuration-picker" data-reveal>
			<div><strong><?php esc_html_e( 'Photo configurations', 'xiujin' ); ?></strong><span><?php esc_html_e( 'Select a real product image', 'xiujin' ); ?></span></div>
			<div class="configuration-options" role="group" aria-label="<?php esc_attr_e( 'Product photo configurations', 'xiujin' ); ?>">
				<?php foreach ( $configurations as $index => $configuration ) : ?>
					<button type="button" class="configuration-option" data-config-choice data-image="<?php echo esc_url( xiujin_theme_asset( $configuration['image'] ) ); ?>" data-title="<?php echo esc_attr( $configuration['title'] ); ?>" data-alt="<?php echo esc_attr( $configuration['alt'] ); ?>" aria-pressed="<?php echo 0 === $index ? 'true' : 'false'; ?>"><img src="<?php echo esc_url( xiujin_theme_asset( $configuration['image'] ) ); ?>" width="180" height="220" loading="lazy" decoding="async" alt=""><span><?php echo esc_html( $configuration['title'] ); ?></span></button>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>

