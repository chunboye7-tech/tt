<?php
/**
 * Factory workflow illustrations.
 *
 * @package Xiujin
 */
$stages = array(
	array( 'factory-assembly.webp', __( 'Assembly workflow', 'xiujin' ), __( 'An illustration of an organized chair assembly environment.', 'xiujin' ) ),
	array( 'factory-quality.webp', __( 'Quality review', 'xiujin' ), __( 'An illustration of a chair inspection and review stage.', 'xiujin' ) ),
	array( 'factory-packing.webp', __( 'Packing and dispatch', 'xiujin' ), __( 'An illustration of organized packing and dispatch preparation.', 'xiujin' ) ),
);
?>
<section id="factory" class="section factory-section">
	<div class="factory-grid-pattern" aria-hidden="true"></div>
	<div class="page-width">
		<?php xiujin_section_heading( __( 'Factory & supply workflow', 'xiujin' ), __( 'From chair production to market-ready supply.', 'xiujin' ), __( 'Discuss production configuration, quality review, packaging and dispatch requirements for your order.', 'xiujin' ) ); ?>
		<div class="factory-grid">
			<?php foreach ( $stages as $index => $stage ) : ?>
				<article class="factory-card" data-reveal><div class="factory-image"><img src="<?php echo esc_url( xiujin_theme_asset( $stage[0] ) ); ?>" width="1600" height="1067" loading="lazy" decoding="async" alt="<?php echo esc_attr( $stage[2] ); ?>"><span><?php esc_html_e( 'Workflow illustration', 'xiujin' ); ?></span></div><div><small><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></small><h3><?php echo esc_html( $stage[1] ); ?></h3><p><?php echo esc_html( $stage[2] ); ?></p></div></article>
			<?php endforeach; ?>
		</div>
		<div class="factory-disclosure" data-reveal><strong><?php esc_html_e( 'Image disclosure', 'xiujin' ); ?></strong><p><?php esc_html_e( 'These are production workflow illustrations. Replace them with verified photographs of the actual facility before presenting them as factory photography.', 'xiujin' ); ?></p></div>
	</div>
</section>

