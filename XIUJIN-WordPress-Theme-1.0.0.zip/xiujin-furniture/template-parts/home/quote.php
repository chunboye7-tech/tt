<?php
/**
 * Wholesale enquiry.
 *
 * @package Xiujin
 */
?>
<section id="quote" class="section quote-section">
	<div class="quote-orb" aria-hidden="true"></div>
	<div class="page-width quote-layout">
		<div class="quote-copy" data-reveal>
			<span class="eyebrow"><?php esc_html_e( 'Discuss your order', 'xiujin' ); ?></span>
			<h2><?php esc_html_e( 'Your next chair order starts here.', 'xiujin' ); ?></h2>
			<p><?php esc_html_e( 'Share the chair series, quantity, destination and configuration you need. We will use those details to discuss a current quotation.', 'xiujin' ); ?></p>
			<div class="quote-checklist"><strong><?php esc_html_e( 'A useful enquiry includes', 'xiujin' ); ?></strong><span><?php esc_html_e( 'Chair series or category', 'xiujin' ); ?></span><span><?php esc_html_e( 'Estimated quantity', 'xiujin' ); ?></span><span><?php esc_html_e( 'Destination country or port', 'xiujin' ); ?></span><span><?php esc_html_e( 'Preferred configuration', 'xiujin' ); ?></span></div>
		</div>
		<div class="quote-form-shell" data-reveal>
			<?php if ( shortcode_exists( 'xiujin_inquiry_form' ) ) : ?>
				<?php echo do_shortcode( '[xiujin_inquiry_form]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php else : ?>
				<h3><?php esc_html_e( 'Activate XIUJIN Store Core to enable the secure enquiry form.', 'xiujin' ); ?></h3>
				<p><?php esc_html_e( 'The companion plugin is included with the theme delivery package.', 'xiujin' ); ?></p>
				<?php $email = sanitize_email( (string) get_theme_mod( 'xiujin_email', '' ) ); ?>
				<?php if ( $email ) : ?><a class="button" href="<?php echo esc_url( 'mailto:' . $email ); ?>"><?php esc_html_e( 'Email the sales team', 'xiujin' ); ?></a><?php endif; ?>
			<?php endif; ?>
		</div>
	</div>
</section>
