<?php
/**
 * Supplied visual gallery.
 *
 * @package Xiujin
 */
$visuals = array(
	array( __( 'Gaming chair overview', 'xiujin' ), __( 'Chair styling for a gaming workspace', 'xiujin' ) ),
	array( __( 'Recline reference', 'xiujin' ), __( 'Reclining position and footrest visual', 'xiujin' ) ),
	array( __( 'Back support reference', 'xiujin' ), __( 'Backrest and lumbar support visual', 'xiujin' ) ),
	array( __( 'Height adjustment reference', 'xiujin' ), __( 'Seat-height adjustment visual', 'xiujin' ) ),
	array( __( 'Upholstery reference', 'xiujin' ), __( 'Seat upholstery and cushion visual', 'xiujin' ) ),
	array( __( 'Armrest reference', 'xiujin' ), __( 'Linked armrest visual', 'xiujin' ) ),
	array( __( 'Base and caster reference', 'xiujin' ), __( 'Chair base and caster visual', 'xiujin' ) ),
	array( __( 'Workspace reference', 'xiujin' ), __( 'Chair shown across workspace settings', 'xiujin' ) ),
	array( __( 'Finish collection', 'xiujin' ), __( 'Multiple supplied color references', 'xiujin' ) ),
	array( __( 'Dimension reference', 'xiujin' ), __( 'Catalog dimension visual requiring confirmation', 'xiujin' ) ),
);
?>
<section id="showroom" class="section showroom-section" data-showroom>
	<div class="page-width">
		<div class="showroom-heading" data-reveal>
			<div><span class="eyebrow"><?php esc_html_e( 'Visual catalog', 'xiujin' ); ?></span><h2><?php esc_html_e( 'See the chairs in more detail.', 'xiujin' ); ?></h2></div>
			<p><?php esc_html_e( 'Browse supplied product visuals, then request confirmation for the exact configuration you plan to order.', 'xiujin' ); ?></p>
			<div class="showroom-controls"><button type="button" data-showroom-direction="-1" aria-label="<?php esc_attr_e( 'Previous visuals', 'xiujin' ); ?>">‹</button><button type="button" data-showroom-direction="1" aria-label="<?php esc_attr_e( 'Next visuals', 'xiujin' ); ?>">›</button></div>
		</div>
		<div class="showroom-track" data-showroom-track tabindex="0" aria-label="<?php esc_attr_e( 'Chair visual catalog', 'xiujin' ); ?>">
			<?php foreach ( $visuals as $index => $visual ) : ?>
				<article class="showroom-card" data-reveal><img src="<?php echo esc_url( xiujin_theme_asset( 'home-main-' . ( $index + 1 ) . '.webp' ) ); ?>" width="1024" height="1024" loading="lazy" decoding="async" alt="<?php echo esc_attr( $visual[1] ); ?>"><div><span><?php esc_html_e( 'Supplied marketing visual', 'xiujin' ); ?></span><h3><?php echo esc_html( $visual[0] ); ?></h3><a href="#quote" data-enquiry-product="<?php echo esc_attr( $visual[0] ); ?>"><?php esc_html_e( 'Ask about this detail', 'xiujin' ); ?><span class="arrow" aria-hidden="true"></span></a></div></article>
			<?php endforeach; ?>
		</div>
		<p class="showroom-note"><?php esc_html_e( 'Marketing visuals support product selection. Verify all written claims, measurements and options against current production information before publishing them as specifications.', 'xiujin' ); ?></p>
	</div>
</section>

