<?php
/**
 * Single post template.
 *
 * @package Xiujin
 */
get_header();
?>
<main id="primary" class="site-main page-width singular-content">
	<?php while ( have_posts() ) : the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<header><p class="post-meta"><?php echo esc_html( get_the_date() ); ?></p><h1><?php the_title(); ?></h1></header>
			<?php if ( has_post_thumbnail() ) : ?><div class="entry-hero"><?php the_post_thumbnail( 'full' ); ?></div><?php endif; ?>
			<div class="entry-content"><?php the_content(); ?></div>
		</article>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>

