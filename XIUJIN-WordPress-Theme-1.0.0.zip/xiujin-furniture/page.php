<?php
/**
 * Page template.
 *
 * @package Xiujin
 */
get_header();
?>
<main id="primary" class="site-main page-width singular-content">
	<?php while ( have_posts() ) : the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<header><h1><?php the_title(); ?></h1></header>
			<div class="entry-content"><?php the_content(); ?></div>
		</article>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>

