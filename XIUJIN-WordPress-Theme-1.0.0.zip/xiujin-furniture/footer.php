<?php
/**
 * Site footer.
 *
 * @package Xiujin
 */
$phone = sanitize_text_field( (string) get_theme_mod( 'xiujin_phone', '+852 9019 9249' ) );
$email = sanitize_email( (string) get_theme_mod( 'xiujin_email', '' ) );
?>
<footer class="site-footer">
	<div class="page-width footer-grid">
		<div class="footer-brand">
			<strong>XIUJIN</strong>
			<p><?php esc_html_e( 'Office chairs, executive seating and gaming chairs for wholesale enquiries and retail-ready product selection.', 'xiujin' ); ?></p>
		</div>
		<div>
			<h2><?php esc_html_e( 'Explore', 'xiujin' ); ?></h2>
			<nav class="footer-links" aria-label="<?php esc_attr_e( 'Footer navigation', 'xiujin' ); ?>">
				<a href="<?php echo esc_url( home_url( '/#collections' ) ); ?>"><?php esc_html_e( 'Chair categories', 'xiujin' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/#catalog' ) ); ?>"><?php esc_html_e( 'Product catalog', 'xiujin' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/#process' ) ); ?>"><?php esc_html_e( 'How to order', 'xiujin' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/#quote' ) ); ?>"><?php esc_html_e( 'Request a quote', 'xiujin' ); ?></a>
			</nav>
		</div>
		<div>
			<h2><?php esc_html_e( 'Contact', 'xiujin' ); ?></h2>
			<p><?php echo esc_html( xiujin_company_name() ); ?></p>
			<?php if ( $phone ) : ?><a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a><?php endif; ?>
			<?php if ( $email ) : ?><a href="<?php echo esc_url( 'mailto:' . $email ); ?>"><?php echo esc_html( $email ); ?></a><?php endif; ?>
		</div>
		<div>
			<h2><?php esc_html_e( 'Follow', 'xiujin' ); ?></h2>
			<?php xiujin_render_social_links(); ?>
		</div>
	</div>
	<div class="page-width footer-bottom">
		<p>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( xiujin_company_name() ); ?></p>
		<p><?php esc_html_e( 'Specifications, availability and commercial terms are confirmed for each order.', 'xiujin' ); ?></p>
	</div>
</footer>
<?php xiujin_render_social_links( 'floating-social' ); ?>
<div class="mobile-actions">
	<a href="<?php echo esc_url( home_url( '/#quote' ) ); ?>"><?php esc_html_e( 'Quote', 'xiujin' ); ?></a>
	<?php $whatsapp = (string) get_theme_mod( 'xiujin_whatsapp_url', '' ); ?>
	<?php if ( $whatsapp ) : ?><a href="<?php echo esc_url( $whatsapp ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'WhatsApp', 'xiujin' ); ?></a><?php endif; ?>
</div>
<?php wp_footer(); ?>
</body>
</html>

