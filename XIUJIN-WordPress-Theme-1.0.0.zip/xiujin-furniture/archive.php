<?php
/**
 * Archive template.
 *
 * @package Xiujin
 */
get_header();
?>
<main id="primary" class="site-main page-width content-index">
	<header class="archive-header"><span class="eyebrow"><?php esc_html_e( 'Archive', 'xiujin' ); ?></span><h1><?php the_archive_title(); ?></h1><?php the_archive_description( '<div class="archive-description">', '</div>' ); ?></header>
	<?php if ( have_posts() ) : ?><div class="post-grid"><?php while ( have_posts() ) : the_post(); ?><article <?php post_class( 'post-card' ); ?>><div><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><?php the_excerpt(); ?></div></article><?php endwhile; ?></div><?php the_posts_pagination(); ?><?php else : ?><p><?php esc_html_e( 'No content was found.', 'xiujin' ); ?></p><?php endif; ?>
</main>
<?php get_footer(); ?>

