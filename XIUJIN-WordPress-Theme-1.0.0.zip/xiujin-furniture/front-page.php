<?php
/**
 * XIUJIN home page.
 *
 * @package Xiujin
 */
get_header();
?>
<main id="primary" class="site-main home-main">
	<?php
	get_template_part( 'template-parts/home/hero' );
	get_template_part( 'template-parts/home/categories' );
	get_template_part( 'template-parts/home/catalog' );
	get_template_part( 'template-parts/home/configurations' );
	get_template_part( 'template-parts/home/showroom' );
	get_template_part( 'template-parts/home/factory' );
	get_template_part( 'template-parts/home/process' );
	get_template_part( 'template-parts/home/quote' );
	?>
</main>
<?php get_footer(); ?>
