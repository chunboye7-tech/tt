<?php
/**
 * Search results.
 *
 * @package Xiujin
 */
get_header();
?>
<main id="primary" class="site-main page-width content-index">
	<header class="archive-header"><span class="eyebrow"><?php esc_html_e( 'Search', 'xiujin' ); ?></span><h1><?php printf( esc_html__( 'Results for “%s”', 'xiujin' ), esc_html( get_search_query() ) ); ?></h1></header>
	<?php if ( have_posts() ) : ?><div class="post-grid"><?php while ( have_posts() ) : the_post(); ?><article <?php post_class( 'post-card' ); ?>><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><?php the_excerpt(); ?></article><?php endwhile; ?></div><?php the_posts_pagination(); ?><?php else : ?><p><?php esc_html_e( 'No matching content was found.', 'xiujin' ); ?></p><?php endif; ?>
</main>
<?php get_footer(); ?>

