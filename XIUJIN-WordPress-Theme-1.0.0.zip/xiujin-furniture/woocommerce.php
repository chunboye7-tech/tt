<?php
/**
 * WooCommerce catalog and product wrapper.
 *
 * Keeping the standard before/after actions preserves WooCommerce and
 * extension integration while the theme supplies its own wrapper markup via
 * inc/woocommerce.php.
 *
 * @package Xiujin
 */

get_header( 'shop' );

/**
 * Hook: woocommerce_before_main_content.
 *
 * @hooked xiujin_woocommerce_wrapper_start - 10
 * @hooked woocommerce_breadcrumb - 20
 */
do_action( 'woocommerce_before_main_content' );

woocommerce_content();

/**
 * Hook: woocommerce_after_main_content.
 *
 * @hooked xiujin_woocommerce_wrapper_end - 10
 */
do_action( 'woocommerce_after_main_content' );

get_footer( 'shop' );

