# Reproducible source inputs

This directory contains only the supplied product media and reviewed catalog
records required to rebuild the XIUJIN WordPress release. It deliberately
excludes the previous Shopify theme, generated delivery archives, screenshots,
temporary files and unrelated workspace data.

- `chair-trade-studio/catalog_copy.json`: reviewed source copy for 18 product series.
- `chair-trade-studio/delivery/`: verified 58-configuration mapping and image archive.
- `chair-trade-studio/xiujin-b2b-theme/assets/`: only the media/model sources used by the WordPress theme builder.
- `chair-trade-studio/uploaded-home-images/main-9.png`: supplied hero source image.
- `catalog-review/`: the 118 supplied catalog images and normalized media manifest.

The paths in `catalog-review/images.json` are relative, so the source archive
can be unpacked anywhere and rebuilt with `make all` after installing the
dependencies in `requirements-dev.txt` and `package-lock.json`.
