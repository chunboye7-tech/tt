<?php
/**
 * Secure, privacy-conscious product enquiry form.
 *
 * @package XiujinStoreCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the enquiry shortcode, handler and recipient setting.
 */
final class Xiujin_Inquiry {
	const OPTION_RECIPIENT = 'xiujin_inquiry_recipient_email';
	const ACTION           = 'xiujin_submit_inquiry';
	const NONCE_ACTION     = 'xiujin_inquiry_submit';
	const NONCE_NAME       = '_xiujin_inquiry_nonce';
	const RATE_LIMIT       = 5;
	const IP_RATE_LIMIT    = 10;
	const CONVERSION_QUERY = 'xiujin_conversion';
	const CONVERSION_TTL   = 600;
	const CONVERSION_PREFIX = 'xiujin_cv_';

	/**
	 * Attach hooks.
	 */
	public static function register() {
		add_shortcode( 'xiujin_inquiry_form', array( __CLASS__, 'render_shortcode' ) );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle_submission' ) );
		add_action( 'admin_post_nopriv_' . self::ACTION, array( __CLASS__, 'handle_submission' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_styles' ) );
		add_action( 'admin_menu', array( __CLASS__, 'register_settings_page' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_init', array( __CLASS__, 'add_privacy_policy_content' ) );
	}

	/**
	 * Load the small form stylesheet.
	 */
	public static function enqueue_styles() {
		wp_enqueue_style(
			'xiujin-store-core',
			XIUJIN_STORE_CORE_URL . 'assets/css/inquiry.css',
			array(),
			XIUJIN_STORE_CORE_VERSION
		);
	}

	/**
	 * Render a product-aware enquiry form.
	 *
	 * @param array $attributes Shortcode attributes.
	 * @return string
	 */
	public static function render_shortcode( $attributes ) {
		// Prevent full-page caches from serving expired nonce/timestamp pairs.
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}

		$attributes = shortcode_atts(
			array(
				'product'      => '',
				'button_label' => esc_html__( 'Send enquiry', 'xiujin-store-core' ),
			),
			$attributes,
			'xiujin_inquiry_form'
		);

		$product_name = is_scalar( $attributes['product'] ) ? sanitize_text_field( (string) $attributes['product'] ) : '';
		$product_id   = absint( self::query_scalar( 'product_id' ) );
		if (
			! $product_name &&
			$product_id &&
			'product' === get_post_type( $product_id ) &&
			'publish' === get_post_status( $product_id ) &&
			is_post_publicly_viewable( $product_id ) &&
			! post_password_required( $product_id )
		) {
			$product_name = get_the_title( $product_id );
		}

		if ( ! $product_name && function_exists( 'is_product' ) && is_product() ) {
			$product_name = get_the_title();
		}

		$status  = sanitize_key( self::query_scalar( 'xiujin_inquiry' ) );
		$started = time();
		$stamp   = self::sign_timestamp( $started );
		$form_id = wp_unique_id( 'xiujin-inquiry-' );

		ob_start();
		?>
		<div class="xiujin-inquiry-wrap">
			<?php self::render_status_message( $status ); ?>
			<form id="<?php echo esc_attr( $form_id ); ?>" class="xiujin-inquiry-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" accept-charset="UTF-8">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
				<input type="hidden" name="xiujin_started" value="<?php echo esc_attr( (string) $started ); ?>">
				<input type="hidden" name="xiujin_stamp" value="<?php echo esc_attr( $stamp ); ?>">
				<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>

				<div class="xiujin-inquiry-trap" aria-hidden="true">
					<label for="<?php echo esc_attr( $form_id ); ?>-website"><?php esc_html_e( 'Leave this field empty', 'xiujin-store-core' ); ?></label>
					<input id="<?php echo esc_attr( $form_id ); ?>-website" name="website" type="text" value="" tabindex="-1" autocomplete="off">
				</div>

				<div class="xiujin-inquiry-grid">
					<p class="xiujin-inquiry-field xiujin-inquiry-field--wide">
						<label for="<?php echo esc_attr( $form_id ); ?>-product"><?php esc_html_e( 'Product or chair category', 'xiujin-store-core' ); ?> <span aria-hidden="true">*</span></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-product" name="product" type="text" value="<?php echo esc_attr( $product_name ); ?>" maxlength="160" required autocomplete="off" data-product-field>
					</p>

					<p class="xiujin-inquiry-field">
						<label for="<?php echo esc_attr( $form_id ); ?>-quantity"><?php esc_html_e( 'Estimated quantity', 'xiujin-store-core' ); ?> <span aria-hidden="true">*</span></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-quantity" name="quantity" type="number" min="1" max="100000000" step="1" required inputmode="numeric">
					</p>

					<p class="xiujin-inquiry-field">
						<label for="<?php echo esc_attr( $form_id ); ?>-destination"><?php esc_html_e( 'Destination country or port', 'xiujin-store-core' ); ?> <span aria-hidden="true">*</span></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-destination" name="destination" type="text" maxlength="160" required autocomplete="country-name">
					</p>

					<p class="xiujin-inquiry-field">
						<label for="<?php echo esc_attr( $form_id ); ?>-company"><?php esc_html_e( 'Company', 'xiujin-store-core' ); ?></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-company" name="company" type="text" maxlength="160" autocomplete="organization">
					</p>

					<p class="xiujin-inquiry-field">
						<label for="<?php echo esc_attr( $form_id ); ?>-name"><?php esc_html_e( 'Contact name', 'xiujin-store-core' ); ?> <span aria-hidden="true">*</span></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-name" name="name" type="text" maxlength="120" required autocomplete="name">
					</p>

					<p class="xiujin-inquiry-field">
						<label for="<?php echo esc_attr( $form_id ); ?>-email"><?php esc_html_e( 'Business email', 'xiujin-store-core' ); ?> <span aria-hidden="true">*</span></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-email" name="email" type="email" maxlength="190" required autocomplete="email">
					</p>

					<p class="xiujin-inquiry-field">
						<label for="<?php echo esc_attr( $form_id ); ?>-whatsapp"><?php esc_html_e( 'WhatsApp or phone', 'xiujin-store-core' ); ?></label>
						<input id="<?php echo esc_attr( $form_id ); ?>-whatsapp" name="whatsapp" type="tel" maxlength="80" autocomplete="tel">
					</p>

					<p class="xiujin-inquiry-field xiujin-inquiry-field--wide">
						<label for="<?php echo esc_attr( $form_id ); ?>-requirements"><?php esc_html_e( 'Configuration and order requirements', 'xiujin-store-core' ); ?> <span aria-hidden="true">*</span></label>
						<textarea id="<?php echo esc_attr( $form_id ); ?>-requirements" name="requirements" rows="5" minlength="10" maxlength="2000" required></textarea>
					</p>
				</div>

				<label class="xiujin-inquiry-consent">
					<input type="checkbox" name="consent" value="1" required>
					<span><?php echo wp_kses( self::consent_copy(), self::consent_allowed_html() ); ?></span>
				</label>

				<p class="xiujin-inquiry-note"><?php esc_html_e( 'Required fields are marked with an asterisk. Product specifications, availability, lead time and pricing are confirmed in the quotation.', 'xiujin-store-core' ); ?></p>
				<button class="button button--gold xiujin-inquiry-submit" type="submit"><?php echo esc_html( $attributes['button_label'] ); ?></button>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Return localized consent copy, including the privacy-policy link when set.
	 *
	 * @return string
	 */
	private static function consent_copy() {
		$privacy_url = get_privacy_policy_url();
		if ( $privacy_url ) {
			return sprintf(
				/* translators: %s: privacy policy URL. */
				__( 'I agree that XIUJIN may use these details to respond to my enquiry. Read the <a href="%s" target="_blank" rel="privacy-policy noopener noreferrer">privacy policy</a>.', 'xiujin-store-core' ),
				esc_url( $privacy_url )
			);
		}

		return esc_html__( 'I agree that XIUJIN may use these details to respond to my enquiry.', 'xiujin-store-core' );
	}

	/**
	 * Restrict the translated consent copy to the one link used by the form.
	 *
	 * @return array
	 */
	private static function consent_allowed_html() {
		return array(
			'a' => array(
				'href'   => true,
				'target' => true,
				'rel'    => true,
			),
		);
	}

	/**
	 * Show an allowlisted result message.
	 *
	 * @param string $status Status slug.
	 */
	private static function render_status_message( $status ) {
		$messages = array(
			'success'      => array( 'success', esc_html__( 'Thank you. Your enquiry has been sent to our sales team.', 'xiujin-store-core' ) ),
			'invalid'      => array( 'error', esc_html__( 'Please review the required fields and try again.', 'xiujin-store-core' ) ),
			'expired'      => array( 'error', esc_html__( 'The form expired. Please reload the page and try again.', 'xiujin-store-core' ) ),
			'rate_limited' => array( 'error', esc_html__( 'Too many enquiries were submitted. Please wait before trying again.', 'xiujin-store-core' ) ),
			'failed'       => array( 'error', esc_html__( 'We could not send the enquiry. Please contact us by email or WhatsApp.', 'xiujin-store-core' ) ),
		);

		if ( ! isset( $messages[ $status ] ) ) {
			return;
		}

		printf(
			'<div class="xiujin-inquiry-message xiujin-inquiry-message--%1$s" role="status" aria-live="polite">%2$s</div>',
			esc_attr( $messages[ $status ][0] ),
			esc_html( $messages[ $status ][1] )
		);
	}

	/**
	 * Validate, rate limit and send a plain-text enquiry email.
	 */
	public static function handle_submission() {
		if ( 'POST' !== strtoupper( isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '' ) ) {
			self::redirect_with_status( 'invalid' );
		}

		$nonce = sanitize_text_field( self::post_scalar( self::NONCE_NAME ) );
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			self::redirect_with_status( 'expired' );
		}

		$honeypot = trim( sanitize_text_field( self::post_scalar( 'website' ) ) );
		if ( '' !== $honeypot ) {
			self::redirect_with_status( 'success' );
		}

		$started = absint( self::post_scalar( 'xiujin_started' ) );
		$stamp   = sanitize_text_field( self::post_scalar( 'xiujin_stamp' ) );
		$age     = time() - $started;
		if ( ! $started || ! hash_equals( self::sign_timestamp( $started ), $stamp ) || $age < 2 || $age > DAY_IN_SECONDS ) {
			self::redirect_with_status( 'expired' );
		}

		$data = self::validated_submission();
		if ( ! $data ) {
			self::redirect_with_status( 'invalid' );
		}

		if ( self::is_rate_limited( $data['email'] ) ) {
			self::redirect_with_status( 'rate_limited' );
		}

		$recipient = self::recipient_email();
		if ( ! is_email( $recipient ) ) {
			self::redirect_with_status( 'failed' );
		}

		/* translators: %s: requested product or category. */
		$subject = sprintf( __( 'New XIUJIN enquiry: %s', 'xiujin-store-core' ), $data['product'] );
		$subject = str_replace( array( "\r", "\n" ), '', $subject );
		$message = self::email_body( $data );
		$headers = array(
			'Content-Type: text/plain; charset=UTF-8',
			'Reply-To: <' . $data['email'] . '>',
		);

		$sent = wp_mail( $recipient, $subject, $message, $headers );
		if ( $sent ) {
			$conversion_token = class_exists( 'Xiujin_Tracking' ) && Xiujin_Tracking::is_configured()
				? self::create_conversion_token()
				: '';
			self::redirect_with_status( 'success', $conversion_token );
		}

		self::redirect_with_status( 'failed' );
	}

	/**
	 * Create a short-lived, single-use marker for a verified enquiry conversion.
	 *
	 * The payload intentionally excludes every submitted form value. Advertising
	 * integrations receive only an opaque event ID after the sales email was
	 * accepted by wp_mail(). If secure randomness is unavailable, the enquiry
	 * still succeeds without an advertising marker.
	 *
	 * @return string Random URL-safe token, or an empty string on failure.
	 */
	private static function create_conversion_token() {
		try {
			$token = bin2hex( random_bytes( 32 ) );
		} catch ( Exception $error ) {
			return '';
		}

		$payload = array(
			'event_id'   => wp_generate_uuid4(),
			'event_name' => 'lead',
			'created_at' => time(),
		);
		$key = self::CONVERSION_PREFIX . hash( 'sha256', $token );

		return set_transient( $key, $payload, self::CONVERSION_TTL ) ? $token : '';
	}

	/**
	 * Consume a verified enquiry conversion payload exactly once.
	 *
	 * Called by the optional tracking module while preparing front-end assets.
	 * Invalid, expired and replayed tokens return an empty array. The transient
	 * is deleted before returning so refreshing the confirmation page does not
	 * create another conversion. Platform event IDs provide an additional layer
	 * of deduplication for concurrent requests.
	 *
	 * @return array Event payload containing event_id and event_name, or empty.
	 */
	public static function consume_conversion_payload() {
		$token = strtolower( trim( self::query_scalar( self::CONVERSION_QUERY ) ) );
		if ( '' === $token ) {
			return array();
		}

		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}

		if ( ! preg_match( '/^[a-f0-9]{64}$/D', $token ) ) {
			return array();
		}

		$key     = self::CONVERSION_PREFIX . hash( 'sha256', $token );
		$payload = get_transient( $key );
		$deleted = delete_transient( $key );

		// Only the request that successfully removes the marker may report it.
		// This also prevents a second near-simultaneous request from counting it.
		if ( ! is_array( $payload ) || ! $deleted ) {
			return array();
		}

		$event_id   = isset( $payload['event_id'] ) && is_string( $payload['event_id'] ) ? strtolower( $payload['event_id'] ) : '';
		$event_name = isset( $payload['event_name'] ) && is_string( $payload['event_name'] ) ? sanitize_key( $payload['event_name'] ) : '';
		$created_at = isset( $payload['created_at'] ) ? absint( $payload['created_at'] ) : 0;
		$age        = time() - $created_at;

		if (
			'lead' !== $event_name ||
			! preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/D', $event_id ) ||
			! $created_at ||
			$age < -60 ||
			$age > self::CONVERSION_TTL
		) {
			return array();
		}

		return array(
			'event_id'   => $event_id,
			'event_name' => $event_name,
		);
	}

	/**
	 * Return sanitized data only when required fields are valid.
	 *
	 * @return array|false
	 */
	private static function validated_submission() {
		$quantity_raw = self::post_scalar( 'quantity' );
		$quantity     = preg_match( '/^[0-9]+$/D', $quantity_raw ) ? (int) $quantity_raw : 0;
		$data = array(
			'product'      => self::post_text( 'product', 160 ),
			'quantity'     => $quantity,
			'destination'  => self::post_text( 'destination', 160 ),
			'company'      => self::post_text( 'company', 160 ),
			'name'         => self::post_text( 'name', 120 ),
			'email'        => sanitize_email( self::post_scalar( 'email' ) ),
			'whatsapp'     => self::post_text( 'whatsapp', 80 ),
			'requirements' => sanitize_textarea_field( self::post_scalar( 'requirements' ) ),
			'consent'      => '1' === sanitize_text_field( self::post_scalar( 'consent' ) ),
		);

		$data['requirements'] = function_exists( 'mb_substr' ) ? mb_substr( $data['requirements'], 0, 2000 ) : substr( $data['requirements'], 0, 2000 );

		if (
			! $data['product'] ||
			$data['quantity'] < 1 ||
			$data['quantity'] > 100000000 ||
			! $data['destination'] ||
			! $data['name'] ||
			! is_email( $data['email'] ) ||
			self::text_length( $data['requirements'] ) < 10 ||
			! $data['consent']
		) {
			return false;
		}

		return $data;
	}

	/**
	 * Read and length-limit one plain-text POST value.
	 *
	 * @param string $key    Field key.
	 * @param int    $length Maximum characters.
	 * @return string
	 */
	private static function post_text( $key, $length ) {
		$value = sanitize_text_field( self::post_scalar( $key ) );
		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, $length ) : substr( $value, 0, $length );
	}

	/**
	 * Read a scalar POST field and reject array-shaped input.
	 *
	 * @param string $key Field key.
	 * @return string
	 */
	private static function post_scalar( $key ) {
		if ( ! isset( $_POST[ $key ] ) || ! is_string( $_POST[ $key ] ) ) {
			return '';
		}

		return wp_unslash( $_POST[ $key ] );
	}

	/**
	 * Read a scalar query field and reject array-shaped input.
	 *
	 * @param string $key Field key.
	 * @return string
	 */
	private static function query_scalar( $key ) {
		if ( ! isset( $_GET[ $key ] ) || ! is_string( $_GET[ $key ] ) ) {
			return '';
		}

		return wp_unslash( $_GET[ $key ] );
	}

	/**
	 * Count text characters when the multibyte extension is available.
	 *
	 * @param string $value Text to count.
	 * @return int
	 */
	private static function text_length( $value ) {
		return function_exists( 'mb_strlen' ) ? mb_strlen( $value ) : strlen( $value );
	}

	/**
	 * Create a signed form-start timestamp.
	 *
	 * @param int $started Unix timestamp.
	 * @return string
	 */
	private static function sign_timestamp( $started ) {
		return hash_hmac( 'sha256', (string) $started, wp_salt( 'nonce' ) );
	}

	/**
	 * Apply privacy-preserving per-address and per-email hourly limits.
	 *
	 * @param string $email Validated email address.
	 * @return bool
	 */
	private static function is_rate_limited( $email ) {
		$raw_ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$ip        = filter_var( $raw_ip, FILTER_VALIDATE_IP ) ? $raw_ip : 'unknown';
		$salt      = wp_salt( 'auth' );
		$email_key = 'xiujin_em_' . substr( hash_hmac( 'sha256', strtolower( $email ), $salt ), 0, 32 );
		$ip_key    = 'xiujin_ip_' . substr( hash_hmac( 'sha256', $ip, $salt ), 0, 32 );
		$email_hits = absint( get_transient( $email_key ) );
		$ip_hits    = absint( get_transient( $ip_key ) );

		if ( $email_hits >= self::RATE_LIMIT || $ip_hits >= self::IP_RATE_LIMIT ) {
			return true;
		}

		set_transient( $email_key, $email_hits + 1, HOUR_IN_SECONDS );
		set_transient( $ip_key, $ip_hits + 1, HOUR_IN_SECONDS );
		return false;
	}

	/**
	 * Build the sales email without HTML or untrusted headers.
	 *
	 * @param array $data Validated submission.
	 * @return string
	 */
	private static function email_body( $data ) {
		$labels = array(
			'product'      => __( 'Product or category', 'xiujin-store-core' ),
			'quantity'     => __( 'Estimated quantity', 'xiujin-store-core' ),
			'destination'  => __( 'Destination', 'xiujin-store-core' ),
			'company'      => __( 'Company', 'xiujin-store-core' ),
			'name'         => __( 'Contact name', 'xiujin-store-core' ),
			'email'        => __( 'Email', 'xiujin-store-core' ),
			'whatsapp'     => __( 'WhatsApp or phone', 'xiujin-store-core' ),
			'requirements' => __( 'Requirements', 'xiujin-store-core' ),
		);
		$lines  = array( __( 'New website enquiry', 'xiujin-store-core' ), str_repeat( '-', 28 ) );

		foreach ( $labels as $key => $label ) {
			$value   = isset( $data[ $key ] ) && '' !== (string) $data[ $key ] ? (string) $data[ $key ] : __( 'Not provided', 'xiujin-store-core' );
			$lines[] = $label . ': ' . $value;
		}

		$source_page = self::source_page_url();
		if ( $source_page ) {
			$lines[] = __( 'Source page', 'xiujin-store-core' ) . ': ' . $source_page;
		}

		return implode( "\n", $lines );
	}

	/**
	 * Return a same-origin source URL without query data or credentials.
	 *
	 * The route helps the sales team understand the enquiry context while
	 * avoiding disclosure of campaign parameters, search terms or account URLs.
	 *
	 * @return string
	 */
	private static function source_page_url() {
		$referer = wp_get_referer();
		if ( ! $referer ) {
			return '';
		}

		$referer = wp_validate_redirect( $referer, '' );
		$home    = wp_parse_url( xiujin_store_home_url() );
		$source  = wp_parse_url( $referer );
		if (
			! $referer ||
			! is_array( $home ) ||
			! is_array( $source ) ||
			empty( $home['host'] ) ||
			empty( $source['host'] ) ||
			0 !== strcasecmp( $home['host'], $source['host'] )
		) {
			return '';
		}

		$scheme = isset( $home['scheme'] ) && 'https' === strtolower( $home['scheme'] ) ? 'https' : 'http';
		$path   = isset( $source['path'] ) ? '/' . ltrim( $source['path'], '/' ) : '/';
		return esc_url_raw( $scheme . '://' . $home['host'] . $path );
	}

	/**
	 * Return the configured valid recipient or the site administrator email.
	 *
	 * @return string
	 */
	private static function recipient_email() {
		$recipient = sanitize_email( get_option( self::OPTION_RECIPIENT, '' ) );
		return is_email( $recipient ) ? $recipient : sanitize_email( get_option( 'admin_email' ) );
	}

	/**
	 * Redirect back to a same-site page with an allowlisted status.
	 *
	 * @param string $status           Result slug.
	 * @param string $conversion_token Optional verified-conversion token.
	 */
	private static function redirect_with_status( $status, $conversion_token = '' ) {
		$allowed = array( 'success', 'invalid', 'expired', 'rate_limited', 'failed' );
		$status  = in_array( $status, $allowed, true ) ? $status : 'failed';
		$referer = wp_get_referer();
		$target  = wp_validate_redirect( $referer ? $referer : '', xiujin_store_home_url() );
		$target  = remove_query_arg( array( 'xiujin_inquiry', self::CONVERSION_QUERY ), $target );
		$target  = add_query_arg( 'xiujin_inquiry', $status, $target );
		if ( 'success' === $status && preg_match( '/^[a-f0-9]{64}$/D', $conversion_token ) ) {
			$target = add_query_arg( self::CONVERSION_QUERY, $conversion_token, $target );
		}
		$target  = strtok( $target, '#' ) . '#quote';

		nocache_headers();
		wp_safe_redirect( $target, 303, 'XIUJIN Store Core' );
		exit;
	}

	/**
	 * Register the recipient setting.
	 */
	public static function register_settings() {
		register_setting(
			'xiujin_inquiry_settings',
			self::OPTION_RECIPIENT,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( __CLASS__, 'sanitize_recipient' ),
				'default'           => '',
			)
		);

		register_setting(
			'xiujin_inquiry_settings',
			Xiujin_Product_Fields::OPTION_CHECKOUT,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( __CLASS__, 'sanitize_checkout_setting' ),
				'default'           => 'no',
			)
		);

		add_settings_section(
			'xiujin_inquiry_delivery',
			esc_html__( 'Enquiry delivery', 'xiujin-store-core' ),
			'__return_false',
			'xiujin-inquiries'
		);

		add_settings_field(
			self::OPTION_RECIPIENT,
			esc_html__( 'Recipient email', 'xiujin-store-core' ),
			array( __CLASS__, 'render_recipient_field' ),
			'xiujin-inquiries',
			'xiujin_inquiry_delivery'
		);

		add_settings_field(
			Xiujin_Product_Fields::OPTION_CHECKOUT,
			esc_html__( 'Online checkout', 'xiujin-store-core' ),
			array( __CLASS__, 'render_checkout_field' ),
			'xiujin-inquiries',
			'xiujin_inquiry_delivery'
		);
	}

	/**
	 * Add the plugin page under Settings.
	 */
	public static function register_settings_page() {
		add_options_page(
			esc_html__( 'XIUJIN enquiries', 'xiujin-store-core' ),
			esc_html__( 'XIUJIN enquiries', 'xiujin-store-core' ),
			'manage_options',
			'xiujin-inquiries',
			array( __CLASS__, 'render_settings_page' )
		);
	}

	/**
	 * Validate the configured recipient.
	 *
	 * @param string $value Submitted email.
	 * @return string
	 */
	public static function sanitize_recipient( $value ) {
		$raw   = is_scalar( $value ) ? trim( (string) $value ) : '';
		$email = sanitize_email( $raw );
		if ( $raw && ! is_email( $email ) ) {
			add_settings_error(
				self::OPTION_RECIPIENT,
				'xiujin_invalid_recipient',
				esc_html__( 'Enter a valid recipient email address.', 'xiujin-store-core' )
			);
			$current = sanitize_email( get_option( self::OPTION_RECIPIENT, '' ) );
			return is_email( $current ) ? $current : '';
		}
		return $email;
	}

	/**
	 * Store the global checkout gate as an explicit yes/no value.
	 *
	 * @param mixed $value Submitted checkbox value.
	 * @return string
	 */
	public static function sanitize_checkout_setting( $value ) {
		return is_string( $value ) && 'yes' === $value ? 'yes' : 'no';
	}

	/**
	 * Explain the plugin's limited processing in WordPress's privacy guide.
	 */
	public static function add_privacy_policy_content() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		$content  = '<p class="privacy-policy-tutorial">' . esc_html__( 'Suggested text:', 'xiujin-store-core' ) . '</p>';
		$content .= '<p>' . esc_html__( 'When you submit a quotation enquiry, the product, quantity, destination, company, contact details and requirements you provide are emailed to our sales recipient so we can respond. The enquiry content is not saved in the WordPress database by this plugin. Pseudonymous email-address and network-address hashes may be retained in temporary rate-limit records for up to one hour to reduce spam. Your email provider may retain the delivered message under its own retention policy.', 'xiujin-store-core' ) . '</p>';
		$content .= '<p>' . esc_html__( 'After an enquiry email is accepted for sending, a random non-personal conversion marker may be retained for up to ten minutes so consented advertising measurement can count the enquiry once.', 'xiujin-store-core' ) . '</p>';

		wp_add_privacy_policy_content(
			esc_html__( 'XIUJIN quotation enquiries', 'xiujin-store-core' ),
			wp_kses_post( wpautop( $content, false ) )
		);
	}

	/**
	 * Render the recipient field.
	 */
	public static function render_recipient_field() {
		$value = get_option( self::OPTION_RECIPIENT, '' );
		printf(
			'<input class="regular-text" type="email" name="%1$s" value="%2$s" autocomplete="email"><p class="description">%3$s</p>',
			esc_attr( self::OPTION_RECIPIENT ),
			esc_attr( $value ),
			esc_html__( 'Leave empty to use the WordPress administration email.', 'xiujin-store-core' )
		);
	}

	/**
	 * Render the opt-in global online-checkout gate.
	 */
	public static function render_checkout_field() {
		$value = get_option( Xiujin_Product_Fields::OPTION_CHECKOUT, 'no' );
		printf(
			'<input type="hidden" name="%1$s" value="no"><label><input type="checkbox" name="%1$s" value="yes" %2$s> %3$s</label><p class="description">%4$s</p>',
			esc_attr( Xiujin_Product_Fields::OPTION_CHECKOUT ),
			checked( 'yes', $value, false ),
			esc_html__( 'Enable WooCommerce cart and online checkout', 'xiujin-store-core' ),
			esc_html__( 'Leave this off for the current enquiry-only wholesale and retail catalogue. Enabling it does not make a product purchasable unless that product also uses the Online checkout purchase path.', 'xiujin-store-core' )
		);
	}

	/**
	 * Render the settings page.
	 */
	public static function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'XIUJIN enquiry settings', 'xiujin-store-core' ); ?></h1>
			<p><?php esc_html_e( 'Choose where validated website enquiries are delivered. Online checkout is disabled by default. Test mail delivery before launching the site.', 'xiujin-store-core' ); ?></p>
			<form action="options.php" method="post">
				<?php
				settings_fields( 'xiujin_inquiry_settings' );
				do_settings_sections( 'xiujin-inquiries' );
				submit_button();
				?>
			</form>
		</div>
		<?php
	}
}

