<?php
/**
 * Consent-aware advertising and analytics measurement.
 *
 * @package XiujinStoreCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers public pixel identifiers, consent controls and verified lead data.
 */
final class Xiujin_Tracking {
	const SETTINGS_GROUP = 'xiujin_tracking_settings';
	const SETTINGS_PAGE  = 'xiujin-tracking';

	const OPTION_GOOGLE_ADS_ID = 'xiujin_tracking_google_ads_id';
	const OPTION_GOOGLE_LABEL  = 'xiujin_tracking_google_conversion_label';
	const OPTION_GA4_ID         = 'xiujin_tracking_ga4_id';
	const OPTION_META_PIXEL_ID  = 'xiujin_tracking_meta_pixel_id';
	const OPTION_TIKTOK_PIXEL_ID = 'xiujin_tracking_tiktok_pixel_id';

	const CONSENT_KEY     = 'xiujin_tracking_consent_v1';
	const CONVERSION_QUERY = 'xiujin_conversion';

	/**
	 * Whether the one-time conversion token has already been checked this request.
	 *
	 * @var bool
	 */
	private static $conversion_consumed = false;

	/**
	 * Sanitized conversion data retained for repeated enqueue calls.
	 *
	 * @var array
	 */
	private static $conversion_payload = array();

	/**
	 * Attach module hooks.
	 */
	public static function register() {
		add_action( 'admin_menu', array( __CLASS__, 'register_settings_page' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_init', array( __CLASS__, 'add_privacy_policy_content' ) );
		add_action( 'template_redirect', array( __CLASS__, 'prevent_conversion_page_cache' ), 0 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'wp_footer', array( __CLASS__, 'render_consent_banner' ), 5 );
	}

	/**
	 * Add the measurement settings page.
	 */
	public static function register_settings_page() {
		add_options_page(
			esc_html__( 'XIUJIN advertising measurement', 'xiujin-store-core' ),
			esc_html__( 'XIUJIN tracking', 'xiujin-store-core' ),
			'manage_options',
			self::SETTINGS_PAGE,
			array( __CLASS__, 'render_settings_page' )
		);
	}

	/**
	 * Register identifier settings and their fields.
	 */
	public static function register_settings() {
		self::register_option( self::OPTION_GOOGLE_ADS_ID, 'sanitize_google_ads_id' );
		self::register_option( self::OPTION_GOOGLE_LABEL, 'sanitize_google_conversion_label' );
		self::register_option( self::OPTION_GA4_ID, 'sanitize_ga4_id' );
		self::register_option( self::OPTION_META_PIXEL_ID, 'sanitize_meta_pixel_id' );
		self::register_option( self::OPTION_TIKTOK_PIXEL_ID, 'sanitize_tiktok_pixel_id' );

		add_settings_section(
			'xiujin_tracking_identifiers',
			esc_html__( 'Analytics and advertising identifiers', 'xiujin-store-core' ),
			array( __CLASS__, 'render_settings_section' ),
			self::SETTINGS_PAGE
		);

		self::add_field(
			self::OPTION_GOOGLE_ADS_ID,
			__( 'Google Ads conversion ID', 'xiujin-store-core' ),
			__( 'Enter the public conversion ID in the format AW-123456789. Google Ads remains disabled until both this ID and a valid conversion label are saved.', 'xiujin-store-core' )
		);
		self::add_field(
			self::OPTION_GOOGLE_LABEL,
			__( 'Google Ads conversion label', 'xiujin-store-core' ),
			__( 'Enter the conversion action label shown in the Google Ads event snippet. It contains letters, numbers, hyphens or underscores.', 'xiujin-store-core' )
		);
		self::add_field(
			self::OPTION_GA4_ID,
			__( 'Google Analytics 4 measurement ID', 'xiujin-store-core' ),
			__( 'Optional. Enter the public web data stream ID in the format G-AB12CDE345.', 'xiujin-store-core' )
		);
		self::add_field(
			self::OPTION_META_PIXEL_ID,
			__( 'Meta Pixel ID', 'xiujin-store-core' ),
			__( 'Enter the numeric public Pixel ID from Meta Events Manager.', 'xiujin-store-core' ),
			'numeric'
		);
		self::add_field(
			self::OPTION_TIKTOK_PIXEL_ID,
			__( 'TikTok Pixel ID', 'xiujin-store-core' ),
			__( 'Enter the public alphanumeric Pixel ID from TikTok Ads Manager.', 'xiujin-store-core' )
		);
	}

	/**
	 * Register one string option.
	 *
	 * @param string $option   Option name.
	 * @param string $callback Sanitization method name.
	 */
	private static function register_option( $option, $callback ) {
		register_setting(
			self::SETTINGS_GROUP,
			$option,
			array(
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => array( __CLASS__, $callback ),
			)
		);
	}

	/**
	 * Add one settings field.
	 *
	 * @param string $option      Option name.
	 * @param string $label       Translated field label.
	 * @param string $description Translated help text.
	 * @param string $inputmode   Optional input mode.
	 */
	private static function add_field( $option, $label, $description, $inputmode = 'text' ) {
		add_settings_field(
			$option,
			$label,
			array( __CLASS__, 'render_text_field' ),
			self::SETTINGS_PAGE,
			'xiujin_tracking_identifiers',
			array(
				'label_for'   => $option,
				'option'      => $option,
				'description' => $description,
				'inputmode'   => $inputmode,
			)
		);
	}

	/**
	 * Explain how the browser integrations behave.
	 */
	public static function render_settings_section() {
		?>
		<p><?php esc_html_e( 'Leave an identifier blank to disable that service. Configured services load only after a visitor accepts analytics and advertising cookies.', 'xiujin-store-core' ); ?></p>
		<p><?php esc_html_e( 'A Lead event is sent only after a validated enquiry email is accepted for sending. Contact names, email addresses, phone numbers and message contents are never included in the tracking configuration.', 'xiujin-store-core' ); ?></p>
		<p><?php esc_html_e( 'Enter public tag identifiers only. Do not enter API keys, access tokens or account passwords.', 'xiujin-store-core' ); ?></p>
		<?php
	}

	/**
	 * Render an identifier input.
	 *
	 * @param array $args Field arguments.
	 */
	public static function render_text_field( $args ) {
		$option      = isset( $args['option'] ) ? (string) $args['option'] : '';
		$description = isset( $args['description'] ) ? (string) $args['description'] : '';
		$inputmode   = isset( $args['inputmode'] ) ? (string) $args['inputmode'] : 'text';
		$value       = self::option_value( $option );
		?>
		<input
			id="<?php echo esc_attr( $option ); ?>"
			name="<?php echo esc_attr( $option ); ?>"
			type="text"
			class="regular-text code"
			value="<?php echo esc_attr( $value ); ?>"
			inputmode="<?php echo esc_attr( $inputmode ); ?>"
			autocomplete="off"
			spellcheck="false"
		>
		<?php if ( '' !== $description ) : ?>
			<p class="description"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render the administration page.
	 */
	public static function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage tracking settings.', 'xiujin-store-core' ) );
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'XIUJIN advertising measurement', 'xiujin-store-core' ); ?></h1>
			<?php settings_errors( self::SETTINGS_PAGE ); ?>
			<form action="options.php" method="post">
				<?php
				settings_fields( self::SETTINGS_GROUP );
				do_settings_sections( self::SETTINGS_PAGE );
				submit_button( esc_html__( 'Save measurement settings', 'xiujin-store-core' ) );
				?>
			</form>
		</div>
		<?php
	}

	/**
	 * Add suggested disclosure text to WordPress's privacy-policy guide.
	 */
	public static function add_privacy_policy_content() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		$content  = '<p>' . esc_html__( 'This site offers a choice before loading optional analytics and advertising services. If a visitor accepts, the selected services may receive public tag identifiers, the page URL, browser and device information, and a random event identifier. The site stores the visitor’s choice in local storage and a cookie for up to 180 days.', 'xiujin-store-core' ) . '</p>';
		$content .= '<p>' . esc_html__( 'After a validated enquiry email is accepted for sending, configured services may receive one Lead event with a random identifier. The event does not include the visitor’s name, email address, phone number, company, product requirements or message contents.', 'xiujin-store-core' ) . '</p>';
		$content .= '<p>' . esc_html__( 'Visitors can reopen Privacy choices to change their selection. Selecting necessary cookies only prevents the optional Google, Meta and TikTok browser tags from loading.', 'xiujin-store-core' ) . '</p>';

		wp_add_privacy_policy_content(
			esc_html__( 'XIUJIN advertising measurement', 'xiujin-store-core' ),
			wp_kses_post( $content )
		);
	}

	/**
	 * Sanitize a Google Ads conversion ID.
	 *
	 * @param mixed $value Submitted value.
	 * @return string
	 */
	public static function sanitize_google_ads_id( $value ) {
		$value = strtoupper( self::normalize_setting( $value ) );
		return self::validated_setting(
			$value,
			'/^AW-[0-9]{5,20}$/D',
			'invalid_google_ads_id',
			__( 'The Google Ads conversion ID was not saved. Use the format AW-123456789.', 'xiujin-store-core' )
		);
	}

	/**
	 * Sanitize a Google Ads conversion label.
	 *
	 * @param mixed $value Submitted value.
	 * @return string
	 */
	public static function sanitize_google_conversion_label( $value ) {
		$value = self::normalize_setting( $value );
		return self::validated_setting(
			$value,
			'/^[A-Za-z0-9_-]{3,120}$/D',
			'invalid_google_conversion_label',
			__( 'The Google Ads conversion label was not saved. Use 3 to 120 letters, numbers, hyphens or underscores.', 'xiujin-store-core' )
		);
	}

	/**
	 * Sanitize a GA4 measurement ID.
	 *
	 * @param mixed $value Submitted value.
	 * @return string
	 */
	public static function sanitize_ga4_id( $value ) {
		$value = strtoupper( self::normalize_setting( $value ) );
		return self::validated_setting(
			$value,
			'/^G-[A-Z0-9]{5,20}$/D',
			'invalid_ga4_id',
			__( 'The Google Analytics 4 measurement ID was not saved. Use the format G-AB12CDE345.', 'xiujin-store-core' )
		);
	}

	/**
	 * Sanitize a Meta Pixel ID.
	 *
	 * @param mixed $value Submitted value.
	 * @return string
	 */
	public static function sanitize_meta_pixel_id( $value ) {
		$value = self::normalize_setting( $value );
		return self::validated_setting(
			$value,
			'/^[0-9]{5,20}$/D',
			'invalid_meta_pixel_id',
			__( 'The Meta Pixel ID was not saved. Enter 5 to 20 numbers.', 'xiujin-store-core' )
		);
	}

	/**
	 * Sanitize a TikTok Pixel ID.
	 *
	 * @param mixed $value Submitted value.
	 * @return string
	 */
	public static function sanitize_tiktok_pixel_id( $value ) {
		$value = strtoupper( self::normalize_setting( $value ) );
		return self::validated_setting(
			$value,
			'/^[A-Z0-9]{10,32}$/D',
			'invalid_tiktok_pixel_id',
			__( 'The TikTok Pixel ID was not saved. Enter 10 to 32 letters or numbers.', 'xiujin-store-core' )
		);
	}

	/**
	 * Return a valid setting or disable the invalid identifier.
	 *
	 * @param string $value   Normalized setting.
	 * @param string $pattern Validation expression.
	 * @param string $code    Settings error code.
	 * @param string $message Translated error message.
	 * @return string
	 */
	private static function validated_setting( $value, $pattern, $code, $message ) {
		if ( '' === $value ) {
			return '';
		}

		if ( preg_match( $pattern, $value ) ) {
			return $value;
		}

		add_settings_error( self::SETTINGS_PAGE, $code, $message, 'error' );
		return '';
	}

	/**
	 * Normalize a scalar setting without interpreting it as markup.
	 *
	 * @param mixed $value Submitted value.
	 * @return string
	 */
	private static function normalize_setting( $value ) {
		if ( ! is_scalar( $value ) ) {
			return '';
		}

		return trim( sanitize_text_field( (string) $value ) );
	}

	/**
	 * Prevent a verified-conversion URL from being stored in a full-page cache.
	 */
	public static function prevent_conversion_page_cache() {
		$token = strtolower( self::query_scalar( self::CONVERSION_QUERY ) );
		if ( ! preg_match( '/^[a-f0-9]{64}$/D', $token ) ) {
			return;
		}

		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		nocache_headers();
	}

	/**
	 * Enqueue the consent controller only when a platform is configured.
	 */
	public static function enqueue_assets() {
		$platforms = self::platform_configuration();
		if ( ! self::is_configured() ) {
			return;
		}

		wp_enqueue_style(
			'xiujin-tracking',
			XIUJIN_STORE_CORE_URL . 'assets/css/tracking.css',
			array(),
			XIUJIN_STORE_CORE_VERSION
		);
		wp_enqueue_script(
			'xiujin-tracking',
			XIUJIN_STORE_CORE_URL . 'assets/js/tracking.js',
			array(),
			XIUJIN_STORE_CORE_VERSION,
			true
		);

		$conversion = self::conversion_payload();
		$lead       = array(
			'eventId'   => isset( $conversion['event_id'] ) ? $conversion['event_id'] : '',
			'eventName' => isset( $conversion['event_name'] ) ? $conversion['event_name'] : '',
			'queryKeys' => array( self::CONVERSION_QUERY ),
		);

		wp_localize_script(
			'xiujin-tracking',
			'xiujinTracking',
			array(
				'platforms' => $platforms,
				'consentKey' => self::CONSENT_KEY,
				'privacyUrl' => esc_url_raw( get_privacy_policy_url() ),
				'strings'    => array(
					'consentTitle'       => __( 'Privacy choices', 'xiujin-store-core' ),
					'consentDescription' => __( 'Choose whether analytics and advertising services may measure site visits and confirmed enquiries. Contact details are never sent to these services.', 'xiujin-store-core' ),
					'privacyLabel'       => __( 'Privacy policy', 'xiujin-store-core' ),
					'essentialLabel'     => __( 'Use necessary cookies only', 'xiujin-store-core' ),
					'acceptLabel'        => __( 'Accept analytics and advertising', 'xiujin-store-core' ),
					'settingsLabel'      => __( 'Privacy choices', 'xiujin-store-core' ),
				),
				'lead'       => $lead,
			)
		);
	}

	/**
	 * Render an accessible consent interface for the JavaScript controller.
	 */
	public static function render_consent_banner() {
		if ( ! self::is_configured() ) {
			return;
		}

		$privacy_url = get_privacy_policy_url();
		?>
		<section
			id="xiujin-consent-banner"
			class="xiujin-consent"
			data-xiujin-consent
			role="region"
			aria-live="polite"
			aria-labelledby="xiujin-consent-title"
			aria-describedby="xiujin-consent-description"
			hidden
		>
			<div class="xiujin-consent__content">
				<div class="xiujin-consent__copy">
					<strong id="xiujin-consent-title"><?php esc_html_e( 'Privacy choices', 'xiujin-store-core' ); ?></strong>
					<p id="xiujin-consent-description"><?php esc_html_e( 'Choose whether analytics and advertising services may measure site visits and confirmed enquiries. Contact details are never sent to these services.', 'xiujin-store-core' ); ?></p>
					<?php if ( $privacy_url ) : ?>
						<a class="xiujin-consent__privacy" href="<?php echo esc_url( $privacy_url ); ?>" rel="privacy-policy"><?php esc_html_e( 'Privacy policy', 'xiujin-store-core' ); ?></a>
					<?php endif; ?>
				</div>
				<div class="xiujin-consent__actions">
					<button class="xiujin-consent__button xiujin-consent__button--secondary" type="button" data-xiujin-consent-essential><?php esc_html_e( 'Use necessary cookies only', 'xiujin-store-core' ); ?></button>
					<button class="xiujin-consent__button xiujin-consent__button--primary" type="button" data-xiujin-consent-accept><?php esc_html_e( 'Accept analytics and advertising', 'xiujin-store-core' ); ?></button>
				</div>
			</div>
		</section>
		<button
			class="xiujin-consent-settings"
			type="button"
			data-xiujin-consent-settings
			aria-controls="xiujin-consent-banner"
			aria-expanded="false"
			hidden
		><?php esc_html_e( 'Privacy choices', 'xiujin-store-core' ); ?></button>
		<?php
	}

	/**
	 * Return validated public identifiers, withholding incomplete Ads settings.
	 *
	 * @return array
	 */
	private static function platform_configuration() {
		$google_ads_id = self::option_value( self::OPTION_GOOGLE_ADS_ID );
		$google_label  = self::option_value( self::OPTION_GOOGLE_LABEL );
		$ga4_id        = self::option_value( self::OPTION_GA4_ID );
		$meta_id       = self::option_value( self::OPTION_META_PIXEL_ID );
		$tiktok_id     = self::option_value( self::OPTION_TIKTOK_PIXEL_ID );

		if ( ! preg_match( '/^AW-[0-9]{5,20}$/D', $google_ads_id ) || ! preg_match( '/^[A-Za-z0-9_-]{3,120}$/D', $google_label ) ) {
			$google_ads_id = '';
			$google_label  = '';
		}

		return array(
			'googleAdsId'    => $google_ads_id,
			'googleAdsLabel' => $google_label,
			'ga4Id'          => preg_match( '/^G-[A-Z0-9]{5,20}$/D', $ga4_id ) ? $ga4_id : '',
			'metaPixelId'    => preg_match( '/^[0-9]{5,20}$/D', $meta_id ) ? $meta_id : '',
			'tiktokPixelId'  => preg_match( '/^[A-Z0-9]{10,32}$/D', $tiktok_id ) ? $tiktok_id : '',
		);
	}

	/**
	 * Whether at least one platform has a complete, valid configuration.
	 *
	 * Inquiry handling uses this to avoid creating conversion markers while all
	 * tracking integrations are disabled.
	 *
	 * @return bool
	 */
	public static function is_configured() {
		return self::has_platform( self::platform_configuration() );
	}

	/**
	 * Whether any supported browser integration can run.
	 *
	 * @param array $platforms Validated platform data.
	 * @return bool
	 */
	private static function has_platform( $platforms ) {
		return ! empty( $platforms['googleAdsId'] )
			|| ! empty( $platforms['ga4Id'] )
			|| ! empty( $platforms['metaPixelId'] )
			|| ! empty( $platforms['tiktokPixelId'] );
	}

	/**
	 * Consume and validate the inquiry module's non-personal one-time payload.
	 *
	 * @return array
	 */
	private static function conversion_payload() {
		if ( self::$conversion_consumed ) {
			return self::$conversion_payload;
		}
		self::$conversion_consumed = true;

		if ( ! class_exists( 'Xiujin_Inquiry' ) || ! method_exists( 'Xiujin_Inquiry', 'consume_conversion_payload' ) ) {
			return array();
		}

		$payload = Xiujin_Inquiry::consume_conversion_payload();
		if ( ! is_array( $payload ) ) {
			return array();
		}

		$event_id   = isset( $payload['event_id'] ) && is_string( $payload['event_id'] ) ? strtolower( $payload['event_id'] ) : '';
		$event_name = isset( $payload['event_name'] ) && is_string( $payload['event_name'] ) ? sanitize_key( $payload['event_name'] ) : '';

		if ( 'lead' !== $event_name || ! preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/D', $event_id ) ) {
			return array();
		}

		self::$conversion_payload = array(
			'event_id'   => $event_id,
			'event_name' => $event_name,
		);
		return self::$conversion_payload;
	}

	/**
	 * Read an option as a trimmed scalar string.
	 *
	 * @param string $option Option name.
	 * @return string
	 */
	private static function option_value( $option ) {
		$value = get_option( $option, '' );
		return is_scalar( $value ) ? trim( (string) $value ) : '';
	}

	/**
	 * Read one scalar query argument.
	 *
	 * @param string $key Query argument name.
	 * @return string
	 */
	private static function query_scalar( $key ) {
		if ( ! isset( $_GET[ $key ] ) || ! is_scalar( $_GET[ $key ] ) ) {
			return '';
		}

		return trim( sanitize_text_field( wp_unslash( (string) $_GET[ $key ] ) ) );
	}
}
