<?php
/**
 * WooCommerce product business fields and storefront behaviour.
 *
 * @package XiujinStoreCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores durable business data outside the theme.
 */
final class Xiujin_Product_Fields {
	const META_SALES_MODE = '_xiujin_sales_mode';
	const META_MOQ        = '_xiujin_moq';
	const META_LEAD_TIME  = '_xiujin_lead_time';
	const META_CONFIG_ID  = '_xiujin_config_id';
	const META_CHECKOUT   = '_xiujin_checkout_mode';
	const OPTION_CHECKOUT = 'xiujin_enable_checkout';

	/**
	 * Attach WordPress and WooCommerce hooks.
	 */
	public static function register() {
		add_action( 'woocommerce_product_options_general_product_data', array( __CLASS__, 'render_admin_fields' ) );
		add_action( 'woocommerce_admin_process_product_object', array( __CLASS__, 'save_admin_fields' ) );
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'render_business_details' ), 24 );
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'render_enquiry_cta' ), 31 );

		add_filter( 'woocommerce_is_purchasable', array( __CLASS__, 'filter_purchasable' ), 10, 2 );
		add_filter( 'woocommerce_variation_is_purchasable', array( __CLASS__, 'filter_purchasable' ), 10, 2 );
		add_filter( 'woocommerce_get_price_html', array( __CLASS__, 'filter_price_html' ), 10, 2 );
		add_filter( 'woocommerce_loop_add_to_cart_link', array( __CLASS__, 'filter_loop_button' ), 10, 3 );
		add_filter( 'woocommerce_add_to_cart_validation', array( __CLASS__, 'validate_add_to_cart' ), 10, 5 );
		add_action( 'woocommerce_check_cart_items', array( __CLASS__, 'validate_cart' ) );
		add_filter( 'woocommerce_get_cart_url', array( __CLASS__, 'filter_commerce_url' ) );
		add_filter( 'woocommerce_get_checkout_url', array( __CLASS__, 'filter_commerce_url' ) );
		add_action( 'template_redirect', array( __CLASS__, 'redirect_disabled_commerce_routes' ) );
	}

	/**
	 * Output fields on the WooCommerce product editor.
	 */
	public static function render_admin_fields() {
		if ( ! function_exists( 'woocommerce_wp_select' ) || ! function_exists( 'woocommerce_wp_text_input' ) ) {
			return;
		}

		$product_id = get_the_ID();
		wp_nonce_field( 'xiujin_save_product_fields_' . $product_id, 'xiujin_product_fields_nonce' );

		echo '<div class="options_group xiujin-business-fields">';

		$checkout_enabled = self::checkout_enabled() && 'online' === self::get_checkout_mode( $product_id );

		woocommerce_wp_select(
			array(
				'id'          => self::META_SALES_MODE,
				'label'       => esc_html__( 'Sales mode', 'xiujin-store-core' ),
				'description' => esc_html__( 'Choose how this product can be ordered.', 'xiujin-store-core' ),
				'desc_tip'    => true,
				'value'       => self::get_sales_mode( $product_id ),
				'options'     => array(
					'wholesale' => esc_html__( 'Wholesale enquiry only', 'xiujin-store-core' ),
					'retail'    => $checkout_enabled ? esc_html__( 'Retail purchase', 'xiujin-store-core' ) : esc_html__( 'Retail enquiry', 'xiujin-store-core' ),
					'both'      => $checkout_enabled ? esc_html__( 'Wholesale and retail', 'xiujin-store-core' ) : esc_html__( 'Wholesale and retail enquiries', 'xiujin-store-core' ),
				),
			)
		);

		woocommerce_wp_text_input(
			array(
				'id'                => self::META_MOQ,
				'label'             => esc_html__( 'Minimum order quantity', 'xiujin-store-core' ),
				'description'       => esc_html__( 'Leave empty when the quantity is confirmed by quotation.', 'xiujin-store-core' ),
				'desc_tip'          => true,
				'type'              => 'number',
				'custom_attributes' => array(
					'min'  => '1',
					'max'  => '100000000',
					'step' => '1',
				),
			)
		);

		woocommerce_wp_select(
			array(
				'id'          => self::META_CHECKOUT,
				'label'       => esc_html__( 'Purchase path', 'xiujin-store-core' ),
				'description' => esc_html__( 'Keep “Quotation enquiry” for products that must not use cart or online payment. Online checkout also requires the global checkout setting.', 'xiujin-store-core' ),
				'desc_tip'    => true,
				'value'       => self::get_checkout_mode( $product_id ),
				'options'     => array(
					'enquiry' => esc_html__( 'Quotation enquiry', 'xiujin-store-core' ),
					'online'  => esc_html__( 'Online checkout', 'xiujin-store-core' ),
				),
			)
		);

		woocommerce_wp_text_input(
			array(
				'id'          => self::META_LEAD_TIME,
				'label'       => esc_html__( 'Lead time', 'xiujin-store-core' ),
				'placeholder' => esc_attr__( 'Confirmed with quotation', 'xiujin-store-core' ),
				'description' => esc_html__( 'Use current, qualified wording such as “Confirmed with quotation”.', 'xiujin-store-core' ),
				'desc_tip'    => true,
			)
		);

		woocommerce_wp_text_input(
			array(
				'id'          => self::META_CONFIG_ID,
				'label'       => esc_html__( 'Internal configuration ID', 'xiujin-store-core' ),
				'placeholder' => 'S01-R002-V01',
				'description' => esc_html__( 'Internal catalogue reference. It is not shown as a public product title.', 'xiujin-store-core' ),
				'desc_tip'    => true,
			)
		);

		echo '</div>';
	}

	/**
	 * Persist product fields after WooCommerce has validated the product edit.
	 *
	 * @param WC_Product $product Product being saved.
	 */
	public static function save_admin_fields( $product ) {
		$product_id = is_object( $product ) && method_exists( $product, 'get_id' ) ? (int) $product->get_id() : 0;
		$nonce      = sanitize_text_field( self::post_scalar( 'xiujin_product_fields_nonce' ) );

		if ( ! $product_id || ! current_user_can( 'edit_post', $product_id ) ) {
			return;
		}

		if ( ! wp_verify_nonce( $nonce, 'xiujin_save_product_fields_' . $product_id ) ) {
			return;
		}

		if ( self::has_scalar_post( self::META_SALES_MODE ) ) {
			$mode = sanitize_key( self::post_scalar( self::META_SALES_MODE ) );
			if ( in_array( $mode, array( 'wholesale', 'retail', 'both' ), true ) ) {
				$product->update_meta_data( self::META_SALES_MODE, $mode );
			} else {
				self::add_admin_error( esc_html__( 'The XIUJIN sales mode was not changed because its value was invalid.', 'xiujin-store-core' ) );
			}
		}

		if ( self::has_scalar_post( self::META_MOQ ) ) {
			$moq_raw = trim( sanitize_text_field( self::post_scalar( self::META_MOQ ) ) );
			if ( '' === $moq_raw ) {
				$product->delete_meta_data( self::META_MOQ );
			} elseif ( preg_match( '/^[0-9]+$/D', $moq_raw ) && (int) $moq_raw >= 1 && (int) $moq_raw <= 100000000 ) {
				$product->update_meta_data( self::META_MOQ, (int) $moq_raw );
			} else {
				self::add_admin_error( esc_html__( 'The XIUJIN minimum order quantity was not changed. Enter a whole number between 1 and 100,000,000.', 'xiujin-store-core' ) );
			}
		}

		if ( self::has_scalar_post( self::META_LEAD_TIME ) ) {
			$lead_time = sanitize_text_field( self::post_scalar( self::META_LEAD_TIME ) );
			$lead_time = function_exists( 'mb_substr' ) ? mb_substr( $lead_time, 0, 120 ) : substr( $lead_time, 0, 120 );
			if ( '' === $lead_time ) {
				$product->delete_meta_data( self::META_LEAD_TIME );
			} else {
				$product->update_meta_data( self::META_LEAD_TIME, $lead_time );
			}
		}

		if ( self::has_scalar_post( self::META_CONFIG_ID ) ) {
			$config_id = strtoupper( sanitize_text_field( self::post_scalar( self::META_CONFIG_ID ) ) );
			$config_id = preg_replace( '/[^A-Z0-9._-]/', '', $config_id );
			$config_id = substr( $config_id, 0, 80 );
			if ( '' === $config_id ) {
				$product->delete_meta_data( self::META_CONFIG_ID );
			} else {
				$product->update_meta_data( self::META_CONFIG_ID, $config_id );
			}
		}

		if ( self::has_scalar_post( self::META_CHECKOUT ) ) {
			$checkout_mode = sanitize_key( self::post_scalar( self::META_CHECKOUT ) );
			if ( in_array( $checkout_mode, array( 'enquiry', 'online' ), true ) ) {
				$product->update_meta_data( self::META_CHECKOUT, $checkout_mode );
			} else {
				self::add_admin_error( esc_html__( 'The XIUJIN purchase path was not changed because its value was invalid.', 'xiujin-store-core' ) );
			}
		}
	}

	/**
	 * Read a scalar product-editor value and reject array-shaped input.
	 *
	 * @param string $key Field key.
	 * @return string
	 */
	private static function post_scalar( $key ) {
		if ( ! self::has_scalar_post( $key ) ) {
			return '';
		}

		return wp_unslash( $_POST[ $key ] );
	}

	/**
	 * Determine whether a product-editor field is a scalar form value.
	 *
	 * @param string $key Field key.
	 * @return bool
	 */
	private static function has_scalar_post( $key ) {
		return isset( $_POST[ $key ] ) && is_string( $_POST[ $key ] );
	}

	/**
	 * Surface a field validation problem in the WooCommerce product editor.
	 *
	 * @param string $message Escaped message.
	 */
	private static function add_admin_error( $message ) {
		if ( class_exists( 'WC_Admin_Meta_Boxes' ) && method_exists( 'WC_Admin_Meta_Boxes', 'add_error' ) ) {
			WC_Admin_Meta_Boxes::add_error( $message );
		}
	}

	/**
	 * Get a validated sales mode for a product or variation.
	 *
	 * @param int|WC_Product $product Product or ID.
	 * @return string
	 */
	public static function get_sales_mode( $product ) {
		if ( is_object( $product ) && method_exists( $product, 'get_id' ) ) {
			$product_id = (int) $product->get_id();
		} elseif ( is_scalar( $product ) && is_numeric( $product ) ) {
			$product_id = absint( $product );
		} else {
			$product_id = 0;
		}

		$mode = $product_id ? get_post_meta( $product_id, self::META_SALES_MODE, true ) : '';

		if ( ! $mode && is_object( $product ) && method_exists( $product, 'get_parent_id' ) && $product->get_parent_id() ) {
			$mode = get_post_meta( $product->get_parent_id(), self::META_SALES_MODE, true );
		}

		return in_array( $mode, array( 'wholesale', 'retail', 'both' ), true ) ? $mode : 'both';
	}

	/**
	 * Get the allowlisted product purchase path.
	 *
	 * Missing values deliberately default to enquiry so imported and legacy
	 * products cannot become purchasable by accident.
	 *
	 * @param int|WC_Product $product Product or ID.
	 * @return string
	 */
	public static function get_checkout_mode( $product ) {
		if ( is_object( $product ) && method_exists( $product, 'get_id' ) ) {
			$product_id = (int) $product->get_id();
		} elseif ( is_scalar( $product ) && is_numeric( $product ) ) {
			$product_id = absint( $product );
		} else {
			$product_id = 0;
		}

		$mode = $product_id ? get_post_meta( $product_id, self::META_CHECKOUT, true ) : '';
		if ( ! $mode && is_object( $product ) && method_exists( $product, 'get_parent_id' ) && $product->get_parent_id() ) {
			$mode = get_post_meta( $product->get_parent_id(), self::META_CHECKOUT, true );
		}

		return in_array( $mode, array( 'enquiry', 'online' ), true ) ? $mode : 'enquiry';
	}

	/**
	 * Determine whether online cart and checkout routes are explicitly enabled.
	 *
	 * Checkout is disabled by default. Integrators can use the documented filter
	 * for controlled deployments without changing stored catalogue data.
	 *
	 * @return bool
	 */
	public static function checkout_enabled() {
		$enabled = 'yes' === get_option( self::OPTION_CHECKOUT, 'no' );
		return (bool) apply_filters( 'xiujin_store_core_checkout_enabled', $enabled );
	}

	/**
	 * Check both the global gate and product-level purchase path.
	 *
	 * @param int|WC_Product $product Product or ID.
	 * @return bool
	 */
	private static function product_checkout_enabled( $product ) {
		return self::checkout_enabled()
			&& 'online' === self::get_checkout_mode( $product )
			&& 'wholesale' !== self::get_sales_mode( $product );
	}

	/**
	 * Disable direct checkout for enquiry-only products.
	 *
	 * @param bool       $purchasable Current status.
	 * @param WC_Product $product     Product object.
	 * @return bool
	 */
	public static function filter_purchasable( $purchasable, $product ) {
		if ( ! self::product_checkout_enabled( $product ) ) {
			return false;
		}

		return $purchasable;
	}

	/**
	 * Present a useful price state without inventing prices.
	 *
	 * @param string     $price_html Existing price HTML.
	 * @param WC_Product $product    Product object.
	 * @return string
	 */
	public static function filter_price_html( $price_html, $product ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $price_html;
		}

		$mode = self::get_sales_mode( $product );
		if ( 'wholesale' === $mode || 'enquiry' === self::get_checkout_mode( $product ) ) {
			return '<span class="xiujin-price-on-request">' . esc_html__( 'Request a current quotation', 'xiujin-store-core' ) . '</span>';
		}

		if ( '' === trim( wp_strip_all_tags( $price_html ) ) ) {
			return '<span class="xiujin-price-on-request">' . esc_html__( 'Contact us for current pricing', 'xiujin-store-core' ) . '</span>';
		}

		return $price_html;
	}

	/**
	 * Reject direct add-to-cart requests for enquiry-only products.
	 *
	 * This complements the purchasable filters and also covers manually crafted
	 * add-to-cart URLs and clients that retained stale product data.
	 *
	 * @param bool  $passed       Existing validation result.
	 * @param int   $product_id   Product ID.
	 * @param int   $quantity     Requested quantity.
	 * @param int   $variation_id Variation ID, when present.
	 * @param array $variations  Selected variation attributes.
	 * @return bool
	 */
	public static function validate_add_to_cart( $passed, $product_id, $quantity, $variation_id = 0, $variations = array() ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		if ( ! $passed || ! function_exists( 'wc_get_product' ) ) {
			return $passed;
		}

		$product = wc_get_product( $variation_id ? $variation_id : $product_id );
		if ( ! self::checkout_enabled() ) {
			self::add_checkout_disabled_notice();
			return false;
		}

		if ( $product && ! self::product_checkout_enabled( $product ) ) {
			if ( 'wholesale' === self::get_sales_mode( $product ) ) {
				self::add_wholesale_cart_notice();
			} else {
				self::add_product_enquiry_notice();
			}
			return false;
		}

		return $passed;
	}

	/**
	 * Block checkout if a product changed to wholesale-only after it entered a cart.
	 */
	public static function validate_cart() {
		if ( ! function_exists( 'WC' ) ) {
			return;
		}

		$woocommerce = WC();
		if ( ! is_object( $woocommerce ) || ! $woocommerce->cart ) {
			return;
		}

		$cart_items = $woocommerce->cart->get_cart();
		if ( ! self::checkout_enabled() && $cart_items ) {
			self::add_checkout_disabled_notice();
			return;
		}

		foreach ( $cart_items as $cart_item ) {
			$product = isset( $cart_item['data'] ) ? $cart_item['data'] : false;
			if ( is_object( $product ) && method_exists( $product, 'get_id' ) && ! self::product_checkout_enabled( $product ) ) {
				if ( 'wholesale' === self::get_sales_mode( $product ) ) {
					self::add_wholesale_cart_notice();
				} else {
					self::add_product_enquiry_notice();
				}
				return;
			}
		}
	}

	/**
	 * Add one actionable checkout notice.
	 */
	private static function add_wholesale_cart_notice() {
		if ( ! function_exists( 'wc_add_notice' ) ) {
			return;
		}

		$message = esc_html__( 'This product is available by wholesale quotation and cannot be purchased through checkout. Remove it from the cart and request a quotation.', 'xiujin-store-core' );
		if ( ! function_exists( 'wc_has_notice' ) || ! wc_has_notice( $message, 'error' ) ) {
			wc_add_notice( $message, 'error' );
		}
	}

	/**
	 * Add one notice when catalogue checkout is globally disabled.
	 */
	private static function add_checkout_disabled_notice() {
		if ( ! function_exists( 'wc_add_notice' ) ) {
			return;
		}

		$message = esc_html__( 'Online checkout is disabled. Request a quotation for wholesale or retail ordering.', 'xiujin-store-core' );
		if ( ! function_exists( 'wc_has_notice' ) || ! wc_has_notice( $message, 'notice' ) ) {
			wc_add_notice( $message, 'notice' );
		}
	}

	/**
	 * Add one notice for an enquiry-only product.
	 */
	private static function add_product_enquiry_notice() {
		if ( ! function_exists( 'wc_add_notice' ) ) {
			return;
		}

		$message = esc_html__( 'This product is available by quotation and cannot be purchased through online checkout.', 'xiujin-store-core' );
		if ( ! function_exists( 'wc_has_notice' ) || ! wc_has_notice( $message, 'notice' ) ) {
			wc_add_notice( $message, 'notice' );
		}
	}

	/**
	 * Replace the archive cart button for wholesale-only products.
	 *
	 * @param string     $html    Existing HTML.
	 * @param WC_Product $product Product object.
	 * @param array      $args    Button arguments.
	 * @return string
	 */
	public static function filter_loop_button( $html, $product, $args ) {
		if ( self::product_checkout_enabled( $product ) ) {
			return $html;
		}

		$button_class = isset( $args['class'] ) && is_string( $args['class'] ) ? $args['class'] : 'button';

		return sprintf(
			'<a href="%1$s" class="%2$s">%3$s</a>',
			esc_url( $product->get_permalink() ),
			esc_attr( $button_class ),
			esc_html__( 'View and enquire', 'xiujin-store-core' )
		);
	}

	/**
	 * Replace WooCommerce cart and checkout URLs while online checkout is off.
	 *
	 * @param string $url Original WooCommerce URL.
	 * @return string
	 */
	public static function filter_commerce_url( $url ) {
		return self::checkout_enabled() ? $url : self::enquiry_url();
	}

	/**
	 * Redirect direct cart or checkout requests to the quotation section.
	 */
	public static function redirect_disabled_commerce_routes() {
		if ( self::checkout_enabled() || is_admin() ) {
			return;
		}

		$is_cart     = function_exists( 'is_cart' ) && is_cart();
		$is_checkout = function_exists( 'is_checkout' ) && is_checkout();
		if ( ! $is_cart && ! $is_checkout ) {
			return;
		}

		nocache_headers();
		wp_safe_redirect( self::enquiry_url(), 302, 'XIUJIN Store Core' );
		exit;
	}

	/**
	 * Show verified B2B attributes on a product page.
	 */
	public static function render_business_details() {
		global $product;

		if ( ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) {
			return;
		}

		$product_id = (int) $product->get_id();
		$mode       = self::get_sales_mode( $product );
		$moq_value  = get_post_meta( $product_id, self::META_MOQ, true );
		$lead_value = get_post_meta( $product_id, self::META_LEAD_TIME, true );
		$moq           = is_scalar( $moq_value ) ? absint( $moq_value ) : 0;
		$lead_time     = is_scalar( $lead_value ) ? sanitize_text_field( (string) $lead_value ) : '';
		$checkout_mode = self::product_checkout_enabled( $product ) ? 'online' : 'enquiry';
		$labels        = 'online' === $checkout_mode
			? array(
				'wholesale' => esc_html__( 'Wholesale enquiry', 'xiujin-store-core' ),
				'retail'    => esc_html__( 'Retail purchase', 'xiujin-store-core' ),
				'both'      => esc_html__( 'Wholesale and retail', 'xiujin-store-core' ),
			)
			: array(
				'wholesale' => esc_html__( 'Wholesale enquiry', 'xiujin-store-core' ),
				'retail'    => esc_html__( 'Retail enquiry', 'xiujin-store-core' ),
				'both'      => esc_html__( 'Wholesale and retail enquiries', 'xiujin-store-core' ),
			);

		echo '<dl class="xiujin-product-facts">';
		$checkout_label = 'online' === $checkout_mode ? esc_html__( 'Online checkout', 'xiujin-store-core' ) : esc_html__( 'Quotation enquiry', 'xiujin-store-core' );
		echo '<div><dt>' . esc_html__( 'Ordering', 'xiujin-store-core' ) . '</dt><dd>' . esc_html( $labels[ $mode ] ) . '</dd></div>';
		echo '<div><dt>' . esc_html__( 'Purchase path', 'xiujin-store-core' ) . '</dt><dd>' . esc_html( $checkout_label ) . '</dd></div>';
		if ( $moq && 'retail' !== $mode ) {
			echo '<div><dt>' . esc_html__( 'Minimum order quantity', 'xiujin-store-core' ) . '</dt><dd>' . esc_html( number_format_i18n( $moq ) ) . '</dd></div>';
		}
		if ( $lead_time ) {
			echo '<div><dt>' . esc_html__( 'Lead time', 'xiujin-store-core' ) . '</dt><dd>' . esc_html( $lead_time ) . '</dd></div>';
		}
		echo '</dl>';
	}

	/**
	 * Add the product-aware quotation call to action.
	 */
	public static function render_enquiry_cta() {
		global $product;

		if ( ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) {
			return;
		}

		$mode = self::get_sales_mode( $product );
		$url  = self::enquiry_url( (int) $product->get_id() );

		echo '<div class="xiujin-product-enquiry">';
		if ( 'wholesale' === $mode ) {
			echo '<strong>' . esc_html__( 'Factory-direct wholesale enquiry', 'xiujin-store-core' ) . '</strong>';
			echo '<p>' . esc_html__( 'Tell us your quantity, destination and preferred configuration for a current quotation.', 'xiujin-store-core' ) . '</p>';
		} elseif ( ! self::product_checkout_enabled( $product ) ) {
			echo '<strong>' . esc_html__( 'Product enquiry', 'xiujin-store-core' ) . '</strong>';
			echo '<p>' . esc_html__( 'Tell us the model, quantity, destination and preferred configuration for a current quotation.', 'xiujin-store-core' ) . '</p>';
		} else {
			echo '<strong>' . esc_html__( 'Planning a bulk order?', 'xiujin-store-core' ) . '</strong>';
			echo '<p>' . esc_html__( 'Ask about quantity, configuration and delivery for your market.', 'xiujin-store-core' ) . '</p>';
		}
		printf(
			'<a class="button" href="%1$s">%2$s</a>',
			esc_url( $url ),
			esc_html__( 'Request a quotation', 'xiujin-store-core' )
		);
		echo '</div>';
	}

	/**
	 * Build the localized quotation-section URL.
	 *
	 * @param int $product_id Optional product to prefill.
	 * @return string
	 */
	private static function enquiry_url( $product_id = 0 ) {
		$url = xiujin_store_home_url();
		if ( $product_id ) {
			$url = add_query_arg( array( 'product_id' => absint( $product_id ) ), $url );
		}

		return $url . '#quote';
	}
}

