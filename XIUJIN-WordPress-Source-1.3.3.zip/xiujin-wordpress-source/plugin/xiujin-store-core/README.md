# XIUJIN Store Core

Companion plugin for the XIUJIN Furniture WordPress theme.

## Features

- Keeps wholesale/retail mode, purchase path, MOQ, lead time and internal configuration IDs outside the theme.
- Defaults the whole catalogue and every product to enquiry-only ordering, so no payment gateway is required.
- Disables cart and checkout routes until an administrator explicitly enables the global checkout gate and sets an individual product to the online-checkout purchase path.
- Adds the `[xiujin_inquiry_form]` shortcode.
- Protects enquiries with a WordPress nonce, honeypot, signed timing check, hourly rate limit, server-side validation and safe plain-text email headers.
- Sends no enquiry until the visitor explicitly submits the form and accepts the consent statement.
- Does not store enquiry contents in the WordPress database.
- Optionally loads Google Ads, Meta Pixel and TikTok Pixel only after the visitor accepts analytics and advertising.
- Counts an enquiry as one anonymous Lead only after WordPress accepts its email for sending; submitted form details are never included in pixel events.

## Setup

1. Install and activate WooCommerce.
2. Upload and activate this plugin ZIP.
3. Go to **Settings → XIUJIN enquiries** and set the sales recipient.
4. Test outbound email delivery before launch. A transactional SMTP provider is recommended for production.
5. Keep **Enable WooCommerce cart and online checkout** off for the current enquiry-only site.
6. Edit each WooCommerce product and choose its sales mode. Keep **Purchase path** set to **Quotation enquiry**. Leave price empty when it is confirmed by quotation; never enter a placeholder zero price.
7. Optional: go to **Settings → XIUJIN tracking** and enter the platform IDs you intend to use. Empty or invalid fields stay disabled. Leave the GA4 field empty if Site Kit, MonsterInsights or another plugin already loads GA4.

The shortcode can be placed on any page. Product links append a product ID so the homepage enquiry form is prefilled automatically.

The form marks its page as non-cacheable so visitors never receive an expired
WordPress nonce or signed timestamp. If the host or CDN ignores WordPress's
`DONOTCACHEPAGE` flag, exclude every page containing the shortcode from its
full-page cache. Static files can remain cached normally.

WooCommerce is used for catalogue and product management. A payment gateway is
not required for the default enquiry-only configuration. Online purchase can
only be enabled later with two deliberate controls: the global checkout setting
and the per-product **Online checkout** purchase path.

## Advertising measurement

The browser integrations support Google Ads conversion tags, an optional GA4
measurement ID, Meta Pixel and TikTok Pixel. They do not include Meta
Conversions API, TikTok Events API, Google Enhanced Conversions or any other
server-side advertising connection. No third-party tracking script is loaded
before visitor consent. The visitor can reopen the privacy controls and switch
back to essential-only storage.

Use one WordPress integration for each platform. If Site Kit, MonsterInsights
or another plugin already loads the same tag, leave that ID empty here to avoid
duplicate page views and conversions.

The consent controller governs only tags loaded by this plugin. It cannot stop
Site Kit, MonsterInsights, Google Tag Manager or another integration from
making an earlier request. Disable their duplicate front-end tags or manage
every integration through one consent platform when site-wide pre-consent
blocking is required.

