(() => {
  'use strict';

  const config = window.xiujinTracking;
  if (!config || typeof config !== 'object') return;

  const rawPlatforms = config.platforms || {};
  const platforms = {
    googleAdsId: /^AW-\d{5,20}$/.test(rawPlatforms.googleAdsId || '') ? rawPlatforms.googleAdsId : '',
    googleAdsLabel: /^[A-Za-z0-9_-]{3,120}$/.test(rawPlatforms.googleAdsLabel || '') ? rawPlatforms.googleAdsLabel : '',
    ga4Id: /^G-[A-Z0-9]{5,20}$/.test(rawPlatforms.ga4Id || '') ? rawPlatforms.ga4Id : '',
    metaPixelId: /^\d{5,20}$/.test(rawPlatforms.metaPixelId || '') ? rawPlatforms.metaPixelId : '',
    tiktokPixelId: /^[A-Za-z0-9]{10,32}$/.test(rawPlatforms.tiktokPixelId || '') ? rawPlatforms.tiktokPixelId : '',
  };
  if (!Object.values(platforms).some(Boolean)) return;

  const strings = config.strings || {};
  const consentKey = /^[A-Za-z0-9_-]{3,80}$/.test(config.consentKey || '')
    ? config.consentKey
    : 'xiujin_tracking_consent_v1';
  const consentDays = 180;
  const consentLifetime = consentDays * 86400000;
  const lead = config.lead && typeof config.lead === 'object' ? config.lead : null;
  const sentThisPage = new Set();
  let initialized = false;
  let googleConsentInitialized = false;
  let currentDecision = '';
  let banner;
  let settingsButton;

  const scriptSourceExists = (fragment) => Array.from(document.scripts || [])
    .some((script) => typeof script.src === 'string' && script.src.includes(fragment));

  const queuedCommandExists = (queue, command, id) => Array.from(queue || []).some((entry) => {
    try {
      const values = Array.from(entry);
      return values[0] === command && String(values[1] || '') === id;
    } catch (_) {
      return false;
    }
  });

  const googleWasConfigured = (id) => Boolean(id) && queuedCommandExists(window.dataLayer, 'config', id);
  const metaWasConfigured = () => {
    if (!platforms.metaPixelId || !window.fbq) return false;
    try {
      if (typeof window.fbq.getState === 'function') {
        const state = window.fbq.getState();
        if (state && Array.isArray(state.pixels) && state.pixels.some((pixel) => String(pixel.id) === platforms.metaPixelId)) {
          return true;
        }
      }
    } catch (_) {
      // Fall through to the bootstrap queue check.
    }
    return queuedCommandExists(window.fbq.queue, 'init', platforms.metaPixelId);
  };

  const tiktokWasConfigured = () => Boolean(
    platforms.tiktokPixelId
    && (
      (window.ttq && window.ttq._i && window.ttq._i[platforms.tiktokPixelId])
      || scriptSourceExists(`sdkid=${encodeURIComponent(platforms.tiktokPixelId)}`)
    )
  );

  const preexisting = {
    googleLoader: scriptSourceExists('googletagmanager.com/gtag/js'),
    googleAds: googleWasConfigured(platforms.googleAdsId),
    ga4: googleWasConfigured(platforms.ga4Id),
    meta: metaWasConfigured(),
    tiktok: tiktokWasConfigured(),
  };

  const safeStorage = (storage, action, key, value) => {
    try {
      if (action === 'get') return storage.getItem(key);
      if (action === 'set') storage.setItem(key, value);
      if (action === 'remove') storage.removeItem(key);
    } catch (_) {
      return null;
    }
    return null;
  };

  const setGoogleConsent = (value) => {
    window.dataLayer = window.dataLayer || [];
    window.gtag = window.gtag || function gtag() { window.dataLayer.push(arguments); };
    window.gtag('consent', googleConsentInitialized ? 'update' : 'default', {
      ad_storage: value,
      analytics_storage: value,
      ad_user_data: value,
      ad_personalization: value,
      functionality_storage: 'granted',
      security_storage: 'granted',
      wait_for_update: value === 'denied' ? 500 : 0,
    });
    googleConsentInitialized = true;
  };
  setGoogleConsent('denied');

  const readCookie = () => {
    const prefix = `${consentKey}=`;
    const item = document.cookie.split(';').map((part) => part.trim()).find((part) => part.startsWith(prefix));
    if (!item) return '';
    try {
      return decodeURIComponent(item.slice(prefix.length));
    } catch (_) {
      return '';
    }
  };

  const readConsent = () => {
    const raw = safeStorage(window.localStorage, 'get', consentKey);
    if (raw) {
      try {
        const saved = JSON.parse(raw);
        if (
          saved
          && ['granted', 'essential'].includes(saved.value)
          && Number(saved.expires) > Date.now()
        ) return saved.value;
      } catch (_) {
        if (['granted', 'essential'].includes(raw)) return raw;
      }
    }
    const cookie = readCookie();
    return ['granted', 'essential'].includes(cookie) ? cookie : '';
  };

  const saveConsent = (value) => {
    const expires = Date.now() + consentLifetime;
    safeStorage(window.localStorage, 'set', consentKey, JSON.stringify({ value, expires }));
    const secure = window.location.protocol === 'https:' ? '; Secure' : '';
    document.cookie = `${consentKey}=${encodeURIComponent(value)}; Path=/; Max-Age=${consentDays * 86400}; SameSite=Lax${secure}`;
  };

  const appendText = (element, text) => {
    element.textContent = typeof text === 'string' ? text : '';
    return element;
  };

  const createBanner = () => {
    const section = document.createElement('section');
    section.id = 'xiujin-consent-banner';
    section.className = 'xiujin-consent';
    section.hidden = true;
    section.setAttribute('data-xiujin-consent', '');
    section.setAttribute('role', 'region');

    const content = document.createElement('div');
    content.className = 'xiujin-consent__content';
    const copy = document.createElement('div');
    copy.className = 'xiujin-consent__copy';
    const titleId = `xiujin-consent-title-${Math.random().toString(36).slice(2, 9)}`;
    const title = appendText(document.createElement('strong'), strings.consentTitle || 'Privacy choices');
    title.id = titleId;
    section.setAttribute('aria-labelledby', titleId);
    const description = appendText(
      document.createElement('p'),
      strings.consentDescription || 'Choose whether analytics and advertising services may be loaded on this site.'
    );
    copy.append(title, description);

    if (config.privacyUrl) {
      const privacy = appendText(document.createElement('a'), strings.privacyLabel || 'Privacy policy');
      privacy.href = config.privacyUrl;
      privacy.className = 'xiujin-consent__privacy';
      copy.append(privacy);
    }

    const actions = document.createElement('div');
    actions.className = 'xiujin-consent__actions';
    const essential = appendText(document.createElement('button'), strings.essentialLabel || 'Essential only');
    essential.type = 'button';
    essential.className = 'xiujin-consent__button xiujin-consent__button--secondary';
    essential.setAttribute('data-xiujin-consent-essential', '');
    const accept = appendText(document.createElement('button'), strings.acceptLabel || 'Accept analytics and ads');
    accept.type = 'button';
    accept.className = 'xiujin-consent__button xiujin-consent__button--primary';
    accept.setAttribute('data-xiujin-consent-accept', '');
    actions.append(essential, accept);
    content.append(copy, actions);
    section.append(content);
    document.body.append(section);
    return section;
  };

  const createSettingsButton = () => {
    const button = appendText(document.createElement('button'), strings.settingsLabel || 'Privacy settings');
    button.type = 'button';
    button.className = 'xiujin-consent-settings';
    button.hidden = true;
    button.setAttribute('data-xiujin-consent-settings', '');
    button.setAttribute('aria-controls', 'xiujin-consent-banner');
    button.setAttribute('aria-expanded', 'false');
    document.body.append(button);
    return button;
  };

  const showBanner = () => {
    banner.hidden = false;
    settingsButton.hidden = true;
    settingsButton.setAttribute('aria-expanded', 'true');
  };

  const hideBanner = () => {
    banner.hidden = true;
    settingsButton.hidden = false;
    settingsButton.setAttribute('aria-expanded', 'false');
  };

  const loadScript = (id, source, existingSourceFragment) => {
    if (document.getElementById(id) || (existingSourceFragment && scriptSourceExists(existingSourceFragment))) return;
    const script = document.createElement('script');
    script.id = id;
    script.async = true;
    script.src = source;
    script.referrerPolicy = 'strict-origin-when-cross-origin';
    document.head.append(script);
  };

  const initializeGoogle = () => {
    const primaryId = platforms.ga4Id || platforms.googleAdsId;
    if (!primaryId) return;
    if (!preexisting.googleLoader) window.gtag('js', new Date());
    if (platforms.ga4Id && !preexisting.ga4) {
      window.gtag('config', platforms.ga4Id, { send_page_view: false });
      window.gtag('event', 'page_view', { send_to: platforms.ga4Id });
    }
    if (platforms.googleAdsId && !preexisting.googleAds) window.gtag('config', platforms.googleAdsId);
    loadScript(
      'xiujin-google-tag',
      `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(primaryId)}`,
      'googletagmanager.com/gtag/js'
    );
  };

  const initializeMeta = () => {
    if (!platforms.metaPixelId) return;
    if (!window.fbq) {
      const fbq = function fbq() { fbq.callMethod ? fbq.callMethod.apply(fbq, arguments) : fbq.queue.push(arguments); };
      fbq.push = fbq;
      fbq.loaded = true;
      fbq.version = '2.0';
      fbq.queue = [];
      window.fbq = fbq;
      window._fbq = fbq;
    }
    window.fbq('consent', 'grant');
    if (!preexisting.meta) {
      window.fbq('init', platforms.metaPixelId);
      window.fbq('trackSingle', platforms.metaPixelId, 'PageView');
    }
    loadScript('xiujin-meta-pixel', 'https://connect.facebook.net/en_US/fbevents.js', 'connect.facebook.net/en_US/fbevents.js');
  };

  const initializeTikTok = () => {
    if (!platforms.tiktokPixelId) return;
    window.TiktokAnalyticsObject = 'ttq';
    const ttq = window.ttq = window.ttq || [];
    if (!ttq.load) {
      ttq.methods = [
        'page', 'track', 'identify', 'instances', 'debug', 'on', 'off', 'once', 'ready',
        'alias', 'group', 'enableCookie', 'disableCookie', 'holdConsent', 'revokeConsent', 'grantConsent',
      ];
      ttq.setAndDefer = (target, method) => {
        target[method] = function deferred() {
          target.push([method].concat(Array.prototype.slice.call(arguments, 0)));
        };
      };
      ttq.methods.forEach((method) => ttq.setAndDefer(ttq, method));
      ttq.instance = (pixelId) => {
        const instance = (ttq._i && ttq._i[pixelId]) || [];
        ttq.methods.forEach((method) => ttq.setAndDefer(instance, method));
        return instance;
      };
      ttq.load = (pixelId, options) => {
        const source = 'https://analytics.tiktok.com/i18n/pixel/events.js';
        ttq._i = ttq._i || {};
        ttq._i[pixelId] = [];
        ttq._i[pixelId]._u = source;
        ttq._t = ttq._t || {};
        ttq._t[pixelId] = Date.now();
        ttq._o = ttq._o || {};
        ttq._o[pixelId] = options || {};
        loadScript('xiujin-tiktok-pixel', `${source}?sdkid=${encodeURIComponent(pixelId)}&lib=ttq`);
      };
    }
    if (!preexisting.tiktok) {
      ttq.load(platforms.tiktokPixelId);
      ttq.grantConsent();
      ttq.page();
    }
  };

  const cleanLeadQuery = () => {
    if (!lead || !window.history || !window.URL) return;
    const keys = Array.isArray(lead.queryKeys) && lead.queryKeys.length
      ? lead.queryKeys
      : ['xiujin_conversion', 'xiujin_event', 'xiujin_sig'];
    const url = new URL(window.location.href);
    let changed = false;
    keys.forEach((key) => {
      if (/^[A-Za-z0-9_-]{1,80}$/.test(key) && url.searchParams.has(key)) {
        url.searchParams.delete(key);
        changed = true;
      }
    });
    if (changed) window.history.replaceState(window.history.state, '', `${url.pathname}${url.search}${url.hash}`);
  };

  // Remove the short-lived opaque marker before waiting for DOMContentLoaded.
  cleanLeadQuery();

  const eventWasSent = (eventId) => {
    if (sentThisPage.has(eventId)) return true;
    if (safeStorage(window.sessionStorage, 'get', `xiujin-lead-${eventId}`)) return true;
    try {
      const saved = JSON.parse(safeStorage(window.localStorage, 'get', 'xiujin_tracking_events_v1') || '{}');
      return Number(saved[eventId]) > Date.now() - 30 * 86400000;
    } catch (_) {
      return false;
    }
  };

  const rememberEvent = (eventId) => {
    sentThisPage.add(eventId);
    safeStorage(window.sessionStorage, 'set', `xiujin-lead-${eventId}`, '1');
    let saved = {};
    try {
      saved = JSON.parse(safeStorage(window.localStorage, 'get', 'xiujin_tracking_events_v1') || '{}');
    } catch (_) {
      saved = {};
    }
    const cutoff = Date.now() - 30 * 86400000;
    const recent = Object.fromEntries(
      Object.entries(saved)
        .filter(([, timestamp]) => Number(timestamp) > cutoff)
        .slice(-29)
    );
    recent[eventId] = Date.now();
    safeStorage(window.localStorage, 'set', 'xiujin_tracking_events_v1', JSON.stringify(recent));
  };

  const fireLead = () => {
    if (!lead || typeof lead.eventId !== 'string') return;
    const eventId = lead.eventId.trim();
    if (!/^[A-Za-z0-9_-]{8,128}$/.test(eventId) || eventWasSent(eventId)) return;

    if (platforms.googleAdsId && platforms.googleAdsLabel) {
      window.gtag('event', 'conversion', {
        send_to: `${platforms.googleAdsId}/${platforms.googleAdsLabel}`,
        transaction_id: eventId,
      });
    }
    if (platforms.ga4Id) {
      window.gtag('event', 'generate_lead', { send_to: platforms.ga4Id, event_id: eventId });
    }
    let sent = false;
    if (platforms.googleAdsId && platforms.googleAdsLabel) sent = true;
    if (platforms.ga4Id) sent = true;
    if (platforms.metaPixelId && window.fbq) {
      window.fbq('trackSingle', platforms.metaPixelId, 'Lead', {}, { eventID: eventId });
      sent = true;
    }
    if (platforms.tiktokPixelId && window.ttq) {
      window.ttq.track('SubmitForm', {}, { event_id: eventId });
      sent = true;
    }
    if (!sent) return;
    rememberEvent(eventId);
    document.dispatchEvent(new CustomEvent('xiujin:lead-tracked', { detail: { eventId } }));
  };

  const enableTracking = () => {
    setGoogleConsent('granted');
    if (window.fbq) window.fbq('consent', 'grant');
    if (window.ttq && window.ttq.grantConsent) window.ttq.grantConsent();
    if (!initialized) {
      initialized = true;
      initializeGoogle();
      initializeMeta();
      initializeTikTok();
    }
    fireLead();
    document.dispatchEvent(new CustomEvent('xiujin:tracking-ready'));
  };

  const applyDecision = (decision) => {
    currentDecision = decision;
    saveConsent(decision);
    hideBanner();
    if (decision === 'granted') {
      enableTracking();
      return;
    }
    setGoogleConsent('denied');
    if (window.fbq) window.fbq('consent', 'revoke');
    if (window.ttq && window.ttq.revokeConsent) window.ttq.revokeConsent();
  };

  const start = () => {
    banner = document.querySelector('[data-xiujin-consent]') || createBanner();
    settingsButton = document.querySelector('[data-xiujin-consent-settings]') || createSettingsButton();
    banner.querySelector('[data-xiujin-consent-accept]')?.addEventListener('click', () => applyDecision('granted'));
    banner.querySelector('[data-xiujin-consent-essential]')?.addEventListener('click', () => applyDecision('essential'));
    settingsButton.addEventListener('click', showBanner);
    document.addEventListener('xiujin:open-consent', showBanner);
    currentDecision = readConsent();
    if (currentDecision === 'granted') {
      hideBanner();
      enableTracking();
    } else if (currentDecision === 'essential') {
      hideBanner();
      setGoogleConsent('denied');
    } else {
      showBanner();
    }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
  else start();
})();
