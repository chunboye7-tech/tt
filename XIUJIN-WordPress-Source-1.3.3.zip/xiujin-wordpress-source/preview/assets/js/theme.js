(() => {
  'use strict';

  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let revealObserver;
  let modelScriptPromise;

  const initializeMenu = (scope) => {
    scope.querySelectorAll('[data-menu-toggle]').forEach((button) => {
      if (button.dataset.ready) return;
      button.dataset.ready = 'true';
      const menu = document.getElementById(button.getAttribute('aria-controls'));
      if (!menu) return;
      const close = () => {
        button.setAttribute('aria-expanded', 'false');
        button.querySelector('.screen-reader-text').textContent = window.xiujinTheme?.menuOpen || 'Open navigation';
        menu.hidden = true;
        document.body.classList.remove('menu-open');
      };
      button.addEventListener('click', () => {
        const open = button.getAttribute('aria-expanded') === 'true';
        if (open) { close(); return; }
        button.setAttribute('aria-expanded', 'true');
        button.querySelector('.screen-reader-text').textContent = window.xiujinTheme?.menuClose || 'Close navigation';
        menu.hidden = false;
        document.body.classList.add('menu-open');
      });
      menu.querySelectorAll('a').forEach((link) => link.addEventListener('click', close));
      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !menu.hidden) {
          close();
          button.focus();
        }
      });
    });
  };

  const initializeEnquiryLinks = (scope) => {
    scope.querySelectorAll('[data-enquiry-product]').forEach((link) => {
      if (link.dataset.ready) return;
      link.dataset.ready = 'true';
      link.addEventListener('click', () => {
        const productField = document.querySelector('[data-product-field]');
        if (productField) productField.value = link.dataset.enquiryProduct || '';
      });
    });
  };

  const initializeShowroom = (scope) => {
    scope.querySelectorAll('[data-showroom]').forEach((showroom) => {
      if (showroom.dataset.ready) return;
      showroom.dataset.ready = 'true';
      const track = showroom.querySelector('[data-showroom-track]');
      if (!track) return;
      showroom.querySelectorAll('[data-showroom-direction]').forEach((button) => {
        button.addEventListener('click', () => {
          const direction = Number(button.dataset.showroomDirection || 1);
          const distance = Math.max(280, track.clientWidth * 0.84);
          track.scrollBy({ left: distance * direction, behavior: reducedMotion.matches ? 'auto' : 'smooth' });
        });
      });
    });
  };

  const initializeFactoryGallery = (scope) => {
    scope.querySelectorAll('[data-factory-gallery]').forEach((gallery) => {
      if (gallery.dataset.ready) return;
      gallery.dataset.ready = 'true';
      const block = gallery.closest('.factory-gallery-block');
      const dialog = block?.querySelector('[data-factory-lightbox]');
      if (!dialog || typeof dialog.showModal !== 'function') return;
      const image = dialog.querySelector('[data-factory-lightbox-image]');
      const title = dialog.querySelector('[data-factory-lightbox-title]');
      const caption = dialog.querySelector('[data-factory-lightbox-caption]');
      const closeButton = dialog.querySelector('[data-factory-lightbox-close]');
      let opener = null;

      gallery.querySelectorAll('[data-factory-photo]').forEach((link) => {
        link.addEventListener('click', (event) => {
          event.preventDefault();
          opener = link;
          if (image) {
            image.src = link.href;
            image.alt = link.querySelector('img')?.alt || '';
          }
          if (title) title.textContent = link.dataset.title || '';
          if (caption) caption.textContent = link.dataset.caption || '';
          document.body.classList.add('factory-lightbox-open');
          dialog.showModal();
          closeButton?.focus();
        });
      });

      closeButton?.addEventListener('click', () => dialog.close());
      dialog.addEventListener('click', (event) => {
        if (event.target === dialog) dialog.close();
      });
      dialog.addEventListener('close', () => {
        document.body.classList.remove('factory-lightbox-open');
        opener?.focus();
        opener = null;
      });
    });
  };

  const initializeConfigurationGallery = (scope) => {
    scope.querySelectorAll('[data-config-gallery]').forEach((gallery) => {
      if (gallery.dataset.ready) return;
      gallery.dataset.ready = 'true';
      const image = gallery.querySelector('[data-config-image]');
      const title = gallery.querySelector('[data-config-title]');
      const modelRoot = gallery.querySelector('[data-chair-model]');
      const modelSelect = gallery.querySelector('[data-model-select]');
      const modelPoster = gallery.querySelector('[data-model-poster]');
      const modelTitle = gallery.querySelector('[data-model-title]');
      gallery.querySelectorAll('[data-config-choice]').forEach((button) => {
        button.addEventListener('click', () => {
          if (button.getAttribute('aria-pressed') === 'true') return;
          gallery.querySelectorAll('[data-config-choice]').forEach((item) => item.setAttribute('aria-pressed', String(item === button)));
          const selectedTitle = button.dataset.title || '';
          const selectedImage = button.dataset.image || '';
          if (title) title.textContent = selectedTitle;
          if (modelTitle) modelTitle.textContent = selectedTitle;
          if (modelRoot) modelRoot.dataset.selectedFinish = selectedTitle;
          // The thumbnail image is already present on the page, so switch the
          // photo and poster synchronously before asking WebGL to change scene.
          // This keeps the visible product and its 3D approximation in phase.
          if (selectedImage) {
            if (image) {
              image.classList.toggle('is-switching', !reducedMotion.matches);
              image.src = selectedImage;
              image.alt = button.dataset.alt || '';
            }
            if (modelPoster) modelPoster.src = selectedImage;
          }
          if (modelSelect) {
            modelSelect.value = button.dataset.modelIndex || '0';
            modelSelect.dispatchEvent(new Event('change', { bubbles: true }));
          }
          if (modelRoot?.dataset.ready !== 'true') {
            const status = modelRoot?.querySelector('[data-status]');
            if (status) status.textContent = `${selectedTitle} · ${modelRoot.dataset.loadPrompt || 'Load the 3D view to inspect this finish.'}`;
          }
          if (!image) return;
          if (reducedMotion.matches) {
            image.classList.remove('is-switching');
            return;
          }
          window.requestAnimationFrame(() => window.requestAnimationFrame(() => image.classList.remove('is-switching')));
        });
      });
    });
  };

  const loadModelScript = (source) => {
    if (window.XiujinChairModel) return Promise.resolve();
    if (modelScriptPromise) return modelScriptPromise;
    modelScriptPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = source;
      script.defer = true;
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
    modelScriptPromise = modelScriptPromise.catch((error) => {
      modelScriptPromise = null;
      throw error;
    });
    return modelScriptPromise;
  };

  const initializeModelLoaders = (scope) => {
    scope.querySelectorAll('[data-model-loader]').forEach((loader) => {
      if (loader.dataset.ready) return;
      loader.dataset.ready = 'true';
      const button = loader.querySelector('[data-model-load]');
      const root = loader.querySelector('[data-chair-model]');
      const status = root?.querySelector('[data-status]');
      if (!button || !root) return;
      const readyObserver = new MutationObserver(() => {
        if (root.dataset.ready === 'true') {
          loader.classList.add('model-loader-ready');
          const canvas = root.querySelector('canvas');
          if (canvas) canvas.tabIndex = 0;
          loader.querySelectorAll('[data-angle],[data-zoom]').forEach((control) => { control.disabled = false; });
          readyObserver.disconnect();
        }
        if (root.dataset.modelError === 'true') {
          loader.classList.add('model-loader-error');
          readyObserver.disconnect();
        }
      });
      readyObserver.observe(root, { attributes: true, attributeFilter: ['data-ready', 'data-model-error'] });
      button.addEventListener('click', () => {
        if (button.disabled) return;
        button.disabled = true;
        loader.classList.add('model-loader-loading');
        if (status) status.textContent = window.xiujinTheme?.modelLoading || 'Loading interactive view…';
        loadModelScript(loader.dataset.modelSrc || window.xiujinTheme?.modelScript)
          .then(() => {
            if (!window.XiujinChairModel?.mount) throw new Error('Interactive chair renderer unavailable');
            return window.XiujinChairModel.mount(root);
          })
          .catch(() => {
            readyObserver.disconnect();
            root.dataset.modelError = 'true';
            loader.classList.add('model-loader-error');
            button.disabled = false;
            if (status) {
              status.textContent = window.xiujinTheme?.modelError || 'The interactive view could not load.';
              status.setAttribute('role', 'alert');
            }
          });
      });
    });
  };

  const initializeCounters = (scope) => {
    scope.querySelectorAll('[data-counter]').forEach((counter) => {
      if (counter.dataset.ready) return;
      counter.dataset.ready = 'true';
      const target = Number(counter.dataset.counter);
      if (!Number.isFinite(target) || reducedMotion.matches || !('IntersectionObserver' in window)) {
        counter.textContent = String(target);
        return;
      }
      const observer = new IntersectionObserver((entries) => {
        if (!entries.some((entry) => entry.isIntersecting)) return;
        observer.disconnect();
        const start = performance.now();
        const duration = 750;
        const tick = (now) => {
          const progress = Math.min(1, (now - start) / duration);
          const eased = 1 - Math.pow(1 - progress, 3);
          counter.textContent = String(Math.round(target * eased));
          if (progress < 1 && !reducedMotion.matches) requestAnimationFrame(tick);
          else counter.textContent = String(target);
        };
        requestAnimationFrame(tick);
      }, { threshold: 0.7 });
      observer.observe(counter);
    });
  };

  const initializeReveals = (scope) => {
    const targets = scope.querySelectorAll('[data-reveal]');
    if (reducedMotion.matches || !('IntersectionObserver' in window)) {
      targets.forEach((target) => target.classList.add('is-visible'));
      return;
    }
    document.documentElement.classList.add('motion-enabled');
    if (!revealObserver) {
      revealObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add('is-visible');
          revealObserver.unobserve(entry.target);
        });
      }, { rootMargin: '0px 0px -8% 0px', threshold: 0.1 });
    }
    targets.forEach((target, index) => {
      if (target.dataset.revealReady) return;
      target.dataset.revealReady = 'true';
      target.style.setProperty('--reveal-delay', `${Math.min(index % 5, 4) * 65}ms`);
      revealObserver.observe(target);
    });
  };

  const initialize = (scope = document) => {
    initializeMenu(scope);
    initializeEnquiryLinks(scope);
    initializeShowroom(scope);
    initializeFactoryGallery(scope);
    initializeConfigurationGallery(scope);
    initializeModelLoaders(scope);
    initializeCounters(scope);
    initializeReveals(scope);
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => initialize(), { once: true });
  else initialize();

  window.addEventListener('pagehide', (event) => {
    if (!event.persisted) window.XiujinChairModel?.unmount(document);
  });
})();
