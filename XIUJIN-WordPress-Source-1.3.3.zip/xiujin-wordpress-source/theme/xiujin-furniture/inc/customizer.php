<?php
/**
 * Theme Customizer settings.
 *
 * @package Xiujin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sanitize public social links to web URLs.
 *
 * @param string $url Submitted URL.
 * @return string
 */
function xiujin_sanitize_external_url( $url ) {
	return esc_url_raw( $url, array( 'http', 'https' ) );
}

function xiujin_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'xiujin_business',
		array(
			'title'       => __( 'XIUJIN brand and contact', 'xiujin' ),
			'description' => __( 'Add verified company and social details. Empty social links stay hidden.', 'xiujin' ),
			'priority'    => 30,
		)
	);

	$text_settings = array(
		'xiujin_company_name' => array( __( 'Company name', 'xiujin' ), 'Bazhou Xiujin Furniture Co., Ltd', 'sanitize_text_field' ),
		'xiujin_phone'        => array( __( 'Business phone', 'xiujin' ), '+86 184 0684 5852', 'sanitize_text_field' ),
		'xiujin_email'        => array( __( 'Business email', 'xiujin' ), '', 'sanitize_email' ),
		'xiujin_announcement' => array( __( 'Announcement', 'xiujin' ), __( 'Factory-direct chair supply · Wholesale and retail enquiries', 'xiujin' ), 'sanitize_text_field' ),
	);
	foreach ( $text_settings as $id => $config ) {
		$wp_customize->add_setting(
			$id,
			array(
				'default'           => $config[1],
				'sanitize_callback' => $config[2],
			)
		);
		$wp_customize->add_control( $id, array( 'label' => $config[0], 'section' => 'xiujin_business', 'type' => 'text' ) );
	}

	$social_networks = array(
		'facebook'  => __( 'Facebook', 'xiujin' ),
		'telegram'  => __( 'Telegram', 'xiujin' ),
		'instagram' => __( 'Instagram', 'xiujin' ),
		'tiktok'    => __( 'TikTok', 'xiujin' ),
		'whatsapp'  => __( 'WhatsApp', 'xiujin' ),
		'messenger' => __( 'Messenger', 'xiujin' ),
	);
	foreach ( $social_networks as $network => $network_label ) {
		$id = 'xiujin_' . $network . '_url';
		$defaults = array(
			'facebook' => 'https://www.facebook.com/profile.php?id=61595055224916',
			'tiktok'   => 'https://www.tiktok.com/@stevenbob620',
			'whatsapp' => 'https://wa.me/85290199249',
		);
		$default = isset( $defaults[ $network ] ) ? $defaults[ $network ] : '';
		$wp_customize->add_setting( $id, array( 'default' => $default, 'sanitize_callback' => 'xiujin_sanitize_external_url' ) );
		$wp_customize->add_control(
			$id,
			array(
					/* Translators: %s is a social network name such as Facebook. */
					'label'   => sprintf( __( '%s URL', 'xiujin' ), $network_label ),
				'section' => 'xiujin_business',
				'type'    => 'url',
			)
		);
	}

	$wp_customize->add_section( 'xiujin_home_media', array( 'title' => __( 'XIUJIN home media', 'xiujin' ), 'priority' => 31 ) );
	$wp_customize->add_setting( 'xiujin_hero_image', array( 'default' => 0, 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control(
		new WP_Customize_Media_Control(
			$wp_customize,
			'xiujin_hero_image',
			array(
				'label'     => __( 'Hero image', 'xiujin' ),
				'section'   => 'xiujin_home_media',
				'mime_type' => 'image',
			)
		)
	);
}
add_action( 'customize_register', 'xiujin_customize_register' );

