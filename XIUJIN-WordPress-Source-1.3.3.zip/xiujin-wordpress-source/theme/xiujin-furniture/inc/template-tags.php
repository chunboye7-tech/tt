<?php
/**
 * Reusable theme output helpers.
 *
 * @package Xiujin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function xiujin_theme_file( $path ) {
	return XIUJIN_THEME_URI . '/assets/' . ltrim( (string) $path, '/' );
}

function xiujin_theme_asset( $filename ) {
	return xiujin_theme_file( 'images/' . ltrim( (string) $filename, '/' ) );
}

function xiujin_company_name() {
	return sanitize_text_field( (string) get_theme_mod( 'xiujin_company_name', 'Bazhou Xiujin Furniture Co., Ltd' ) );
}

/**
 * Return the verified WhatsApp contact URL.
 *
 * Keeping the default here gives a newly installed theme a working contact
 * path while the Customizer setting still lets an administrator replace it.
 *
 * @return string
 */
function xiujin_whatsapp_url() {
	return esc_url_raw(
		(string) get_theme_mod( 'xiujin_whatsapp_url', 'https://wa.me/85290199249' ),
		array( 'http', 'https' )
	);
}

/**
 * Return the current language's home URL, optionally with a page anchor.
 *
 * Polylang and WPML both expose a localized home URL. Using it here keeps
 * header and footer links in the visitor's selected language.
 *
 * @param string $anchor Optional anchor without the hash character.
 * @return string
 */
function xiujin_home_url( $anchor = '' ) {
	$url = home_url( '/' );

	if ( function_exists( 'pll_home_url' ) ) {
		$localized_url = pll_home_url();
		if ( $localized_url ) {
			$url = $localized_url;
		}
	} elseif ( has_filter( 'wpml_home_url' ) ) {
		$localized_url = apply_filters( 'wpml_home_url', $url );
		if ( is_string( $localized_url ) && $localized_url ) {
			$url = $localized_url;
		}
	}

	$anchor = sanitize_title( ltrim( (string) $anchor, '#' ) );
	if ( $anchor ) {
		$url = preg_replace( '/#.*$/', '', $url ) . '#' . $anchor;
	}

	return $url;
}

function xiujin_social_links() {
	$networks = array(
		'facebook'  => __( 'Facebook', 'xiujin' ),
		'telegram'  => __( 'Telegram', 'xiujin' ),
		'instagram' => __( 'Instagram', 'xiujin' ),
		'tiktok'    => __( 'TikTok', 'xiujin' ),
		'whatsapp'  => __( 'WhatsApp', 'xiujin' ),
		'messenger' => __( 'Messenger', 'xiujin' ),
	);
	$links = array();
	$defaults = array(
		'facebook' => 'https://www.facebook.com/profile.php?id=61595055224916',
		'tiktok'   => 'https://www.tiktok.com/@stevenbob620',
		'whatsapp' => 'https://wa.me/85290199249',
	);
	foreach ( $networks as $key => $label ) {
		$url = 'whatsapp' === $key
			? xiujin_whatsapp_url()
			: esc_url_raw(
				(string) get_theme_mod( 'xiujin_' . $key . '_url', isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' ),
				array( 'http', 'https' )
			);
		if ( $url ) {
			$links[ $key ] = array( 'label' => $label, 'url' => $url );
		}
	}
	return $links;
}

/**
 * Return a compact inline SVG for a supported social network.
 *
 * The SVGs inherit currentColor and remain local to the theme so the header
 * does not depend on an icon font or a third-party CDN.
 *
 * @param string $network Social network key.
 * @return string
 */
function xiujin_social_icon_svg( $network ) {
	$icons = array(
		'facebook'  => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M14 8.5V7c0-.7.5-1 1.2-1H17V3.1c-.7-.1-1.6-.1-2.8-.1-2.8 0-4.7 1.7-4.7 4.8v.7H7V12h2.5v9H13v-9h3l.5-3.5H13Z"/></svg>',
		'telegram'  => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M21.6 3.3 18.5 20c-.2 1.2-.9 1.5-1.9.9l-4.8-3.6-2.3 2.3c-.3.3-.5.5-1 .5l.4-4.9 8.9-8c.4-.4-.1-.6-.6-.2L6.1 14l-4.8-1.5c-1-.3-1.1-1 .2-1.5l18.8-7.2c.9-.3 1.6.2 1.3 1.5Z"/></svg>',
		'instagram' => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.4" cy="6.7" r="1.2" fill="currentColor"/></svg>',
		'tiktok'    => '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M15.3 3c.3 2.1 1.5 3.4 3.7 3.6v3.1a7.4 7.4 0 0 1-3.7-1.1v6.1A5.7 5.7 0 1 1 10.4 9v3.2a2.6 2.6 0 1 0 1.8 2.5V3h3.1Z"/></svg>',
	);

	$network = sanitize_key( $network );
	return isset( $icons[ $network ] ) ? $icons[ $network ] : '';
}

/**
 * Render configured profile icons in the site header.
 *
 * @return void
 */
function xiujin_render_header_social_links() {
	$links   = xiujin_social_links();
	$ordered = array( 'facebook', 'telegram', 'tiktok' );
	$items   = array();

	foreach ( $ordered as $network ) {
		if ( empty( $links[ $network ]['url'] ) ) {
			continue;
		}
		$items[ $network ] = $links[ $network ];
	}

	if ( ! $items ) {
		return;
	}
	?>
	<nav class="header-social-links" aria-label="<?php esc_attr_e( 'Social media', 'xiujin' ); ?>">
		<?php foreach ( $items as $network => $item ) : ?>
			<a class="header-social-link header-social-link--<?php echo esc_attr( $network ); ?>" href="<?php echo esc_url( $item['url'] ); ?>" target="_blank" rel="me noopener noreferrer" aria-label="<?php echo esc_attr( $item['label'] ); ?>">
				<?php echo xiujin_social_icon_svg( $network ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span class="screen-reader-text"><?php echo esc_html( $item['label'] ); ?></span>
			</a>
		<?php endforeach; ?>
	</nav>
	<?php
}

function xiujin_language_switcher() {
	if ( function_exists( 'pll_the_languages' ) ) {
		echo '<label class="language-switcher"><span class="screen-reader-text">' . esc_html__( 'Language selection', 'xiujin' ) . '</span>';
		pll_the_languages(
			array(
				'show_flags'            => 0,
				'show_names'            => 1,
				'dropdown'              => 1,
				'hide_if_empty'         => 0,
				'hide_if_no_translation' => 0,
				'force_home'            => 0,
			)
		);
		echo '</label>';
		return;
	}
	if ( has_action( 'wpml_add_language_selector' ) ) {
		echo '<div class="language-switcher" aria-label="' . esc_attr__( 'Language selection', 'xiujin' ) . '">';
		do_action( 'wpml_add_language_selector' );
		echo '</div>';
	}
}

/**
 * Avoid duplicate menu-item IDs when menus are rendered in more than one
 * navigation region.
 *
 * @param string   $menu_id Menu item ID.
 * @param WP_Post  $item    Menu item object.
 * @param stdClass $args    Menu arguments.
 * @return string
 */
function xiujin_mobile_menu_item_id( $menu_id, $item, $args ) {
	unset( $item );
	if ( isset( $args->menu_class ) && in_array( $args->menu_class, array( 'mobile-menu', 'footer-menu' ), true ) ) {
		return '';
	}
	return $menu_id;
}
add_filter( 'nav_menu_item_id', 'xiujin_mobile_menu_item_id', 10, 3 );

function xiujin_section_heading( $eyebrow, $heading, $intro = '' ) {
	?>
	<div class="section-heading" data-reveal>
		<div>
			<span class="eyebrow"><?php echo esc_html( $eyebrow ); ?></span>
			<h2><?php echo esc_html( $heading ); ?></h2>
		</div>
		<?php if ( $intro ) : ?>
			<p><?php echo esc_html( $intro ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

function xiujin_render_social_links( $class_name = 'social-links', $excluded = array() ) {
	$links = xiujin_social_links();
	foreach ( (array) $excluded as $key ) {
		unset( $links[ sanitize_key( $key ) ] );
	}
	if ( ! $links ) {
		return;
	}
	echo '<div class="' . esc_attr( $class_name ) . '">';
	foreach ( $links as $key => $item ) {
		printf(
			'<a class="social-link social-link--%1$s" href="%2$s" target="_blank" rel="noopener noreferrer"><span>%3$s</span></a>',
			esc_attr( $key ),
			esc_url( $item['url'] ),
			esc_html( $item['label'] )
		);
	}
	echo '</div>';
}

