<?php
/**
 * WooCommerce presentation hooks.
 *
 * @package Xiujin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function xiujin_woocommerce_setup() {
	add_theme_support(
		'woocommerce',
		array(
			'thumbnail_image_width' => 520,
			'single_image_width'    => 900,
			'product_grid'          => array(
				'default_rows'    => 3,
				'min_rows'        => 1,
				'max_rows'        => 8,
				'default_columns' => 3,
				'min_columns'     => 2,
				'max_columns'     => 4,
			),
		)
	);
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
}
add_action( 'after_setup_theme', 'xiujin_woocommerce_setup' );

function xiujin_woocommerce_wrapper_start() {
	echo '<main id="primary" class="site-main commerce-main"><div class="page-width">';
}

function xiujin_woocommerce_wrapper_end() {
	echo '</div></main>';
}

function xiujin_woocommerce_hooks() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
	remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
	remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
	add_action( 'woocommerce_before_main_content', 'xiujin_woocommerce_wrapper_start', 10 );
	add_action( 'woocommerce_after_main_content', 'xiujin_woocommerce_wrapper_end', 10 );
	add_filter( 'woocommerce_output_related_products_args', 'xiujin_related_products_args' );
}
add_action( 'wp', 'xiujin_woocommerce_hooks' );

function xiujin_related_products_args( $args ) {
	$args['posts_per_page'] = 3;
	$args['columns']        = 3;
	return $args;
}

/**
 * Keep WooCommerce as a searchable product catalog without an online-payment
 * path. Wholesale and single-chair requests are confirmed by direct enquiry.
 */
function xiujin_catalog_only_purchasable() {
	return false;
}
add_filter( 'woocommerce_is_purchasable', 'xiujin_catalog_only_purchasable', PHP_INT_MAX );
add_filter( 'woocommerce_variation_is_purchasable', 'xiujin_catalog_only_purchasable', PHP_INT_MAX );

