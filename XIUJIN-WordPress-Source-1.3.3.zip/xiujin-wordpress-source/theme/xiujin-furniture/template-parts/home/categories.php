<?php
/**
 * Category entry points and sales paths.
 *
 * @package Xiujin
 */
$categories = array(
	array( 'title' => __( 'Gaming chairs', 'xiujin' ), 'copy' => __( 'Reclining and adjustable seating for gaming and creator setups.', 'xiujin' ), 'image' => 'chair-8051.webp', 'accent' => 'coral' ),
	array( 'title' => __( 'Mesh office chairs', 'xiujin' ), 'copy' => __( 'Breathable task seating for office and home workspaces.', 'xiujin' ), 'image' => 'chair-110.webp', 'accent' => 'teal' ),
	array( 'title' => __( 'Executive office chairs', 'xiujin' ), 'copy' => __( 'High-back and padded seating for management and meeting spaces.', 'xiujin' ), 'image' => 'chair-executive.webp', 'accent' => 'amber' ),
);
?>
<section id="collections" class="section categories-section">
	<div class="page-width">
		<?php xiujin_section_heading( __( 'Chair categories', 'xiujin' ), __( 'Choose the right seat for your market.', 'xiujin' ), __( 'Start with a seating category, then compare the available series and product-specific options.', 'xiujin' ) ); ?>
		<div class="category-grid">
			<?php foreach ( $categories as $category ) : ?>
				<article class="category-card category-card--<?php echo esc_attr( $category['accent'] ); ?>" data-reveal>
					<div class="category-image"><img src="<?php echo esc_url( xiujin_theme_asset( $category['image'] ) ); ?>" width="720" height="720" loading="lazy" decoding="async" alt="<?php echo esc_attr( $category['title'] ); ?>"></div>
					<div class="category-copy"><span><?php esc_html_e( 'Product category', 'xiujin' ); ?></span><h3><?php echo esc_html( $category['title'] ); ?></h3><p><?php echo esc_html( $category['copy'] ); ?></p><a href="#catalog"><?php esc_html_e( 'View chair series', 'xiujin' ); ?><span class="arrow" aria-hidden="true"></span></a></div>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<section id="wholesale-retail" class="section paths-section">
	<div class="page-width paths-grid">
		<article class="path-card path-card--wholesale" data-reveal>
			<span class="eyebrow"><?php esc_html_e( 'Wholesale sourcing', 'xiujin' ); ?></span>
			<h2><?php esc_html_e( 'Build a chair order around your market.', 'xiujin' ); ?></h2>
			<p><?php esc_html_e( 'Share the chair series, quantities, destination and preferred configuration. Packaging, minimum order, lead time and commercial terms are confirmed in the quotation.', 'xiujin' ); ?></p>
			<a class="button button--gold" href="#quote"><?php esc_html_e( 'Start a wholesale enquiry', 'xiujin' ); ?><span class="arrow" aria-hidden="true"></span></a>
		</article>
		<article class="path-card path-card--retail" data-reveal>
			<span class="eyebrow"><?php esc_html_e( 'Retail enquiries', 'xiujin' ); ?></span>
			<h2><?php esc_html_e( 'Ask about individual chair models.', 'xiujin' ); ?></h2>
			<p><?php esc_html_e( 'Browse the catalog and tell us the model, configuration and quantity you need. We confirm current availability, price and delivery through a direct enquiry.', 'xiujin' ); ?></p>
			<a class="button button--outline-light" href="#catalog"><?php esc_html_e( 'Browse product series', 'xiujin' ); ?><span class="arrow" aria-hidden="true"></span></a>
		</article>
	</div>
</section>

