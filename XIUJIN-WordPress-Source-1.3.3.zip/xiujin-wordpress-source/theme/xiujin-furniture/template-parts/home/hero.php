<?php
/**
 * Home hero and verified catalog counts.
 *
 * @package Xiujin
 */
$hero_image_id = (int) get_theme_mod( 'xiujin_hero_image', 0 );
$shop_url      = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : xiujin_home_url( 'catalog' );
if ( ! $shop_url ) {
	$shop_url = xiujin_home_url( 'catalog' );
}
?>
<section class="hero-section">
	<div class="hero-orb hero-orb--one" aria-hidden="true"></div>
	<div class="hero-orb hero-orb--two" aria-hidden="true"></div>
	<div class="page-width hero-grid">
		<div class="hero-copy">
			<span class="eyebrow"><?php esc_html_e( 'XIUJIN FURNITURE · FACTORY DIRECT', 'xiujin' ); ?></span>
			<h1><?php esc_html_e( 'Office & gaming chairs. Wholesale & retail.', 'xiujin' ); ?></h1>
			<p><?php esc_html_e( 'Compare office, executive and gaming chair series, confirm the required configuration and request a current quotation for your market.', 'xiujin' ); ?></p>
			<div class="hero-actions">
				<a class="button button--gold" href="#quote"><?php esc_html_e( 'Request wholesale quote', 'xiujin' ); ?><span class="arrow" aria-hidden="true"></span></a>
				<a class="text-link" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Explore the chair catalog', 'xiujin' ); ?><span class="arrow" aria-hidden="true"></span></a>
			</div>
			<div class="hero-paths">
				<div><strong><?php esc_html_e( 'Wholesale sourcing', 'xiujin' ); ?></strong><span><?php esc_html_e( 'Quantities, configurations and destination confirmed by quotation', 'xiujin' ); ?></span></div>
				<div><strong><?php esc_html_e( 'Retail enquiries', 'xiujin' ); ?></strong><span><?php esc_html_e( 'Individual chair requests are confirmed through an enquiry', 'xiujin' ); ?></span></div>
			</div>
		</div>
		<div class="hero-media">
			<?php if ( $hero_image_id ) : ?>
				<?php echo wp_get_attachment_image( $hero_image_id, 'full', false, array( 'class' => 'hero-image', 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'alt' => __( 'XIUJIN chair collection', 'xiujin' ) ) ); ?>
			<?php else : ?>
				<img class="hero-image" src="<?php echo esc_url( xiujin_theme_asset( 'hero-chair-collection.webp' ) ); ?>" width="1200" height="900" loading="eager" fetchpriority="high" decoding="async" alt="<?php esc_attr_e( 'Five gaming chair styles in blue, yellow, orange, red and black with white accents', 'xiujin' ); ?>">
			<?php endif; ?>
			<div class="hero-color-dots" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></div>
			<p class="hero-media-note"><span><?php esc_html_e( 'Multiple finishes', 'xiujin' ); ?></span><?php esc_html_e( 'Confirm current color and upholstery options with your quotation.', 'xiujin' ); ?></p>
		</div>
	</div>
</section>
<section class="proof-strip" aria-label="<?php esc_attr_e( 'Catalog summary', 'xiujin' ); ?>">
	<div class="page-width proof-grid">
		<div class="proof-item"><strong data-counter="18">18</strong><span><?php esc_html_e( 'source catalog series', 'xiujin' ); ?></span></div>
		<div class="proof-item"><strong data-counter="58">58</strong><span><?php esc_html_e( 'catalog visual configurations', 'xiujin' ); ?></span></div>
		<div class="proof-item"><strong data-counter="3">3</strong><span><?php esc_html_e( 'seating categories', 'xiujin' ); ?></span></div>
		<div class="proof-item proof-item--text"><strong><?php esc_html_e( 'B2B + retail', 'xiujin' ); ?></strong><span><?php esc_html_e( 'quotation and enquiry paths', 'xiujin' ); ?></span></div>
	</div>
</section>

