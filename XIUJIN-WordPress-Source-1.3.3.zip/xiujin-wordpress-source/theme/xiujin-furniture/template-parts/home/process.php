<?php
/**
 * Order process and FAQ.
 *
 * @package Xiujin
 */
$steps = array(
	array( __( 'Choose chair series', 'xiujin' ), __( 'Shortlist the seating styles that fit your customers or project.', 'xiujin' ) ),
	array( __( 'Confirm configuration', 'xiujin' ), __( 'Discuss upholstery, colors, components, packaging and quantity.', 'xiujin' ) ),
	array( __( 'Receive quotation', 'xiujin' ), __( 'Review the current price, minimum order, lead time and shipping terms.', 'xiujin' ) ),
	array( __( 'Confirm the order', 'xiujin' ), __( 'Agree on samples, payment and delivery details before proceeding.', 'xiujin' ) ),
);
?>
<section id="process" class="section process-section">
	<div class="page-width">
		<?php xiujin_section_heading( __( 'From enquiry to order', 'xiujin' ), __( 'A clear path to your next chair order.', 'xiujin' ), __( 'The process keeps product selection separate from the final commercial confirmation.', 'xiujin' ) ); ?>
		<div class="process-grid">
			<?php foreach ( $steps as $index => $step ) : ?>
				<article class="process-step" data-reveal><span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span><h3><?php echo esc_html( $step[0] ); ?></h3><p><?php echo esc_html( $step[1] ); ?></p></article>
			<?php endforeach; ?>
		</div>
		<div class="faq-layout">
			<div data-reveal><span class="eyebrow"><?php esc_html_e( 'Before you order', 'xiujin' ); ?></span><h2><?php esc_html_e( 'Details we confirm with you.', 'xiujin' ); ?></h2></div>
			<div class="faq-list">
				<details data-reveal><summary><?php esc_html_e( 'Can I request mixed chair series?', 'xiujin' ); ?></summary><p><?php esc_html_e( 'Tell us which series and quantities you need. Feasibility, packing and commercial terms are confirmed with the quotation.', 'xiujin' ); ?></p></details>
				<details data-reveal><summary><?php esc_html_e( 'Are all colors and options always available?', 'xiujin' ); ?></summary><p><?php esc_html_e( 'Availability can vary by chair series and order. Use the catalog photos as references and confirm current options before ordering.', 'xiujin' ); ?></p></details>
				<details data-reveal><summary><?php esc_html_e( 'Can I enquire about a single chair?', 'xiujin' ); ?></summary><p><?php esc_html_e( 'Yes. Send the model and quantity you need. We confirm availability, price and delivery directly; this site does not take online payment.', 'xiujin' ); ?></p></details>
			</div>
		</div>
	</div>
</section>

