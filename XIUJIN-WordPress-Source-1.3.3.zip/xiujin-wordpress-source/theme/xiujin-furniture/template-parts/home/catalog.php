<?php
/**
 * Published WooCommerce products or the source-checked starter catalog.
 *
 * @package Xiujin
 */
$store_products = array();
if ( function_exists( 'wc_get_products' ) ) {
	$store_products = wc_get_products(
		array(
			'status'     => 'publish',
			'visibility' => 'catalog',
			'limit'      => 18,
			'orderby'    => 'menu_order',
			'order'      => 'ASC',
		)
	);
}
?>
<section id="catalog" class="section catalog-section">
	<div class="page-width">
		<?php xiujin_section_heading( __( 'Chair catalog', 'xiujin' ), __( 'Explore all 18 source series.', 'xiujin' ), __( 'Each series has an independent introduction. Ask us to confirm the configuration, availability and current quotation before ordering.', 'xiujin' ) ); ?>
		<div class="product-grid">
			<?php if ( $store_products ) : ?>
				<?php foreach ( $store_products as $store_product ) : ?>
					<article class="product-card" data-reveal>
						<a class="product-image" href="<?php echo esc_url( $store_product->get_permalink() ); ?>"><?php echo $store_product->get_image( 'xiujin-card', array( 'loading' => 'lazy', 'decoding' => 'async' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
						<div class="product-copy"><span class="product-category"><?php echo wp_kses_post( wc_get_product_category_list( $store_product->get_id(), ', ' ) ); ?></span><h3><a href="<?php echo esc_url( $store_product->get_permalink() ); ?>"><?php echo esc_html( $store_product->get_name() ); ?></a></h3><?php if ( '' !== $store_product->get_price() ) : ?><div class="product-price"><?php echo wp_kses_post( $store_product->get_price_html() ); ?></div><?php else : ?><p><?php esc_html_e( 'Request current quotation', 'xiujin' ); ?></p><?php endif; ?><a class="card-link" href="<?php echo esc_url( $store_product->get_permalink() ); ?>" aria-label="<?php echo esc_attr( __( 'View product', 'xiujin' ) . ': ' . $store_product->get_name() ); ?>"><?php esc_html_e( 'View product', 'xiujin' ); ?><span class="arrow" aria-hidden="true"></span></a></div>
					</article>
				<?php endforeach; ?>
			<?php else : ?>
				<?php foreach ( xiujin_catalog_series() as $series ) : ?>
					<article class="product-card" data-reveal>
						<a class="product-image" href="#quote" data-enquiry-product="<?php echo esc_attr( $series['title'] ); ?>"><img src="<?php echo esc_url( xiujin_theme_asset( $series['image'] ) ); ?>" width="720" height="720" loading="lazy" decoding="async" alt="<?php echo esc_attr( $series['title'] ); ?>"></a>
						<div class="product-copy"><span class="product-category"><?php echo esc_html( $series['category'] ); ?></span><h3><?php echo esc_html( $series['title'] ); ?></h3><p><?php echo esc_html( $series['detail'] ); ?></p><a class="card-link" href="#quote" data-enquiry-product="<?php echo esc_attr( $series['title'] ); ?>" aria-label="<?php echo esc_attr( __( 'Enquire about this chair', 'xiujin' ) . ': ' . $series['title'] ); ?>"><?php esc_html_e( 'Enquire about this chair', 'xiujin' ); ?><span class="arrow" aria-hidden="true"></span></a></div>
					</article>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
		<p class="catalog-note"><?php esc_html_e( 'Source-catalog descriptions are provided for selection. Final materials, colors, dimensions, packaging, price and availability follow the confirmed quotation.', 'xiujin' ); ?></p>
	</div>
</section>

