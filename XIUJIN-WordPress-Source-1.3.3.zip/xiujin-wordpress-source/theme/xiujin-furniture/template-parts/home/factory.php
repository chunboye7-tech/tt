<?php
/**
 * Verified facility photographs and warehouse footage supplied by XIUJIN.
 *
 * @package Xiujin
 */
$warehouse_video  = xiujin_theme_file( 'video/factory-warehouse.mp4' );
$warehouse_poster = xiujin_theme_asset( 'factory-warehouse-poster.webp' );
$warehouse_points = array(
	__( 'Finished-goods storage', 'xiujin' ),
	__( 'Cartonized inventory', 'xiujin' ),
	__( 'Dispatch preparation', 'xiujin' ),
);
$factory_photos   = array(
	array(
		'image'       => xiujin_theme_asset( 'factory-cnc-wood-components.webp' ),
		'title'       => __( 'CNC cutting for wood components', 'xiujin' ),
		'description' => __( 'A CNC router works beside stacks of shaped wooden chair components on the production floor.', 'xiujin' ),
	),
	array(
		'image'       => xiujin_theme_asset( 'factory-fabric-roll-cutting.webp' ),
		'title'       => __( 'Upholstery fabric roll preparation', 'xiujin' ),
		'description' => __( 'A large roll of dark upholstery fabric is positioned on the automated cutting table.', 'xiujin' ),
	),
	array(
		'image'       => xiujin_theme_asset( 'factory-fabric-cutting-table.webp' ),
		'title'       => __( 'Multi-layer fabric cutting', 'xiujin' ),
		'description' => __( 'Layers of upholstery fabric are spread across a long cutting table for batch preparation.', 'xiujin' ),
	),
	array(
		'image'       => xiujin_theme_asset( 'factory-upholstery-preparation.webp' ),
		'title'       => __( 'Foam and upholstery preparation', 'xiujin' ),
		'description' => __( 'Foam pieces and upholstered components are organized in the preparation area.', 'xiujin' ),
	),
);
?>
<section id="factory" class="section factory-section">
	<div class="factory-grid-pattern" aria-hidden="true"></div>
	<div class="page-width">
		<?php xiujin_section_heading( __( 'Actual facility media', 'xiujin' ), __( 'Inside the XIUJIN production and warehouse areas.', 'xiujin' ), __( 'See verified on-site photographs and finished-goods warehouse footage.', 'xiujin' ) ); ?>
		<div class="factory-media-layout">
			<figure class="factory-video-card" data-reveal>
				<div class="factory-video-shell">
					<video controls muted playsinline preload="none" poster="<?php echo esc_url( $warehouse_poster ); ?>" aria-label="<?php esc_attr_e( 'Video tour of the XIUJIN finished-goods warehouse', 'xiujin' ); ?>">
						<source src="<?php echo esc_url( $warehouse_video ); ?>" type="video/mp4">
						<a href="<?php echo esc_url( $warehouse_video ); ?>"><?php esc_html_e( 'Open the warehouse video', 'xiujin' ); ?></a>
					</video>
					<span class="factory-video-badge"><?php esc_html_e( 'Real warehouse video', 'xiujin' ); ?></span>
				</div>
				<figcaption><?php esc_html_e( 'Filmed in the XIUJIN finished-goods warehouse. The video has no audio and plays only when selected.', 'xiujin' ); ?></figcaption>
			</figure>
			<div class="factory-copy-card" data-reveal>
				<span class="eyebrow"><?php esc_html_e( 'Warehouse and dispatch', 'xiujin' ); ?></span>
				<h3><?php esc_html_e( 'Packed inventory prepared for dispatch', 'xiujin' ); ?></h3>
				<p><?php esc_html_e( 'This footage shows the actual XIUJIN finished-goods warehouse. Cartons are organized before quantities, destination, packaging and dispatch timing are confirmed for each order.', 'xiujin' ); ?></p>
				<ol class="factory-points">
					<?php foreach ( $warehouse_points as $index => $point ) : ?>
						<li><span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span><?php echo esc_html( $point ); ?></li>
					<?php endforeach; ?>
				</ol>
			</div>
		</div>

		<div class="factory-gallery-block">
			<div class="factory-gallery-heading" data-reveal>
				<div>
					<span class="eyebrow"><?php esc_html_e( 'Real production floor', 'xiujin' ); ?></span>
					<h3><?php esc_html_e( 'Production processes, photographed on site', 'xiujin' ); ?></h3>
				</div>
				<p><?php esc_html_e( 'These photographs show equipment, materials and preparation areas inside the XIUJIN facility.', 'xiujin' ); ?></p>
			</div>
			<div class="factory-gallery" data-factory-gallery>
				<?php foreach ( $factory_photos as $index => $photo ) : ?>
					<figure class="factory-photo-card<?php echo 0 === $index ? ' factory-photo-card--featured' : ''; ?>" data-reveal>
						<a class="factory-photo-link" href="<?php echo esc_url( $photo['image'] ); ?>" data-factory-photo data-title="<?php echo esc_attr( $photo['title'] ); ?>" data-caption="<?php echo esc_attr( $photo['description'] ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'View larger: %s', 'xiujin' ), $photo['title'] ) ); ?>">
							<img src="<?php echo esc_url( $photo['image'] ); ?>" width="1440" height="810" loading="lazy" decoding="async" alt="<?php echo esc_attr( $photo['description'] ); ?>">
							<span class="factory-photo-expand" aria-hidden="true"><?php esc_html_e( 'View larger', 'xiujin' ); ?></span>
						</a>
						<figcaption>
							<span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span>
							<div><strong><?php echo esc_html( $photo['title'] ); ?></strong><p><?php echo esc_html( $photo['description'] ); ?></p></div>
						</figcaption>
					</figure>
				<?php endforeach; ?>
			</div>
			<dialog class="factory-lightbox" data-factory-lightbox aria-labelledby="FactoryLightboxTitle">
				<button type="button" class="factory-lightbox-close" data-factory-lightbox-close><span aria-hidden="true">×</span><span class="screen-reader-text"><?php esc_html_e( 'Close image viewer', 'xiujin' ); ?></span></button>
				<figure>
					<img src="<?php echo esc_url( $factory_photos[0]['image'] ); ?>" width="1440" height="810" alt="<?php echo esc_attr( $factory_photos[0]['description'] ); ?>" data-factory-lightbox-image>
					<figcaption><strong id="FactoryLightboxTitle" data-factory-lightbox-title><?php esc_html_e( 'Factory photograph viewer', 'xiujin' ); ?></strong><span data-factory-lightbox-caption></span></figcaption>
				</figure>
			</dialog>
		</div>
	</div>
</section>
