<?php
/**
 * Real photo configurations synchronized with six approximate 3D references.
 *
 * @package Xiujin
 */
$configurations = xiujin_photo_configurations();
$first_config   = $configurations[0];
$model_options  = $configurations;
usort(
	$model_options,
	static function ( $left, $right ) {
		return $left['model_index'] <=> $right['model_index'];
	}
);
?>
<section id="configurations" class="section configuration-section" data-config-gallery>
	<div class="page-width">
		<?php xiujin_section_heading( __( 'Real product references', 'xiujin' ), __( 'Compare each finish with its matching 3D view.', 'xiujin' ), __( 'Select a supplied catalog photo to display the corresponding 3D approximation. Use the photo to confirm the exact color and upholstery.', 'xiujin' ) ); ?>
		<div class="configuration-layout">
			<figure class="reference-card" data-reveal>
				<div class="reference-image"><img data-config-image src="<?php echo esc_url( xiujin_theme_asset( $first_config['image'] ) ); ?>" width="910" height="1451" loading="lazy" decoding="async" alt="<?php echo esc_attr( $first_config['alt'] ); ?>"></div>
				<figcaption><span><?php esc_html_e( 'Actual catalog photo', 'xiujin' ); ?></span><strong data-config-title aria-live="polite"><?php echo esc_html( $first_config['title'] ); ?></strong><small><?php esc_html_e( 'Use the photo to confirm visible color and upholstery details.', 'xiujin' ); ?></small></figcaption>
			</figure>
			<div class="model-card" data-model-loader data-model-src="<?php echo esc_url( XIUJIN_THEME_URI . '/assets/js/chair-model.js' ); ?>" data-reveal>
				<div class="model-heading"><span><?php esc_html_e( 'Interactive 3D reference', 'xiujin' ); ?></span><strong data-model-title aria-live="polite"><?php echo esc_html( $first_config['title'] ); ?></strong></div>
				<div class="model-shell" data-chair-model data-drag-zoom="<?php esc_attr_e( 'Drag to rotate · Use buttons to zoom', 'xiujin' ); ?>" data-selected-finish="<?php echo esc_attr( $first_config['title'] ); ?>" data-load-prompt="<?php esc_attr_e( 'Load the 3D view to inspect this finish.', 'xiujin' ); ?>" data-error-text="<?php esc_attr_e( 'The 3D view could not load.', 'xiujin' ); ?>" data-unavailable-text="<?php esc_attr_e( '3D is unavailable in this browser.', 'xiujin' ); ?>">
					<img class="model-poster" data-model-poster src="<?php echo esc_url( xiujin_theme_asset( $first_config['image'] ) ); ?>" width="910" height="1451" loading="lazy" decoding="async" alt="">
					<label class="screen-reader-text" for="ChairReferenceSelect"><?php esc_html_e( '3D appearance', 'xiujin' ); ?></label><select class="screen-reader-text" id="ChairReferenceSelect" data-model-select tabindex="-1" aria-hidden="true">
						<?php foreach ( $model_options as $configuration ) : ?>
							<option value="<?php echo esc_attr( (string) $configuration['model_index'] ); ?>"><?php echo esc_html( $configuration['title'] ); ?></option>
						<?php endforeach; ?>
					</select>
					<canvas tabindex="-1" aria-label="<?php esc_attr_e( 'Interactive 3D chair reference. Use arrow keys to rotate and plus or minus to zoom.', 'xiujin' ); ?>" aria-keyshortcuts="ArrowLeft ArrowRight ArrowUp ArrowDown + -" role="img"><?php esc_html_e( 'Interactive chair reference', 'xiujin' ); ?></canvas>
					<button class="model-load-button button button--gold" type="button" data-model-load aria-describedby="ChairModelStatus"><?php esc_html_e( 'Load 3D view', 'xiujin' ); ?><span class="arrow" aria-hidden="true"></span></button>
					<div class="model-controls" role="group" aria-label="<?php esc_attr_e( 'Choose viewing angle', 'xiujin' ); ?>">
						<button type="button" data-angle="0" aria-pressed="true" disabled><?php esc_html_e( 'Front', 'xiujin' ); ?></button><button type="button" data-angle="3.1415926536" aria-pressed="false" disabled><?php esc_html_e( 'Back', 'xiujin' ); ?></button><button type="button" data-angle="-1.5707963268" aria-pressed="false" disabled><?php esc_html_e( 'Left', 'xiujin' ); ?></button><button type="button" data-angle="1.5707963268" aria-pressed="false" disabled><?php esc_html_e( 'Right', 'xiujin' ); ?></button><button type="button" data-zoom="0.82" disabled><?php esc_html_e( 'Zoom in', 'xiujin' ); ?></button><button type="button" data-zoom="1.22" disabled><?php esc_html_e( 'Zoom out', 'xiujin' ); ?></button>
					</div>
					<span id="ChairModelStatus" class="model-status" data-status aria-live="polite"><?php esc_html_e( 'Load the 3D view to inspect this finish.', 'xiujin' ); ?></span>
				</div>
				<p class="model-disclosure"><?php esc_html_e( 'The 3D object is an approximate visual reference reconstructed from supplied photos. Confirm construction and dimensions against production specifications.', 'xiujin' ); ?></p>
			</div>
		</div>
		<div class="configuration-picker" data-reveal>
			<div><strong><?php esc_html_e( 'Photo configurations', 'xiujin' ); ?></strong><span><?php esc_html_e( 'Select a photo and matching 3D finish', 'xiujin' ); ?></span></div>
			<div class="configuration-options" role="group" aria-label="<?php esc_attr_e( 'Product photo configurations', 'xiujin' ); ?>">
				<?php foreach ( $configurations as $index => $configuration ) : ?>
					<button type="button" class="configuration-option" data-config-choice data-model-index="<?php echo esc_attr( (string) $configuration['model_index'] ); ?>" data-model-key="<?php echo esc_attr( $configuration['model_key'] ); ?>" data-image="<?php echo esc_url( xiujin_theme_asset( $configuration['image'] ) ); ?>" data-title="<?php echo esc_attr( $configuration['title'] ); ?>" data-alt="<?php echo esc_attr( $configuration['alt'] ); ?>" aria-pressed="<?php echo 0 === $index ? 'true' : 'false'; ?>"><img src="<?php echo esc_url( xiujin_theme_asset( $configuration['image'] ) ); ?>" width="180" height="220" loading="lazy" decoding="async" alt=""><span><?php echo esc_html( $configuration['title'] ); ?></span></button>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>

