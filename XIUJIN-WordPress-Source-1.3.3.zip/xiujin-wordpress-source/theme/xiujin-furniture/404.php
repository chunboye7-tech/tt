<?php
/**
 * Not found template.
 *
 * @package Xiujin
 */
get_header();
?>
<main id="primary" class="site-main page-width error-page"><span class="eyebrow">404</span><h1><?php esc_html_e( 'This page could not be found.', 'xiujin' ); ?></h1><p><?php esc_html_e( 'Return to the chair catalog or contact us about the product you need.', 'xiujin' ); ?></p><a class="button" href="<?php echo esc_url( xiujin_home_url() ); ?>"><?php esc_html_e( 'Return home', 'xiujin' ); ?><span class="arrow" aria-hidden="true"></span></a></main>
<?php get_footer(); ?>

