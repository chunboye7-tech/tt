#!/usr/bin/env node
'use strict';

const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const PhpParser = require('php-parser');

const projectRoot = path.resolve(process.argv[2] || path.join(__dirname, '..'));
const outputPath = path.resolve(process.argv[3] || path.join(projectRoot, 'tests', 'artifacts', 'php-ast-validation.json'));
const roots = [
  path.join(projectRoot, 'theme', 'xiujin-furniture'),
  path.join(projectRoot, 'plugin', 'xiujin-store-core'),
];

const parser = new PhpParser.Engine({
  parser: {
    extractDoc: true,
    suppressErrors: false,
    version: '8.1',
  },
  ast: { withPositions: true },
});

async function collect(directory) {
  const files = [];
  for (const entry of await fsp.readdir(directory, { withFileTypes: true })) {
    if (entry.name === 'node_modules' || entry.name === 'vendor') continue;
    const target = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...await collect(target));
    else if (entry.isFile() && entry.name.endsWith('.php')) files.push(target);
  }
  return files;
}

(async () => {
  const files = (await Promise.all(roots.map(collect))).flat().sort();
  const results = [];
  for (const file of files) {
    const relative = path.relative(projectRoot, file).split(path.sep).join('/');
    try {
      parser.parseCode(await fsp.readFile(file, 'utf8'), relative);
      results.push({ file: relative, passed: true });
    } catch (error) {
      results.push({ file: relative, passed: false, error: String(error.message || error) });
    }
  }

  const failed = results.filter((item) => !item.passed);
  const report = {
    parser: `php-parser ${require('php-parser/package.json').version}`,
    phpLanguageLevel: '8.1',
    summary: {
      files: results.length,
      passed: results.length - failed.length,
      failed: failed.length,
    },
    results,
  };
  await fsp.mkdir(path.dirname(outputPath), { recursive: true });
  await fsp.writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`);
  console.log(JSON.stringify(report.summary, null, 2));
  if (failed.length) process.exitCode = 1;
})().catch((error) => {
  console.error(error.stack || error);
  process.exitCode = 1;
});
