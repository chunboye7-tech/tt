#!/usr/bin/env python3
"""Sync the verified 18-series/58-configuration index into the theme.

The complete catalog media belongs to the WooCommerce import package. Keeping
another copy inside the theme would add several megabytes to every theme
upload and backup even though WordPress never enqueues those files.
"""

from __future__ import annotations

import csv
import json
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "dist" / "woocommerce-import"
THEME = ROOT / "theme" / "xiujin-furniture"
DATA_TARGET = THEME / "data"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def main() -> None:
    products_path = SOURCE / "XIUJIN-WooCommerce-products-DRAFT.csv"
    configurations_path = SOURCE / "XIUJIN-WooCommerce-58-configurations.csv"
    products = read_csv(products_path)
    configurations = read_csv(configurations_path)
    if len(products) != 18 or len(configurations) != 58:
        raise RuntimeError(
            f"Expected 18 products and 58 configurations; got {len(products)} and {len(configurations)}"
        )

    DATA_TARGET.mkdir(parents=True, exist_ok=True)

    legacy_media_target = THEME / "assets" / "catalog-configurations"
    if legacy_media_target.exists():
        shutil.rmtree(legacy_media_target)

    shutil.copy2(configurations_path, DATA_TARGET / "catalog-configurations.csv")
    manifest = {
        "schema_version": 1,
        "notice": (
            "Catalog reference data only. Price, currency, inventory, materials, "
            "MOQ and availability require confirmation before publication."
        ),
        "series": [
            {
                "sku": row["SKU"],
                "public_title": row["Name"],
                "category": row["Categories"],
                "configuration_ids": row["Meta: _xiujin_configuration_ids"].split("|"),
            }
            for row in products
        ],
        "configurations": [
            {
                "id": row["configuration_id"],
                "parent_sku": row["parent_sku"],
                "description": row["visual_description"],
                "image": row["media_library_filename"],
                "sha256": row.get("output_sha256") or row["sha256"],
                "source_sha256": row.get("source_sha256") or row["sha256"],
                "transformation": row.get("transformation", "none"),
            }
            for row in configurations
        ],
    }
    (DATA_TARGET / "catalog-manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(f"Synced {len(products)} series and {len(configurations)} configurations into theme data")


if __name__ == "__main__":
    main()
