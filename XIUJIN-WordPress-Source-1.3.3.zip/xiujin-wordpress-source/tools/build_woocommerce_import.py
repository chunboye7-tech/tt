#!/usr/bin/env python3
"""Build the XIUJIN WooCommerce draft product import package.

The source catalog contains 18 product series, 58 photographed visual
configurations and 118 embedded product/specification images. Every image is
kept as product media with traceable provenance. A visual configuration is
deliberately not turned into a purchasable WooCommerce variation until its
SKU, price, currency and availability are confirmed.

The generated product CSV uses only columns understood by WooCommerce's core
CSV importer.  Image cells contain Media Library filenames.  Upload the
generated ``product-images`` directory to the WordPress Media Library without
renaming files before importing the product CSV.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import re
import shutil
import sys
from collections import Counter, defaultdict
from pathlib import Path, PurePosixPath
from zipfile import ZipFile

from PIL import Image


PROJECT_ROOT = Path(__file__).resolve().parents[1]
INPUT_ROOT = PROJECT_ROOT / "inputs"
SOURCE_ROOT = INPUT_ROOT / "chair-trade-studio"

DEFAULT_CATALOG = SOURCE_ROOT / "catalog_copy.json"
DEFAULT_CONFIGURATION_CSV = (
    SOURCE_ROOT / "delivery" / "XIUJIN-58-visual-configurations.csv"
)
DEFAULT_IMAGE_ARCHIVE = SOURCE_ROOT / "delivery" / "XIUJIN-58-product-images.zip"
DEFAULT_MEDIA_MANIFEST = INPUT_ROOT / "catalog-review" / "images.json"
DEFAULT_OUTPUT = PROJECT_ROOT / "dist" / "woocommerce-import"

EXPECTED_PRODUCT_COUNT = 18
EXPECTED_CONFIGURATION_COUNT = 58
EXPECTED_MEDIA_COUNT = 118
PRODUCT_SOURCE_ROWS = (2, 12, 22, 32, 42, 51, 61, 71, 81, 91, 101, 111, 121, 131, 141, 151, 161, 171)

# These descriptions were checked against the original catalog images.
# Keeping this small correction table here prevents the known 8011 colour-name
# mismatch from being carried into the new WordPress package while preserving
# the source wording in a separate mapping column.
VISUAL_DESCRIPTION_CORRECTIONS = {
    "S01-R002-V01": "Black and white colorway",
    "S01-R002-V02": "Black and red colorway with multicolor accent trim",
    "S01-R002-V03": "Black, white and blue colorway",
    "S01-R002-V04": "Black and yellow colorway",
    "S01-R002-V05": "Black and red alternate cushion styling",
    "S01-R002-V06": "Black and orange fabric colorway",
    "S12-R111-V02": "Gray mesh chair with light frame",
}

# The user asked to remove the source number 8011 from all customer-facing
# copy.  It remains available to staff in the SKU and source metadata so the
# imported product can still be traced back to the price sheet.
PUBLIC_CONTENT_OVERRIDES = {
    "8011": {
        "title": "135° Reclining Gaming Chair",
        "overview": (
            "A configurable gaming chair series for wholesale and retail orders, "
            "combining a 135-degree recline with seat-height adjustment and swivel movement."
        ),
        "seo_title": "135° Reclining Gaming Chair | XIUJIN",
        "seo_description": (
            "A reclining gaming chair with height adjustment, swivel and linked armrests. "
            "Ask XIUJIN about upholstery and order options."
        ),
    }
}

PRODUCT_COLUMNS = [
    "Type",
    "SKU",
    "Name",
    "Published",
    "Is featured?",
    "Visibility in catalog",
    "Short description",
    "Description",
    "Tax status",
    "In stock?",
    "Stock",
    "Backorders allowed?",
    "Sold individually?",
    "Allow customer reviews?",
    "Regular price",
    "Sale price",
    "Categories",
    "Tags",
    "Images",
    "Position",
    "Attribute 1 name",
    "Attribute 1 value(s)",
    "Attribute 1 visible",
    "Attribute 1 global",
    "Meta: _xiujin_source_handle",
    "Meta: _xiujin_source_row",
    "Meta: _xiujin_source_model",
    "Meta: _xiujin_configuration_ids",
    "Meta: _xiujin_sales_mode",
    "Meta: _xiujin_checkout_mode",
    "Meta: _xiujin_moq",
    "Meta: _xiujin_lead_time",
    "Meta: _xiujin_commercial_status",
    "Meta: _yoast_wpseo_title",
    "Meta: _yoast_wpseo_metadesc",
    "Meta: rank_math_title",
    "Meta: rank_math_description",
]

CONFIGURATION_COLUMNS = [
    "parent_sku",
    "parent_handle",
    "parent_product_name",
    "parent_category",
    "series_order",
    "source_start_row",
    "source_model_or_name",
    "configuration_number",
    "configuration_id",
    "visual_description",
    "observed_visual_description",
    "source_image_file",
    "media_library_filename",
    "source_image_width_px",
    "source_image_height_px",
    "image_width_px",
    "image_height_px",
    "source_sha256",
    "output_sha256",
    "transformation",
    "sha256",
    "verification_status",
    "commercial_status",
    "catalog_caution",
]

MEDIA_COLUMNS = [
    "parent_sku",
    "parent_handle",
    "parent_product_name",
    "source_start_row",
    "media_order",
    "role",
    "alt_text",
    "source_image_file",
    "media_library_filename",
    "source_width_px",
    "source_height_px",
    "output_width_px",
    "output_height_px",
    "source_sha256",
    "output_sha256",
    "transformation",
    "configuration_id",
    "duplicate_source_of",
]


class BuildError(RuntimeError):
    """Raised when the source package is incomplete or internally inconsistent."""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate draft WooCommerce product and configuration CSV files."
    )
    parser.add_argument("--catalog", type=Path, default=DEFAULT_CATALOG)
    parser.add_argument(
        "--configurations", type=Path, default=DEFAULT_CONFIGURATION_CSV
    )
    parser.add_argument("--images", type=Path, default=DEFAULT_IMAGE_ARCHIVE)
    parser.add_argument(
        "--media-manifest", type=Path, default=DEFAULT_MEDIA_MANIFEST
    )
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_catalog(path: Path) -> tuple[dict, list[dict]]:
    if not path.is_file():
        raise BuildError(f"Catalog JSON not found: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or not isinstance(payload.get("products"), list):
        raise BuildError("Catalog JSON must contain a products array")
    products = payload["products"]
    if len(products) != EXPECTED_PRODUCT_COUNT:
        raise BuildError(
            f"Expected {EXPECTED_PRODUCT_COUNT} products; found {len(products)}"
        )
    required = {
        "source_row",
        "source_name",
        "handle",
        "category",
        "title",
        "overview",
        "highlights",
        "construction",
        "quote_options",
        "feature_tags",
        "seo_title",
        "seo_description",
        "price_publishable",
        "confirmation_notes",
    }
    for index, product in enumerate(products, start=1):
        missing = sorted(required - product.keys())
        if missing:
            raise BuildError(f"Catalog product {index} is missing: {', '.join(missing)}")
        if product["price_publishable"] is not False:
            raise BuildError(
                f"Product at source row {product['source_row']} unexpectedly permits price publication"
            )
    return payload, products


def load_configurations(path: Path) -> list[dict]:
    if not path.is_file():
        raise BuildError(f"Configuration CSV not found: {path}")
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
    required = {
        "series_order",
        "source_start_row",
        "source_model_or_name",
        "visual_configuration_number",
        "visual_configuration_id",
        "apparent_visual_description",
        "source_image_file",
        "packaged_image_file",
        "image_width_px",
        "image_height_px",
        "sha256",
        "verification_status",
        "catalog_caution",
    }
    missing = sorted(required - set(reader.fieldnames or []))
    if missing:
        raise BuildError(f"Configuration CSV is missing: {', '.join(missing)}")
    if len(rows) != EXPECTED_CONFIGURATION_COUNT:
        raise BuildError(
            f"Expected {EXPECTED_CONFIGURATION_COUNT} configurations; found {len(rows)}"
        )
    return rows


def load_media_manifest(path: Path) -> list[dict]:
    """Load and normalize every embedded image extracted from the source workbook."""
    if not path.is_file():
        raise BuildError(f"Source media manifest not found: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, list):
        raise BuildError("Source media manifest must be a JSON array")
    if len(payload) != EXPECTED_MEDIA_COUNT:
        raise BuildError(
            f"Expected {EXPECTED_MEDIA_COUNT} source images; found {len(payload)}"
        )
    required = {"index", "row", "col", "path", "size"}
    seen_indexes: set[int] = set()
    seen_files: set[str] = set()
    rows: list[dict] = []
    for item in payload:
        if not isinstance(item, dict) or not required.issubset(item):
            raise BuildError(f"Invalid source media record: {item!r}")
        index = int(item["index"])
        row = int(item["row"])
        col = int(item["col"])
        filename = Path(str(item["path"])).name
        if index in seen_indexes or filename in seen_files:
            raise BuildError(f"Duplicate source media record: {filename}")
        seen_indexes.add(index)
        seen_files.add(filename)

        # OpenPyXL reports a few drawings against the continuation row below
        # the product block. Associate each with the nearest preceding series.
        # Five drawings have row 1 anchors: one is the row-2 dimension sheet,
        # while the other four are extra views for the row-121 chair.
        if index == 2:
            product_row = 2
        elif index in {70, 71, 72, 73}:
            product_row = 121
        else:
            preceding = [start for start in PRODUCT_SOURCE_ROWS if start <= row]
            if not preceding:
                raise BuildError(f"Cannot map source image {filename} at row {row}")
            product_row = max(preceding)

        source_path = Path(str(item["path"]))
        if not source_path.is_file():
            source_path = path.parent / filename
        if not source_path.is_file():
            raise BuildError(f"Source media file not found: {filename}")
        width, height = (int(value) for value in item["size"])
        with Image.open(source_path) as image:
            if image.size != (width, height):
                raise BuildError(
                    f"Source media dimensions mismatch for {filename}: "
                    f"manifest={(width, height)}, file={image.size}"
                )
            image.verify()
        rows.append(
            {
                "index": index,
                "row": row,
                "col": col,
                "source_path": source_path,
                "source_filename": filename,
                "source_width": width,
                "source_height": height,
                "product_row": product_row,
            }
        )
    if seen_indexes != set(range(EXPECTED_MEDIA_COUNT)):
        raise BuildError("Source media indexes must exactly cover 0 through 117")
    return rows


def make_sku(product: dict) -> str:
    model = str(product.get("model") or "").strip()
    if model:
        normalized = re.sub(r"[^A-Za-z0-9-]+", "-", model).strip("-").upper()
        return f"XJ-{normalized}"
    return f"XJ-R{int(product['source_row']):03d}"


def public_product(product: dict) -> dict:
    """Return customer-facing copy while preserving source fields internally."""
    model = str(product.get("model") or "").strip()
    return {**product, **PUBLIC_CONTENT_OVERRIDES.get(model, {})}


def list_html(items: list[str]) -> str:
    return "<ul>" + "".join(f"<li>{html.escape(str(item))}</li>" for item in items) + "</ul>"


def build_description(product: dict) -> str:
    sections = [
        f"<p>{html.escape(str(product['overview']))}</p>",
        "<h2>Product highlights</h2>",
        list_html(product["highlights"]),
        "<h2>Construction and components</h2>",
        list_html(product["construction"]),
        "<h2>Options for quotation</h2>",
        list_html(product["quote_options"]),
        (
            "<p><strong>Wholesale and retail enquiries:</strong> "
            "Contact XIUJIN to confirm the selected configuration, current availability, "
            "packaging, minimum order, lead time, currency, taxes, payment and shipping terms.</p>"
        ),
    ]
    return "".join(sections)


def group_configurations(rows: list[dict]) -> dict[int, list[dict]]:
    grouped: dict[int, list[dict]] = defaultdict(list)
    for row in rows:
        try:
            source_row = int(row["source_start_row"])
            int(row["series_order"])
            int(row["visual_configuration_number"])
        except (TypeError, ValueError) as error:
            raise BuildError(f"Invalid numeric configuration field: {row}") from error
        grouped[source_row].append(row)
    for source_row, group in grouped.items():
        group.sort(
            key=lambda row: (
                int(row["series_order"]),
                int(row["visual_configuration_number"]),
            )
        )
        ids = [row["visual_configuration_id"] for row in group]
        if len(ids) != len(set(ids)):
            raise BuildError(f"Duplicate configuration ID under source row {source_row}")
    return dict(grouped)


def archive_members_by_basename(archive: ZipFile) -> dict[str, str]:
    members: dict[str, str] = {}
    for member in archive.namelist():
        path = PurePosixPath(member)
        if path.is_absolute() or ".." in path.parts:
            raise BuildError(f"Unsafe path in image archive: {member}")
        if member.endswith("/"):
            continue
        basename = path.name
        if basename in members:
            raise BuildError(f"Duplicate archive basename: {basename}")
        members[basename] = member
    return members


def extract_and_verify_images(
    archive_path: Path, configuration_rows: list[dict], output_dir: Path
) -> list[dict]:
    if not archive_path.is_file():
        raise BuildError(f"Image archive not found: {archive_path}")
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    results = []
    with ZipFile(archive_path) as archive:
        corrupt_member = archive.testzip()
        if corrupt_member:
            raise BuildError(f"Image archive CRC failure: {corrupt_member}")
        members = archive_members_by_basename(archive)
        for row in configuration_rows:
            filename = Path(row["packaged_image_file"]).name
            member = members.get(filename)
            if not member:
                raise BuildError(f"Image missing from archive: {filename}")
            data = archive.read(member)
            digest = sha256_bytes(data)
            expected = row["sha256"].strip().lower()
            if digest != expected:
                raise BuildError(
                    f"Image hash mismatch for {filename}: expected {expected}, got {digest}"
                )
            destination = output_dir / filename
            destination.write_bytes(data)
            results.append(
                {
                    "filename": filename,
                    "bytes": len(data),
                    "sha256": digest,
                    "source_archive_member": member,
                }
            )
    if len(results) != EXPECTED_CONFIGURATION_COUNT:
        raise BuildError("Not all 58 configuration images were extracted")
    return results


def media_sort_key(item: dict) -> tuple[int, int]:
    """Put a useful storefront image first, galleries next, dimensions last."""
    if item["product_row"] == 22 and item["index"] == 15:
        return (-1, item["index"])
    column_rank = {2: 0, 10: 1, 1: 2, 6: 3}
    return (column_rank.get(item["col"], 2), item["index"])


def media_role(item: dict, order: int) -> str:
    if order == 1:
        return "primary"
    if item["col"] == 6:
        return "dimensions"
    return "gallery"


def media_alt_text(product: dict, item: dict, role: str, gallery_number: int) -> str:
    display = public_product(product)
    title = str(display["title"])
    if item.get("visual_description"):
        detail = str(item["visual_description"])
    elif role == "primary":
        detail = "front product view"
    elif role == "dimensions":
        detail = "dimensions and specification reference"
    else:
        detail = f"additional product view {gallery_number}"
    return f"{title} — {detail}"


def save_rotated_jpeg(source: Path, destination: Path) -> None:
    """Correct the physically sideways 8021 source while retaining provenance."""
    with Image.open(source) as image:
        corrected = image.convert("RGB").transpose(Image.Transpose.ROTATE_270)
        corrected.save(
            destination,
            format="JPEG",
            quality=95,
            optimize=True,
            progressive=True,
            subsampling=0,
        )


def build_complete_media_library(
    source_media: list[dict],
    configuration_rows: list[dict],
    products: list[dict],
    images_dir: Path,
) -> tuple[list[dict], dict[int, list[dict]]]:
    """Copy all 118 workbook images and build their auditable media mapping."""
    configurations_by_source = {
        row["source_image_file"]: row for row in configuration_rows
    }
    if len(configurations_by_source) != EXPECTED_CONFIGURATION_COUNT:
        raise BuildError("Configuration source image filenames are not unique")
    products_by_row = {int(product["source_row"]): product for product in products}
    series_by_row = {
        int(product["source_row"]): order
        for order, product in enumerate(products, start=1)
    }

    grouped: dict[int, list[dict]] = defaultdict(list)
    for item in source_media:
        grouped[int(item["product_row"])].append(item)
    if set(grouped) != set(products_by_row):
        raise BuildError("All products must have complete source media coverage")

    output_rows: list[dict] = []
    product_media: dict[int, list[dict]] = {}
    first_source_by_hash: dict[str, str] = {}
    for product_row in PRODUCT_SOURCE_ROWS:
        product = products_by_row[product_row]
        ordered = sorted(grouped[product_row], key=media_sort_key)
        prepared: list[dict] = []
        gallery_number = 0
        for order, item in enumerate(ordered, start=1):
            source_filename = item["source_filename"]
            configuration = configurations_by_source.get(source_filename)
            suffix = item["source_path"].suffix.lower()
            if configuration:
                destination_name = Path(configuration["packaged_image_file"]).name
                description = VISUAL_DESCRIPTION_CORRECTIONS.get(
                    configuration["visual_configuration_id"],
                    configuration["apparent_visual_description"],
                )
                configuration_id = configuration["visual_configuration_id"]
            else:
                destination_name = (
                    f"series-{series_by_row[product_row]:02d}-row-{product_row:03d}-"
                    f"media-{order:02d}{suffix}"
                )
                description = ""
                configuration_id = ""

            destination = images_dir / destination_name
            source_hash = sha256_file(item["source_path"])
            expected_configuration_hash = ""
            if configuration:
                expected_configuration_hash = configuration["sha256"].strip().lower()
                if source_hash != expected_configuration_hash:
                    raise BuildError(
                        f"Configuration/source hash mismatch: {source_filename}"
                    )
            transformation = "none"
            if item["index"] in {12, 13}:
                transformation = "rotate_90_clockwise"
                save_rotated_jpeg(item["source_path"], destination)
            elif configuration:
                # The verified archive extraction already wrote the selected
                # configuration under its stable Media Library filename.
                if sha256_file(destination) != expected_configuration_hash:
                    raise BuildError(
                        f"Configuration/source hash mismatch: {source_filename}"
                    )
            else:
                shutil.copyfile(item["source_path"], destination)

            with Image.open(destination) as output_image:
                output_width, output_height = output_image.size
                output_image.verify()
            output_hash = sha256_file(destination)
            role = media_role(item, order)
            if role == "gallery":
                gallery_number += 1
            alt_text = media_alt_text(
                product,
                {**item, "visual_description": description},
                role,
                gallery_number,
            )
            row = {
                "parent_sku": make_sku(product),
                "parent_handle": product["handle"],
                "parent_product_name": public_product(product)["title"],
                "source_start_row": str(product_row),
                "media_order": str(order),
                "role": role,
                "alt_text": alt_text,
                "source_image_file": source_filename,
                "media_library_filename": destination_name,
                "source_width_px": str(item["source_width"]),
                "source_height_px": str(item["source_height"]),
                "output_width_px": str(output_width),
                "output_height_px": str(output_height),
                "source_sha256": source_hash,
                "output_sha256": output_hash,
                "transformation": transformation,
                "configuration_id": configuration_id,
                "duplicate_source_of": first_source_by_hash.get(source_hash, ""),
            }
            first_source_by_hash.setdefault(source_hash, source_filename)
            output_rows.append(row)
            prepared.append(row)
        product_media[product_row] = prepared

    if len(output_rows) != EXPECTED_MEDIA_COUNT:
        raise BuildError(
            f"Expected {EXPECTED_MEDIA_COUNT} prepared media rows; found {len(output_rows)}"
        )
    output_names = [row["media_library_filename"] for row in output_rows]
    if len(output_names) != len(set(output_names)):
        raise BuildError("Generated Media Library filenames are not unique")
    actual_names = sorted(path.name for path in images_dir.iterdir() if path.is_file())
    if actual_names != sorted(output_names):
        raise BuildError("Product image directory contains missing or stale files")
    return output_rows, product_media


def configuration_description(source: dict) -> str:
    configuration_id = source["visual_configuration_id"]
    return VISUAL_DESCRIPTION_CORRECTIONS.get(
        configuration_id, source["apparent_visual_description"]
    )


def product_row(
    product: dict,
    position: int,
    configurations: list[dict],
    media_rows: list[dict],
) -> dict:
    display = public_product(product)
    filenames = [item["media_library_filename"] for item in media_rows]
    configuration_ids = [item["visual_configuration_id"] for item in configurations]
    appearance_labels = list(
        dict.fromkeys(configuration_description(item) for item in configurations)
    )
    tags = [
        "XIUJIN",
        "Factory Direct",
        "Wholesale",
        "Retail Ready",
        str(product["category"]),
        *[str(value) for value in product["feature_tags"]],
    ]
    return {
        "Type": "simple",
        "SKU": make_sku(product),
        "Name": display["title"],
        # WooCommerce's core importer uses -1 for draft, 0 for private and 1
        # for published.  Every generated product remains a reviewable draft.
        "Published": "-1",
        "Is featured?": "0",
        "Visibility in catalog": "visible",
        "Short description": f"<p>{html.escape(str(display['overview']))}</p>",
        "Description": build_description(display),
        "Tax status": "",
        "In stock?": "",
        "Stock": "",
        "Backorders allowed?": "",
        "Sold individually?": "",
        "Allow customer reviews?": "",
        "Regular price": "",
        "Sale price": "",
        "Categories": f"Chairs > {product['category']}",
        "Tags": ", ".join(dict.fromkeys(tags)),
        "Images": ", ".join(filenames),
        "Position": str(position),
        "Attribute 1 name": "Appearance references",
        "Attribute 1 value(s)": ", ".join(appearance_labels),
        "Attribute 1 visible": "1",
        "Attribute 1 global": "0",
        "Meta: _xiujin_source_handle": product["handle"],
        "Meta: _xiujin_source_row": str(product["source_row"]),
        "Meta: _xiujin_source_model": product.get("model") or "",
        "Meta: _xiujin_configuration_ids": "|".join(configuration_ids),
        "Meta: _xiujin_sales_mode": "both",
        "Meta: _xiujin_checkout_mode": "enquiry",
        "Meta: _xiujin_moq": "",
        "Meta: _xiujin_lead_time": "",
        "Meta: _xiujin_commercial_status": "Quotation required; commercial terms unconfirmed",
        "Meta: _yoast_wpseo_title": display["seo_title"],
        "Meta: _yoast_wpseo_metadesc": display["seo_description"],
        "Meta: rank_math_title": display["seo_title"],
        "Meta: rank_math_description": display["seo_description"],
    }


def configuration_row(product: dict, source: dict, media: dict) -> dict:
    configuration_id = source["visual_configuration_id"]
    display = public_product(product)
    return {
        "parent_sku": make_sku(product),
        "parent_handle": product["handle"],
        "parent_product_name": display["title"],
        "parent_category": product["category"],
        "series_order": source["series_order"],
        "source_start_row": source["source_start_row"],
        "source_model_or_name": source["source_model_or_name"],
        "configuration_number": source["visual_configuration_number"],
        "configuration_id": configuration_id,
        "visual_description": configuration_description(source),
        # This is an observation from the supplied image, not authoritative
        # factory colour/material data. Keep that boundary explicit.
        "observed_visual_description": configuration_description(source),
        "source_image_file": source["source_image_file"],
        "media_library_filename": media["media_library_filename"],
        "source_image_width_px": media["source_width_px"],
        "source_image_height_px": media["source_height_px"],
        "image_width_px": media["output_width_px"],
        "image_height_px": media["output_height_px"],
        "source_sha256": media["source_sha256"],
        "output_sha256": media["output_sha256"],
        "transformation": media["transformation"],
        # Backward-compatible hash column refers to the distributed file.
        "sha256": media["output_sha256"],
        "verification_status": source["verification_status"],
        "commercial_status": (
            "Photo reference only; confirm SKU, color, material, price, currency and availability"
        ),
        "catalog_caution": source["catalog_caution"],
    }


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    # UTF-8 BOM keeps multilingual text readable when the CSV is opened in Excel.
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def write_readme(path: Path) -> None:
    path.write_text(
        """# XIUJIN WooCommerce 商品导入包（草稿）

本目录由 `tools/build_woocommerce_import.py` 生成，包含 18 个产品系列、58 个可追溯外观配置和源价目表内全部 118 张商品媒体。

## 导入顺序

1. 在 WordPress 后台打开 **媒体 → 添加新媒体文件**，先上传 `product-images/` 内的 118 张图片；请勿改名。
2. 打开 **商品 → 所有商品 → 导入**，选择 `XIUJIN-WooCommerce-products-DRAFT.csv`。
3. 检查 WooCommerce 自动匹配的字段；`Meta:` 开头的列应映射为自定义元数据。
4. 参照 `XIUJIN-WooCommerce-media-library.csv` 为媒体库图片填写 ALT 文本；该映射不会被 WooCommerce 商品 CSV 自动写入媒体附件。
5. 完成导入后，18 个商品均为草稿。逐个核对图片、文案、商品类别及 SEO，再补充经过确认的销售资料。

## 数据边界

- 价格、促销价、币种、税务状态和库存均为空。
- 58 个视觉配置是图片/询价参考，不是已经确认可售的 WooCommerce 变体。
- WooCommerce 在本项目中用于管理目录和商品媒体；所有商品均设置为批发和零售询价，线上结账方式为 `enquiry`，不启用在线付款。
- `_xiujin_moq` 与 `_xiujin_lead_time` 保持为空，确认工厂商业资料后再填写。
- 发布前必须确认具体 SKU、颜色、材料、尺寸、MOQ、包装、交期、付款和运输条款。
- `XIUJIN-WooCommerce-58-configurations.csv` 记录每张图片与父商品、配置编号、原图及 SHA-256 的关系。
- `XIUJIN-WooCommerce-media-library.csv` 记录全部媒体的顺序、用途、ALT 文本、原始/输出尺寸、原始/输出 SHA-256 及旋转修正。
- SEO 元数据同时写入 Yoast SEO 与 Rank Math 常用字段；未安装对应插件时不会影响商品导入。

## 文件说明

- `XIUJIN-WooCommerce-products-DRAFT.csv`：WooCommerce 核心导入器使用的 18 个草稿产品。
- `XIUJIN-WooCommerce-58-configurations.csv`：58 个视觉配置的可审计映射。
- `XIUJIN-WooCommerce-media-library.csv`：全部 118 张商品媒体及可审计来源/ALT 映射。
- `product-images/`：118 张商品图片；两张横置的 8021 图片已生成顺时针旋转 90° 的展示副本，并保留源文件哈希。
- `import-manifest.json`：输入文件、输出文件和计数摘要。
- `validation-report.json`：构建后的自动验证结果。
""",
        encoding="utf-8",
    )


def read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def validate_outputs(
    product_csv: Path,
    configuration_csv: Path,
    media_csv: Path,
    images_dir: Path,
    source_products: list[dict],
) -> dict:
    products = read_csv(product_csv)
    configurations = read_csv(configuration_csv)
    media = read_csv(media_csv)
    errors: list[str] = []

    if len(products) != EXPECTED_PRODUCT_COUNT:
        errors.append(f"Product row count is {len(products)}, expected 18")
    if len(configurations) != EXPECTED_CONFIGURATION_COUNT:
        errors.append(f"Configuration row count is {len(configurations)}, expected 58")
    if len(media) != EXPECTED_MEDIA_COUNT:
        errors.append(f"Media row count is {len(media)}, expected 118")

    skus = [row["SKU"] for row in products]
    config_ids = [row["configuration_id"] for row in configurations]
    configuration_filenames = [row["media_library_filename"] for row in configurations]
    media_filenames = [row["media_library_filename"] for row in media]
    if len(skus) != len(set(skus)):
        errors.append("Product SKUs are not unique")
    if len(config_ids) != len(set(config_ids)):
        errors.append("Configuration IDs are not unique")
    if len(configuration_filenames) != len(set(configuration_filenames)):
        errors.append("Configuration image filenames are not unique")
    if len(media_filenames) != len(set(media_filenames)):
        errors.append("Media Library filenames are not unique")

    parent_skus = {row["parent_sku"] for row in configurations}
    if parent_skus != set(skus):
        errors.append("Configuration parent SKUs do not exactly cover all products")

    unsafe_fields = ["Regular price", "Sale price", "In stock?", "Stock", "Tax status"]
    for row in products:
        if row.get("Published") != "-1":
            errors.append(f"Product {row.get('SKU')} is not a draft")
        for field in unsafe_fields:
            if row.get(field):
                errors.append(f"Product {row.get('SKU')} has an unconfirmed {field}")
        if not row.get("Images"):
            errors.append(f"Product {row.get('SKU')} has no mapped images")
        if row.get("Meta: _xiujin_sales_mode") != "both":
            errors.append(f"Product {row.get('SKU')} is not wholesale + retail")
        if row.get("Meta: _xiujin_checkout_mode") != "enquiry":
            errors.append(f"Product {row.get('SKU')} does not disable online checkout")
        if row.get("Meta: _xiujin_moq") or row.get("Meta: _xiujin_lead_time"):
            errors.append(f"Product {row.get('SKU')} has unconfirmed MOQ/lead time")
        attribute_values = row.get("Attribute 1 value(s)", "")
        if any(identifier in attribute_values for identifier in config_ids):
            errors.append(f"Product {row.get('SKU')} exposes internal configuration IDs")

    expected_hashes = {
        row["media_library_filename"]: row["output_sha256"].lower() for row in media
    }
    for filename, expected_hash in expected_hashes.items():
        path = images_dir / filename
        if not path.is_file():
            errors.append(f"Missing extracted image: {filename}")
        elif sha256_file(path) != expected_hash:
            errors.append(f"Extracted image hash mismatch: {filename}")

    actual_files = sorted(path.name for path in images_dir.iterdir() if path.is_file())
    if actual_files != sorted(expected_hashes):
        errors.append("Product image directory has missing or stale files")

    media_by_sku: dict[str, list[dict]] = defaultdict(list)
    for row in media:
        media_by_sku[row["parent_sku"]].append(row)
        if not row.get("alt_text"):
            errors.append(f"Media {row.get('media_library_filename')} has no ALT text")
        if row.get("role") not in {"primary", "gallery", "dimensions"}:
            errors.append(f"Media {row.get('media_library_filename')} has an invalid role")
    product_image_union: list[str] = []
    for row in products:
        mapped = sorted(media_by_sku[row["SKU"]], key=lambda item: int(item["media_order"]))
        expected = [item["media_library_filename"] for item in mapped]
        actual = [value.strip() for value in row["Images"].split(",") if value.strip()]
        if actual != expected:
            errors.append(f"Product {row['SKU']} image order does not match media mapping")
        if mapped and mapped[0]["role"] != "primary":
            errors.append(f"Product {row['SKU']} has no primary first image")
        product_image_union.extend(actual)
    if len(product_image_union) != EXPECTED_MEDIA_COUNT or set(product_image_union) != set(expected_hashes):
        errors.append("Product image cells do not cover all 118 media files exactly once")

    by_source = {row["source_image_file"]: row for row in media}
    for rotated_source in ("12_image13.jpeg", "13_image14.jpeg"):
        rotated = by_source.get(rotated_source)
        if not rotated or rotated.get("transformation") != "rotate_90_clockwise":
            errors.append(f"Sideways 8021 source was not corrected: {rotated_source}")
        elif (
            rotated["source_width_px"] != rotated["output_height_px"]
            or rotated["source_height_px"] != rotated["output_width_px"]
        ):
            errors.append(f"Rotated output dimensions are wrong: {rotated_source}")
    duplicate = by_source.get("96_image93.jpeg")
    if not duplicate or duplicate.get("duplicate_source_of") != "92_image93.jpeg":
        errors.append("Known duplicate source image provenance is not recorded")
    product_8031 = next((row for row in products if row["SKU"] == "XJ-8031"), None)
    if not product_8031 or not product_8031["Images"].startswith(
        by_source["15_image16.jpeg"]["media_library_filename"]
    ):
        errors.append("XJ-8031 does not use 15_image16.jpeg as its primary image")

    corrected = next(
        (row for row in configurations if row["configuration_id"] == "S12-R111-V02"),
        None,
    )
    if not corrected or corrected["visual_description"] != "Gray mesh chair with light frame":
        errors.append("S12-R111-V02 still has the incorrect visual description")

    source_rows = {int(product["source_row"]) for product in source_products}
    mapped_rows = {int(row["source_start_row"]) for row in configurations}
    if source_rows != mapped_rows:
        errors.append("Source catalog rows and configuration source rows do not match")

    category_counts = dict(sorted(Counter(row["parent_category"] for row in configurations).items()))
    product_category_counts = dict(sorted(Counter(product["category"] for product in source_products).items()))
    report = {
        "status": "pass" if not errors else "fail",
        "errors": errors,
        "checks": {
            "product_count": len(products),
            "configuration_count": len(configurations),
            "image_count": len(expected_hashes),
            "media_alt_text_count": sum(bool(row.get("alt_text")) for row in media),
            "rotated_8021_images": sum(
                row.get("transformation") == "rotate_90_clockwise" for row in media
            ),
            "duplicate_source_records": sum(
                bool(row.get("duplicate_source_of")) for row in media
            ),
            "products_in_enquiry_checkout_mode": sum(
                row.get("Meta: _xiujin_checkout_mode") == "enquiry" for row in products
            ),
            "unique_product_skus": len(set(skus)),
            "unique_configuration_ids": len(set(config_ids)),
            "draft_products": sum(row.get("Published") == "-1" for row in products),
            "products_with_blank_price": sum(
                not row.get("Regular price") and not row.get("Sale price") for row in products
            ),
            "products_with_blank_inventory": sum(
                not row.get("In stock?") and not row.get("Stock") for row in products
            ),
            "product_category_counts": product_category_counts,
            "configuration_category_counts": category_counts,
            "verified_visual_descriptions_corrected": sum(
                row["configuration_id"] in VISUAL_DESCRIPTION_CORRECTIONS
                for row in configurations
            ),
        },
    }
    if errors:
        raise BuildError("Output validation failed: " + "; ".join(errors))
    return report


def build(args: argparse.Namespace) -> dict:
    catalog_payload, products = load_catalog(args.catalog)
    source_configurations = load_configurations(args.configurations)
    source_media = load_media_manifest(args.media_manifest)
    grouped = group_configurations(source_configurations)

    product_source_rows = {int(product["source_row"]) for product in products}
    configuration_source_rows = set(grouped)
    if product_source_rows != configuration_source_rows:
        missing = sorted(product_source_rows - configuration_source_rows)
        extra = sorted(configuration_source_rows - product_source_rows)
        raise BuildError(f"Product/configuration group mismatch; missing={missing}, extra={extra}")

    args.output.mkdir(parents=True, exist_ok=True)
    images_dir = args.output / "product-images"
    extract_and_verify_images(
        args.images, source_configurations, images_dir
    )
    media_rows, media_by_product = build_complete_media_library(
        source_media, source_configurations, products, images_dir
    )
    media_by_source = {row["source_image_file"]: row for row in media_rows}

    product_rows = []
    configuration_rows = []
    for position, product in enumerate(products, start=1):
        source_row = int(product["source_row"])
        configurations = grouped[source_row]
        product_rows.append(
            product_row(product, position, configurations, media_by_product[source_row])
        )
        configuration_rows.extend(
            configuration_row(
                product, source, media_by_source[source["source_image_file"]]
            )
            for source in configurations
        )

    product_csv = args.output / "XIUJIN-WooCommerce-products-DRAFT.csv"
    configuration_csv = args.output / "XIUJIN-WooCommerce-58-configurations.csv"
    media_csv = args.output / "XIUJIN-WooCommerce-media-library.csv"
    write_csv(product_csv, PRODUCT_COLUMNS, product_rows)
    write_csv(configuration_csv, CONFIGURATION_COLUMNS, configuration_rows)
    write_csv(media_csv, MEDIA_COLUMNS, media_rows)
    write_readme(args.output / "README-导入说明.md")

    manifest = {
        "schema_version": 2,
        "policy": (
            "Draft catalog only. Prices, currency, tax status and inventory are intentionally blank; "
            "visual configurations are media references until commercial details are confirmed. "
            "Wholesale and retail are handled by enquiry without online checkout or payment."
        ),
        "sources": {
            "catalog": {"file": args.catalog.name, "sha256": sha256_file(args.catalog)},
            "configuration_csv": {
                "file": args.configurations.name,
                "sha256": sha256_file(args.configurations),
            },
            "image_archive": {
                "file": args.images.name,
                "sha256": sha256_file(args.images),
            },
            "source_media_manifest": {
                "file": args.media_manifest.name,
                "sha256": sha256_file(args.media_manifest),
            },
            "catalog_schema_version": catalog_payload.get("schema_version"),
        },
        "counts": {
            "parent_catalog_products": len(product_rows),
            "visual_configurations": len(configuration_rows),
            "product_images": len(media_rows),
            "images_with_alt_text": sum(bool(row["alt_text"]) for row in media_rows),
            "rotated_display_corrections": sum(
                row["transformation"] != "none" for row in media_rows
            ),
            "duplicate_source_records": sum(
                bool(row["duplicate_source_of"]) for row in media_rows
            ),
        },
        "outputs": {
            "product_csv": product_csv.name,
            "configuration_csv": configuration_csv.name,
            "media_csv": media_csv.name,
            "images_directory": images_dir.name,
        },
        "images": media_rows,
    }
    (args.output / "import-manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    report = validate_outputs(
        product_csv, configuration_csv, media_csv, images_dir, products
    )
    report["files"] = {
        "product_csv": {
            "path": product_csv.name,
            "sha256": sha256_file(product_csv),
        },
        "configuration_csv": {
            "path": configuration_csv.name,
            "sha256": sha256_file(configuration_csv),
        },
        "media_csv": {
            "path": media_csv.name,
            "sha256": sha256_file(media_csv),
        },
    }
    (args.output / "validation-report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return report


def main() -> int:
    args = parse_args()
    try:
        report = build(args)
    except (BuildError, OSError, ValueError, json.JSONDecodeError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    checks = report["checks"]
    print(
        "PASS: "
        f"{checks['product_count']} draft products, "
        f"{checks['configuration_count']} configurations and "
        f"{checks['image_count']} verified images written to {args.output}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
