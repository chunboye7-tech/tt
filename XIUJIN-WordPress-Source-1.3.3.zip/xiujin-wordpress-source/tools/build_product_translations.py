#!/usr/bin/env python3
"""Build reviewed ES/PT product-copy reference files for the XIUJIN catalog.

The output deliberately contains copy only. Polylang/WPML must create and link
the translated WooCommerce products; importing these rows alone does not build
translation relationships.
"""

from __future__ import annotations

import csv
import hashlib
import html
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "inputs" / "chair-trade-studio" / "catalog_copy.json"
ENGLISH_PRODUCTS = ROOT / "dist" / "woocommerce-import" / "XIUJIN-WooCommerce-products-DRAFT.csv"
OUTPUT = ROOT / "dist" / "woocommerce-import"
EXPECTED = 18

FIELDS = [
    "locale",
    "language_name",
    "SKU",
    "source_handle",
    "source_row",
    "localized_slug",
    "localized_title",
    "localized_short_description",
    "localized_description_html",
    "localized_seo_title",
    "localized_seo_description",
    "localized_tags",
    "translation_status",
]


TITLES = {
    "es_ES": [
        "Silla gaming reclinable 135°",
        "Silla gaming reclinable con estructura de acero modelo 8021",
        "Silla gaming reclinable de malla modelo 8031",
        "Silla gaming reclinable 180° modelo 8051",
        "Silla de oficina de malla con brazos fijos y respaldo en aro",
        "Silla operativa de malla con estructura en A y brazos fijos",
        "Silla de oficina de malla reforzada modelo 110",
        "Silla gaming ajustable con balanceo modelo 8061",
        "Silla de oficina giratoria de malla con brazos fijos",
        "Silla operativa de malla regulable en altura",
        "Silla de oficina de malla con reposacabezas",
        "Silla de oficina de malla reclinable con opciones de reposapiés",
        "Silla ejecutiva reclinable con brazos 3D",
        "Silla ejecutiva de oficina acolchada y reclinable",
        "Silla ejecutiva reclinable de respaldo alto",
        "Silla de oficina reclinable con brazos acolchados",
        "Silla ejecutiva reclinable regulable en altura",
        "Silla de escritorio giratoria y reclinable de malla",
    ],
    "pt_BR": [
        "Cadeira gamer reclinável 135°",
        "Cadeira gamer reclinável com estrutura de aço modelo 8021",
        "Cadeira gamer reclinável em tela modelo 8031",
        "Cadeira gamer reclinável 180° modelo 8051",
        "Cadeira de escritório em tela com braços fixos e encosto em aro",
        "Cadeira operativa em tela com estrutura em A e braços fixos",
        "Cadeira de escritório em tela reforçada modelo 110",
        "Cadeira gamer ajustável com balanço modelo 8061",
        "Cadeira de escritório giratória em tela com braços fixos",
        "Cadeira operativa em tela com altura ajustável",
        "Cadeira de escritório em tela com apoio de cabeça",
        "Cadeira de escritório reclinável em tela com opções de apoio para pés",
        "Cadeira executiva reclinável com braços 3D",
        "Cadeira executiva acolchoada e reclinável",
        "Cadeira executiva reclinável de encosto alto",
        "Cadeira de escritório reclinável com braços acolchoados",
        "Cadeira executiva reclinável com altura ajustável",
        "Cadeira de escritório giratória e reclinável em tela",
    ],
}


OVERVIEWS = {
    "es_ES": [
        "Serie de silla gaming configurable para consultas mayoristas y minoristas, con reclinación de 135 grados, regulación de altura y giro.",
        "El modelo 8021 combina asiento y respaldo acolchados con estructura de acero, reclinación de 135 grados, regulación de altura y giro.",
        "El modelo 8031 incorpora tapizado de malla a un perfil gaming, con reclinación de 135 grados, regulación de altura y giro.",
        "El modelo 8051 ofrece reclinación total de 180 grados, función de balanceo, regulación de altura y giro.",
        "Esta selección con respaldo en aro combina malla y polipropileno, asiento acolchado, brazos fijos, regulación de altura y giro.",
        "Esta selección operativa con estructura en A combina respaldo de malla y polipropileno, asiento acolchado, brazos fijos, regulación de altura y giro.",
        "El modelo 110 es una silla de oficina de malla cuyo catálogo identifica como reforzados el respaldo, el asiento, los brazos y las ruedas; además ofrece regulación de altura y giro.",
        "El modelo 8061 es una serie gaming ajustable con regulación de altura, giro, balanceo y brazos vinculados configurables.",
        "Esta selección de oficina combina respaldo de malla y polipropileno con asiento acolchado, brazos fijos, regulación de altura y giro.",
        "Esta selección operativa de malla ofrece respaldo de polipropileno, asiento acolchado, brazos fijos, regulación de altura y giro, con reposacabezas opcional.",
        "Esta selección de oficina de malla incluye reposacabezas, brazos fijos, regulación de altura y giro, con una versión sin reposacabezas disponible para cotización.",
        "Esta selección de oficina de malla reclinable combina regulación de altura y giro con brazos fijos y dos configuraciones de reposapiés disponibles para cotización.",
        "Esta selección ejecutiva combina respaldo reclinable, regulación de altura y giro con brazos 3D acolchados y estructura de acero en asiento y respaldo.",
        "Esta selección ejecutiva acolchada ofrece respaldo reclinable, regulación de altura y giro, con estructura de acero en asiento y respaldo.",
        "Esta selección ejecutiva de respaldo alto combina reclinación, regulación de altura y giro con brazos acolchados y estructura de acero.",
        "Esta selección de oficina combina respaldo reclinable, regulación de altura y giro con brazos acolchados y estructura de acero en asiento y respaldo.",
        "Esta selección ejecutiva combina respaldo reclinable, regulación de altura y giro con brazos acolchados y base de acero.",
        "Esta selección de escritorio de malla, mostrada en rosa, gris y beige cerca de la fila 171 del catálogo fuente, combina reclinación, regulación de altura y giro.",
    ],
    "pt_BR": [
        "Série de cadeira gamer configurável para consultas de atacado e varejo, com reclinação de 135 graus, ajuste de altura e giro.",
        "O modelo 8021 combina assento e encosto acolchoados com estrutura de aço, reclinação de 135 graus, ajuste de altura e giro.",
        "O modelo 8031 leva o revestimento em tela a um perfil gamer, com reclinação de 135 graus, ajuste de altura e giro.",
        "O modelo 8051 oferece reclinação total de 180 graus, função de balanço, ajuste de altura e giro.",
        "Esta seleção com encosto em aro combina tela e polipropileno, assento acolchoado, braços fixos, ajuste de altura e giro.",
        "Esta seleção operativa com estrutura em A combina encosto em tela e polipropileno, assento acolchoado, braços fixos, ajuste de altura e giro.",
        "O modelo 110 é uma cadeira de escritório em tela cujo catálogo identifica encosto, assento, braços e rodízios como reforçados; também oferece ajuste de altura e giro.",
        "O modelo 8061 é uma série gamer ajustável com ajuste de altura, giro, balanço e braços vinculados configuráveis.",
        "Esta seleção de escritório combina encosto em tela e polipropileno com assento acolchoado, braços fixos, ajuste de altura e giro.",
        "Esta seleção operativa em tela tem encosto de polipropileno, assento acolchoado, braços fixos, ajuste de altura e giro, com apoio de cabeça opcional.",
        "Esta seleção de escritório em tela inclui apoio de cabeça, braços fixos, ajuste de altura e giro, com uma versão sem apoio de cabeça disponível para cotação.",
        "Esta seleção de escritório reclinável em tela combina ajuste de altura e giro com braços fixos e duas configurações de apoio para pés disponíveis para cotação.",
        "Esta seleção executiva combina encosto reclinável, ajuste de altura e giro com braços 3D acolchoados e estrutura de aço no assento e no encosto.",
        "Esta seleção executiva acolchoada oferece encosto reclinável, ajuste de altura e giro, com estrutura de aço no assento e no encosto.",
        "Esta seleção executiva de encosto alto combina reclinação, ajuste de altura e giro com braços acolchoados e estrutura de aço.",
        "Esta seleção de escritório combina encosto reclinável, ajuste de altura e giro com braços acolchoados e estrutura de aço no assento e no encosto.",
        "Esta seleção executiva combina encosto reclinável, ajuste de altura e giro com braços acolchoados e base de aço.",
        "Esta seleção de escritório em tela, mostrada em rosa, cinza e bege perto da linha 171 do catálogo de origem, combina reclinação, ajuste de altura e giro.",
    ],
}


SEO_DESCRIPTIONS = {
    "es_ES": [
        "Silla gaming con reclinación 135°, regulación de altura, giro y brazos vinculados. Consulta tapizados y opciones con XIUJIN.",
        "Modelo 8021 con estructura de acero acolchada, reclinación 135°, regulación de altura y giro. Solicita opciones a XIUJIN.",
        "Modelo 8031 de malla con reclinación 135°, regulación de altura y giro. Consulta carcasa, base y reposapiés con XIUJIN.",
        "Modelo 8051 con reclinación 180°, balanceo, regulación de altura, giro y brazos 2D. Solicita opciones a XIUJIN.",
        "Silla de oficina de malla con brazos fijos, regulación de altura, giro y asiento acolchado. Consulta bastidor y base con XIUJIN.",
        "Silla operativa de malla con estructura en A, brazos fijos, regulación de altura y giro. Consulta opciones con XIUJIN.",
        "Modelo 110 con respaldo, asiento, brazos y ruedas reforzados, regulación de altura y giro. Solicita especificaciones a XIUJIN.",
        "Modelo 8061 con regulación de altura, giro, balanceo y brazos vinculados configurables. Consulta tapizados con XIUJIN.",
        "Silla de oficina de malla con brazos fijos, asiento acolchado, regulación de altura y giro. Consulta opciones con XIUJIN.",
        "Silla operativa de malla con regulación de altura, giro y brazos fijos. Consulta reposacabezas, base y balanceo con XIUJIN.",
        "Silla de oficina de malla con reposacabezas, brazos fijos, regulación de altura y giro. Consulta versiones con XIUJIN.",
        "Silla de oficina de malla reclinable con regulación de altura, giro, brazos fijos y opciones de reposapiés. Consulta a XIUJIN.",
        "Silla ejecutiva reclinable con brazos 3D acolchados, regulación de altura, giro y estructura de acero. Solicita opciones a XIUJIN.",
        "Silla ejecutiva acolchada con reclinación, regulación de altura, giro y base de acero. Consulta tapizados y funciones con XIUJIN.",
        "Silla ejecutiva de respaldo alto con reclinación, regulación de altura, giro y brazos acolchados. Consulta opciones con XIUJIN.",
        "Silla de oficina reclinable con brazos acolchados, regulación de altura, giro y estructura de acero. Solicita opciones a XIUJIN.",
        "Silla ejecutiva con reclinación, regulación de altura, giro, brazos acolchados y base de acero. Solicita opciones a XIUJIN.",
        "Silla de escritorio de malla con reclinación, regulación de altura y giro, mostrada en rosa, gris y beige. Consulta opciones con XIUJIN.",
    ],
    "pt_BR": [
        "Cadeira gamer com reclinação 135°, ajuste de altura, giro e braços vinculados. Consulte revestimentos e opções com a XIUJIN.",
        "Modelo 8021 com estrutura de aço acolchoada, reclinação 135°, ajuste de altura e giro. Solicite opções à XIUJIN.",
        "Modelo 8031 em tela com reclinação 135°, ajuste de altura e giro. Consulte concha, base e apoio para pés com a XIUJIN.",
        "Modelo 8051 com reclinação 180°, balanço, ajuste de altura, giro e braços 2D. Solicite opções à XIUJIN.",
        "Cadeira de escritório em tela com braços fixos, ajuste de altura, giro e assento acolchoado. Consulte estrutura e base com a XIUJIN.",
        "Cadeira operativa em tela com estrutura em A, braços fixos, ajuste de altura e giro. Consulte opções com a XIUJIN.",
        "Modelo 110 com encosto, assento, braços e rodízios reforçados, além de ajuste de altura e giro. Solicite especificações à XIUJIN.",
        "Modelo 8061 com ajuste de altura, giro, balanço e braços vinculados configuráveis. Consulte revestimentos com a XIUJIN.",
        "Cadeira de escritório em tela com braços fixos, assento acolchoado, ajuste de altura e giro. Consulte opções com a XIUJIN.",
        "Cadeira operativa em tela com ajuste de altura, giro e braços fixos. Consulte apoio de cabeça, base e balanço com a XIUJIN.",
        "Cadeira de escritório em tela com apoio de cabeça, braços fixos, ajuste de altura e giro. Consulte versões com a XIUJIN.",
        "Cadeira de escritório reclinável em tela com ajuste de altura, giro, braços fixos e opções de apoio para pés. Consulte a XIUJIN.",
        "Cadeira executiva reclinável com braços 3D acolchoados, ajuste de altura, giro e estrutura de aço. Solicite opções à XIUJIN.",
        "Cadeira executiva acolchoada com reclinação, ajuste de altura, giro e base de aço. Consulte revestimentos e funções com a XIUJIN.",
        "Cadeira executiva de encosto alto com reclinação, ajuste de altura, giro e braços acolchoados. Consulte opções com a XIUJIN.",
        "Cadeira de escritório reclinável com braços acolchoados, ajuste de altura, giro e estrutura de aço. Solicite opções à XIUJIN.",
        "Cadeira executiva com reclinação, ajuste de altura, giro, braços acolchoados e base de aço. Solicite opções à XIUJIN.",
        "Cadeira de escritório em tela com reclinação, ajuste de altura e giro, mostrada em rosa, cinza e bege. Consulte opções com a XIUJIN.",
    ],
}


LIST_TRANSLATIONS = {
    "es_ES": {
        "135-degree reclining function": "Función reclinable de 135 grados",
        "Seat-height adjustment and swivel": "Regulación de altura del asiento y giro",
        "Padded two-point linked armrests": "Brazos vinculados acolchados de dos puntos",
        "PVC or fine-weave fabric upholstery choices": "Opciones de tapizado en PVC o tejido de trama fina",
        "PVC upholstery listed in the source catalog": "Tapizado de PVC indicado en el catálogo fuente",
        "Mesh upholstery": "Tapizado de malla",
        "180-degree full-recline function": "Reclinación total de 180 grados",
        "Rocking function": "Función de balanceo",
        "Padded 2D armrests": "Brazos 2D acolchados",
        "PVC or PU upholstery choices": "Opciones de tapizado en PVC o PU",
        "Seat-height adjustment": "Regulación de altura del asiento",
        "Swivel seat": "Asiento giratorio",
        "Fixed armrests": "Brazos fijos",
        "Reinforced components as identified in the source catalog": "Componentes reforzados según el catálogo fuente",
        "Adjustable padded linked armrests": "Brazos vinculados, acolchados y ajustables",
        "Mesh, PVC or PU upholstery choices": "Opciones de tapizado en malla, PVC o PU",
        "Optional headrest": "Reposacabezas opcional",
        "Headrest configuration": "Configuración con reposacabezas",
        "Reclining function": "Función reclinable",
        "Padded 3D armrests": "Brazos 3D acolchados",
        "Padded armrests": "Brazos acolchados",
        "High-back profile": "Perfil de respaldo alto",
        "Pink, gray and beige configurations shown in the source catalog": "Configuraciones rosa, gris y beige mostradas en el catálogo fuente",
        "Backrest and seat use board, foam and metal components": "Respaldo y asiento con tablero, espuma y componentes metálicos",
        "100 mm travel, Class 1 gas lift listed in the source catalog": "Pistón de gas clase 1 con recorrido de 100 mm indicado en el catálogo fuente",
        "Nylon base with nylon casters listed as the standard configuration": "Base y ruedas de nailon indicadas como configuración estándar",
        "Steel-frame backrest and seat with virgin or recycled foam choices": "Respaldo y asiento con estructura de acero y opciones de espuma virgen o reciclada",
        "Polypropylene backrest": "Respaldo de polipropileno",
        "Board seat with recycled foam": "Asiento de tablero con espuma reciclada",
        "100 mm travel, Class 1 gas lift and Nylon base": "Pistón de gas clase 1 con recorrido de 100 mm y base de nailon",
        "Nylon casters": "Ruedas de nailon",
        "100 mm travel, Class 2 gas lift listed in the source catalog": "Pistón de gas clase 2 con recorrido de 100 mm indicado en el catálogo fuente",
        "Nylon base and nylon casters": "Base y ruedas de nailon",
        "Board seat with virgin or recycled foam choices": "Asiento de tablero con opciones de espuma virgen o reciclada",
        "100 mm travel, Class 1 gas lift": "Pistón de gas clase 1 con recorrido de 100 mm",
        "Steel base and nylon casters listed as the standard configuration": "Base de acero y ruedas de nailon indicadas como configuración estándar",
        "Reinforced polypropylene backrest as listed in the source catalog": "Respaldo reforzado de polipropileno según el catálogo fuente",
        "Board seat with recycled foam, also listed as reinforced": "Asiento de tablero con espuma reciclada, también indicado como reforzado",
        "Steel base and nylon casters": "Base de acero y ruedas de nailon",
        "Board backrest and seat with recycled foam": "Respaldo y asiento de tablero con espuma reciclada",
        "Two-point or four-point linked armrest configurations listed in the source catalog": "Configuraciones de brazos vinculados de dos o cuatro puntos indicadas en el catálogo fuente",
        "Nylon base": "Base de nailon",
        "Polypropylene base and nylon casters listed as the standard configuration": "Base de polipropileno y ruedas de nailon indicadas como configuración estándar",
        "Polypropylene base and nylon casters": "Base de polipropileno y ruedas de nailon",
        "Metal-frame backrest and seat with virgin or recycled foam choices": "Respaldo y asiento con estructura metálica y opciones de espuma virgen o reciclada",
        "Polypropylene base and nylon casters listed in the source catalog": "Base de polipropileno y ruedas de nailon indicadas en el catálogo fuente",
        "The exact armrest specification requires supplier confirmation": "La especificación exacta de los brazos requiere confirmación del proveedor",
        "Fine-weave fabric or PVC upholstery": "Tapizado de tejido de trama fina o PVC",
        "Steel base": "Base de acero",
        "Three-point armrest configuration": "Configuración de brazos de tres puntos",
        "Footrest": "Reposapiés",
        "Lighting, speaker or seven-point massage configurations": "Configuraciones con iluminación, altavoz o masaje de siete puntos",
        "Alternative gas-lift classes": "Clases alternativas de pistón de gas",
        "Alternative five-star base styles": "Estilos alternativos de base de cinco radios",
        "White shell": "Carcasa blanca",
        "PVC or PU upholstery": "Tapizado de PVC o PU",
        "Alternative 1D–4D armrest configurations": "Configuraciones alternativas de brazos 1D–4D",
        "White frame": "Bastidor blanco",
        "Rocking function": "Función de balanceo",
        "Headrest": "Reposacabezas",
        "Mesh, PVC or PU upholstery": "Tapizado de malla, PVC o PU",
        "Two-point or four-point linked armrest configuration": "Configuración de brazos vinculados de dos o cuatro puntos",
        "Final colors and component specification": "Colores finales y especificación de componentes",
        "Version without headrest": "Versión sin reposacabezas",
        "White color configuration": "Configuración en color blanco",
        "Standard footrest": "Reposapiés estándar",
        "Plastic footrest": "Reposapiés de plástico",
        "Speaker configuration": "Configuración con altavoz",
        "Seven-point massage configuration": "Configuración con masaje de siete puntos",
        "Color selection": "Selección de color",
        "Alternative five-star base": "Base alternativa de cinco radios",
        "Gravity casters": "Ruedas por gravedad",
    },
    "pt_BR": {
        "135-degree reclining function": "Função reclinável de 135 graus",
        "Seat-height adjustment and swivel": "Ajuste de altura do assento e giro",
        "Padded two-point linked armrests": "Braços vinculados acolchoados de dois pontos",
        "PVC or fine-weave fabric upholstery choices": "Opções de revestimento em PVC ou tecido de trama fina",
        "PVC upholstery listed in the source catalog": "Revestimento em PVC indicado no catálogo de origem",
        "Mesh upholstery": "Revestimento em tela",
        "180-degree full-recline function": "Reclinação total de 180 graus",
        "Rocking function": "Função de balanço",
        "Padded 2D armrests": "Braços 2D acolchoados",
        "PVC or PU upholstery choices": "Opções de revestimento em PVC ou PU",
        "Seat-height adjustment": "Ajuste de altura do assento",
        "Swivel seat": "Assento giratório",
        "Fixed armrests": "Braços fixos",
        "Reinforced components as identified in the source catalog": "Componentes reforçados conforme o catálogo de origem",
        "Adjustable padded linked armrests": "Braços vinculados, acolchoados e ajustáveis",
        "Mesh, PVC or PU upholstery choices": "Opções de revestimento em tela, PVC ou PU",
        "Optional headrest": "Apoio de cabeça opcional",
        "Headrest configuration": "Configuração com apoio de cabeça",
        "Reclining function": "Função reclinável",
        "Padded 3D armrests": "Braços 3D acolchoados",
        "Padded armrests": "Braços acolchoados",
        "High-back profile": "Perfil de encosto alto",
        "Pink, gray and beige configurations shown in the source catalog": "Configurações rosa, cinza e bege mostradas no catálogo de origem",
        "Backrest and seat use board, foam and metal components": "Encosto e assento com placa, espuma e componentes metálicos",
        "100 mm travel, Class 1 gas lift listed in the source catalog": "Pistão a gás classe 1 com curso de 100 mm indicado no catálogo de origem",
        "Nylon base with nylon casters listed as the standard configuration": "Base e rodízios de náilon indicados como configuração padrão",
        "Steel-frame backrest and seat with virgin or recycled foam choices": "Encosto e assento com estrutura de aço e opções de espuma virgem ou reciclada",
        "Polypropylene backrest": "Encosto de polipropileno",
        "Board seat with recycled foam": "Assento de placa com espuma reciclada",
        "100 mm travel, Class 1 gas lift and Nylon base": "Pistão a gás classe 1 com curso de 100 mm e base de náilon",
        "Nylon casters": "Rodízios de náilon",
        "100 mm travel, Class 2 gas lift listed in the source catalog": "Pistão a gás classe 2 com curso de 100 mm indicado no catálogo de origem",
        "Nylon base and nylon casters": "Base e rodízios de náilon",
        "Board seat with virgin or recycled foam choices": "Assento de placa com opções de espuma virgem ou reciclada",
        "100 mm travel, Class 1 gas lift": "Pistão a gás classe 1 com curso de 100 mm",
        "Steel base and nylon casters listed as the standard configuration": "Base de aço e rodízios de náilon indicados como configuração padrão",
        "Reinforced polypropylene backrest as listed in the source catalog": "Encosto reforçado de polipropileno conforme o catálogo de origem",
        "Board seat with recycled foam, also listed as reinforced": "Assento de placa com espuma reciclada, também indicado como reforçado",
        "Steel base and nylon casters": "Base de aço e rodízios de náilon",
        "Board backrest and seat with recycled foam": "Encosto e assento de placa com espuma reciclada",
        "Two-point or four-point linked armrest configurations listed in the source catalog": "Configurações de braços vinculados de dois ou quatro pontos indicadas no catálogo de origem",
        "Nylon base": "Base de náilon",
        "Polypropylene base and nylon casters listed as the standard configuration": "Base de polipropileno e rodízios de náilon indicados como configuração padrão",
        "Polypropylene base and nylon casters": "Base de polipropileno e rodízios de náilon",
        "Metal-frame backrest and seat with virgin or recycled foam choices": "Encosto e assento com estrutura metálica e opções de espuma virgem ou reciclada",
        "Polypropylene base and nylon casters listed in the source catalog": "Base de polipropileno e rodízios de náilon indicados no catálogo de origem",
        "The exact armrest specification requires supplier confirmation": "A especificação exata dos braços requer confirmação do fornecedor",
        "Fine-weave fabric or PVC upholstery": "Revestimento em tecido de trama fina ou PVC",
        "Steel base": "Base de aço",
        "Three-point armrest configuration": "Configuração de braços de três pontos",
        "Footrest": "Apoio para pés",
        "Lighting, speaker or seven-point massage configurations": "Configurações com iluminação, alto-falante ou massagem de sete pontos",
        "Alternative gas-lift classes": "Classes alternativas de pistão a gás",
        "Alternative five-star base styles": "Estilos alternativos de base de cinco pontas",
        "White shell": "Concha branca",
        "PVC or PU upholstery": "Revestimento em PVC ou PU",
        "Alternative 1D–4D armrest configurations": "Configurações alternativas de braços 1D–4D",
        "White frame": "Estrutura branca",
        "Rocking function": "Função de balanço",
        "Headrest": "Apoio de cabeça",
        "Mesh, PVC or PU upholstery": "Revestimento em tela, PVC ou PU",
        "Two-point or four-point linked armrest configuration": "Configuração de braços vinculados de dois ou quatro pontos",
        "Final colors and component specification": "Cores finais e especificação dos componentes",
        "Version without headrest": "Versão sem apoio de cabeça",
        "White color configuration": "Configuração na cor branca",
        "Standard footrest": "Apoio para pés padrão",
        "Plastic footrest": "Apoio para pés de plástico",
        "Speaker configuration": "Configuração com alto-falante",
        "Seven-point massage configuration": "Configuração com massagem de sete pontos",
        "Color selection": "Seleção de cor",
        "Alternative five-star base": "Base alternativa de cinco pontas",
        "Gravity casters": "Rodízios por gravidade",
    },
}


TAG_TRANSLATIONS = {
    "es_ES": {
        "Feature": "Característica", "Material": "Material", "Construction": "Construcción", "Option": "Opción",
        "135° Recline": "Reclinación 135°", "180° Recline": "Reclinación 180°", "Height Adjustable": "Altura regulable",
        "Swivel": "Giratoria", "Linked Armrests": "Brazos vinculados", "Fabric Option": "Opción de tejido",
        "Steel Frame": "Estructura de acero", "Mesh": "Malla", "PP Backrest": "Respaldo de PP", "Rocking": "Balanceo",
        "2D Armrests": "Brazos 2D", "Fixed Armrests": "Brazos fijos", "Steel Base": "Base de acero",
        "Headrest": "Reposacabezas", "Reinforced Components": "Componentes reforzados", "Adjustable Armrests": "Brazos ajustables",
        "Multiple Upholstery Options": "Varias opciones de tapizado", "PP Base": "Base de PP", "Reclining": "Reclinable",
        "Footrest": "Reposapiés", "3D Armrests": "Brazos 3D", "Padded Armrests": "Brazos acolchados",
        "High Back": "Respaldo alto", "Metal Frame": "Estructura metálica", "Gravity Casters": "Ruedas por gravedad",
        "PVC": "PVC",
    },
    "pt_BR": {
        "Feature": "Característica", "Material": "Material", "Construction": "Construção", "Option": "Opção",
        "135° Recline": "Reclinação 135°", "180° Recline": "Reclinação 180°", "Height Adjustable": "Altura ajustável",
        "Swivel": "Giratória", "Linked Armrests": "Braços vinculados", "Fabric Option": "Opção de tecido",
        "Steel Frame": "Estrutura de aço", "Mesh": "Tela", "PP Backrest": "Encosto de PP", "Rocking": "Balanço",
        "2D Armrests": "Braços 2D", "Fixed Armrests": "Braços fixos", "Steel Base": "Base de aço",
        "Headrest": "Apoio de cabeça", "Reinforced Components": "Componentes reforçados", "Adjustable Armrests": "Braços ajustáveis",
        "Multiple Upholstery Options": "Várias opções de revestimento", "PP Base": "Base de PP", "Reclining": "Reclinável",
        "Footrest": "Apoio para pés", "3D Armrests": "Braços 3D", "Padded Armrests": "Braços acolchoados",
        "High Back": "Encosto alto", "Metal Frame": "Estrutura metálica", "Gravity Casters": "Rodízios por gravidade",
        "PVC": "PVC",
    },
}


LOCALE_META = {
    "es_ES": {
        "name": "Español",
        "slug": "es",
        "headings": ("Características del producto", "Construcción y componentes", "Opciones para cotización"),
        "closing": "Consultas mayoristas y minoristas: contacte con XIUJIN para confirmar la configuración elegida, disponibilidad, embalaje, pedido mínimo, plazo de entrega, moneda, impuestos, pago y condiciones de envío.",
    },
    "pt_BR": {
        "name": "Português (Brasil)",
        "slug": "pt-br",
        "headings": ("Destaques do produto", "Construção e componentes", "Opções para cotação"),
        "closing": "Consultas de atacado e varejo: entre em contato com a XIUJIN para confirmar a configuração escolhida, disponibilidade, embalagem, pedido mínimo, prazo de entrega, moeda, impostos, pagamento e condições de envio.",
    },
}


def slugify(value: str) -> str:
    normalized = value.casefold()
    normalized = re.sub(r"[^a-z0-9]+", "-", normalized).strip("-")
    return normalized


def translate_tags(tags: list[str], locale: str) -> list[str]:
    mapping = TAG_TRANSLATIONS[locale]
    translated = []
    for tag in tags:
        prefix, value = tag.split(": ", 1)
        if prefix not in mapping or value not in mapping:
            raise ValueError(f"Missing {locale} tag translation: {tag}")
        translated.append(f"{mapping[prefix]}: {mapping[value]}")
    return translated


def list_html(items: list[str]) -> str:
    return "<ul>" + "".join(f"<li>{html.escape(item)}</li>" for item in items) + "</ul>"


def description_html(product: dict, locale: str, overview: str) -> str:
    mapping = LIST_TRANSLATIONS[locale]
    headings = LOCALE_META[locale]["headings"]
    groups = []
    for key in ("highlights", "construction", "quote_options"):
        missing = [item for item in product[key] if item not in mapping]
        if missing:
            raise ValueError(f"Missing {locale} list translations: {missing}")
        groups.append([mapping[item] for item in product[key]])
    return "".join(
        [
            f"<p>{html.escape(overview)}</p>",
            f"<h2>{headings[0]}</h2>", list_html(groups[0]),
            f"<h2>{headings[1]}</h2>", list_html(groups[1]),
            f"<h2>{headings[2]}</h2>", list_html(groups[2]),
            f"<p><strong>{html.escape(LOCALE_META[locale]['closing'].split(':', 1)[0])}:</strong>{html.escape(LOCALE_META[locale]['closing'].split(':', 1)[1])}</p>",
        ]
    )


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build() -> dict:
    catalog = json.loads(CATALOG.read_text(encoding="utf-8"))["products"]
    english = read_csv(ENGLISH_PRODUCTS)
    if len(catalog) != EXPECTED or len(english) != EXPECTED:
        raise ValueError(f"Expected {EXPECTED} source products; got {len(catalog)} and {len(english)}")

    by_row = {int(row["Meta: _xiujin_source_row"]): row for row in english}
    if len(by_row) != EXPECTED:
        raise ValueError("English product rows are missing or duplicated")

    output_files = []
    validation = []
    for locale in ("es_ES", "pt_BR"):
        rows = []
        for index, product in enumerate(catalog):
            source_row = int(product["source_row"])
            source = by_row[source_row]
            title = TITLES[locale][index]
            overview = OVERVIEWS[locale][index]
            seo_description = SEO_DESCRIPTIONS[locale][index]
            localized_tags = translate_tags(product["feature_tags"], locale)
            html_description = description_html(product, locale, overview)
            localized_slug = f"{LOCALE_META[locale]['slug']}-{slugify(title)}"
            branded_seo_title = f"{title} | XIUJIN"
            seo_title = branded_seo_title if len(branded_seo_title) <= 70 else title
            rows.append(
                {
                    "locale": locale,
                    "language_name": LOCALE_META[locale]["name"],
                    "SKU": source["SKU"],
                    "source_handle": product["handle"],
                    "source_row": str(source_row),
                    "localized_slug": localized_slug,
                    "localized_title": title,
                    "localized_short_description": overview,
                    "localized_description_html": html_description,
                    "localized_seo_title": seo_title,
                    "localized_seo_description": seo_description,
                    "localized_tags": ", ".join(localized_tags),
                    "translation_status": "reviewed-reference-copy",
                }
            )

        output_path = OUTPUT / f"XIUJIN-product-copy-{locale}.csv"
        with output_path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=FIELDS, lineterminator="\n")
            writer.writeheader()
            writer.writerows(rows)
        output_files.append(output_path)

        unique_skus = len({row["SKU"] for row in rows})
        same_skus = {row["SKU"] for row in rows} == {row["SKU"] for row in english}
        html_ok = all(
            row["localized_description_html"].count("<h2>") == 3
            and row["localized_description_html"].count("<ul>") == 3
            and row["localized_description_html"].count("<li>")
            == source["Description"].count("<li>")
            for row, source in zip(rows, english, strict=True)
        )
        validation.append(
            {
                "locale": locale,
                "rows": len(rows),
                "unique_skus": unique_skus,
                "sku_set_matches_english": same_skus,
                "html_structure_matches": html_ok,
                "empty_customer_fields": sum(
                    not all(row[field].strip() for field in FIELDS if field not in {"source_row"})
                    for row in rows
                ),
                "seo_titles_over_70": sum(len(row["localized_seo_title"]) > 70 for row in rows),
                "seo_descriptions_over_160": sum(len(row["localized_seo_description"]) > 160 for row in rows),
            }
        )

    failed = [
        item for item in validation
        if item["rows"] != EXPECTED
        or item["unique_skus"] != EXPECTED
        or not item["sku_set_matches_english"]
        or not item["html_structure_matches"]
        or item["empty_customer_fields"]
        or item["seo_titles_over_70"]
        or item["seo_descriptions_over_160"]
    ]
    report = {
        "status": "pass" if not failed else "fail",
        "source_product_count": EXPECTED,
        "locales": validation,
        "files": [
            {"file": path.name, "bytes": path.stat().st_size, "sha256": sha256(path)}
            for path in output_files
        ],
        "note": "Reference copy only; a multilingual WordPress plugin must create and link translated products.",
    }
    report_path = OUTPUT / "XIUJIN-product-translations-validation.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if failed:
        raise ValueError(f"Translation bundle validation failed: {failed}")
    return report


def main() -> None:
    report = build()
    print(json.dumps({"status": report["status"], "locales": report["locales"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
