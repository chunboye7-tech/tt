#!/usr/bin/env python3
"""Build optimized theme media and the lazy-loaded 3D script."""

from pathlib import Path
import hashlib
import json
import os
import shutil
from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parents[1]
THEME = ROOT / 'theme' / 'xiujin-furniture'
TARGET = THEME / 'assets' / 'images'
SOURCE_ROOT = Path(os.environ.get('XIUJIN_SOURCE_ROOT', ROOT / 'inputs' / 'chair-trade-studio'))
SHOPIFY_ASSETS = SOURCE_ROOT / 'xiujin-b2b-theme' / 'assets'
HOME_IMAGES = SOURCE_ROOT / 'uploaded-home-images'
CATALOG_IMAGES = Path(os.environ.get('XIUJIN_CATALOG_REVIEW', ROOT / 'inputs' / 'catalog-review'))
FACTORY_MEDIA = ROOT / 'inputs' / 'factory-media'

COPY_ASSETS = [
    'chair-110.webp', 'chair-8011.webp', 'chair-8021.webp', 'chair-8031.webp',
    'chair-8051.webp', 'chair-8061.webp', 'chair-executive.webp', 'chair-mesh-a.webp',
    'chair-row42.webp', 'chair-row81.webp', 'chair-row91.webp', 'chair-row101.webp',
    'chair-row111.webp', 'chair-row131.webp', 'chair-row141.webp', 'chair-row151.webp',
    'chair-row161.webp', 'chair-row171.webp',
] + [f'home-main-{number}.webp' for number in range(1, 11)]

CONFIGURATIONS = {
    'config-black-ivory.webp': '1_image2.png',
    'config-red-rgb.webp': '0_image1.png',
    'config-blue-piping.webp': '3_image4.png',
    'config-yellow-black.webp': '4_image5.png',
    'config-red-bow.webp': '5_image6.png',
    'config-orange-fabric.webp': '6_image7.png',
}


def optimize(source: Path, destination: Path, size=(1000, 1400), quality=82):
    with Image.open(source) as image:
        image = ImageOps.exif_transpose(image)
        image.thumbnail(size, Image.Resampling.LANCZOS)
        if image.mode not in ('RGB', 'RGBA'):
            image = image.convert('RGBA' if 'A' in image.getbands() else 'RGB')
        image.save(destination, 'WEBP', quality=quality, method=6)


def optimize_factory_photo(source: Path, destination: Path):
    """Create a consistent 16:9 WebP without generative or cosmetic edits."""

    with Image.open(source) as image:
        image = ImageOps.exif_transpose(image).convert('RGB')
        image = ImageOps.fit(image, (1440, 810), Image.Resampling.LANCZOS)
        image.save(destination, 'WEBP', quality=78, method=6)


def build_hero():
    # Remove the baked English heading from the supplied square graphic so the
    # WordPress page can provide translatable, indexable HTML copy instead.
    source = HOME_IMAGES / 'main-9.png'
    with Image.open(source) as image:
        image = ImageOps.exif_transpose(image).convert('RGB')
        width, height = image.size
        top = round(height * 0.25)
        crop = image.crop((0, top, width, height))
        crop = crop.resize((1200, 900), Image.Resampling.LANCZOS)
        crop.save(TARGET / 'hero-chair-collection.webp', 'WEBP', quality=84, method=6)


def build_factory_media():
    """Build verified facility photos and footage and remove old AI visuals."""

    video_target = THEME / 'assets' / 'video'
    data_target = THEME / 'data'
    video_target.mkdir(parents=True, exist_ok=True)
    data_target.mkdir(parents=True, exist_ok=True)

    required = (
        FACTORY_MEDIA / 'factory-warehouse.mp4',
        FACTORY_MEDIA / 'factory-warehouse-poster.webp',
        FACTORY_MEDIA / 'factory-media.json',
    )
    for source in required:
        if not source.is_file():
            raise FileNotFoundError(source)

    manifest = json.loads(required[2].read_text(encoding='utf-8'))
    if manifest.get('source') != 'user_supplied_actual_facility_media':
        raise ValueError('Factory media manifest must identify user-supplied facility media')
    for media_type, source in (('video', required[0]), ('poster', required[1])):
        expected_name = manifest[media_type]['filename']
        expected_hash = manifest[media_type]['sha256']
        actual_hash = hashlib.sha256(source.read_bytes()).hexdigest()
        if source.name != expected_name or actual_hash != expected_hash:
            raise ValueError(f'Factory {media_type} does not match its provenance manifest')
    with Image.open(required[1]) as poster:
        expected_size = (manifest['poster']['width'], manifest['poster']['height'])
        if poster.size != expected_size:
            raise ValueError(f'Factory poster size {poster.size} does not match {expected_size}')

    photos = manifest.get('photos')
    if not isinstance(photos, list) or len(photos) != 4:
        raise ValueError('Factory media manifest must contain four verified photographs')
    for photo in photos:
        source = FACTORY_MEDIA / photo['source_filename']
        destination = TARGET / photo['filename']
        if not source.is_file():
            raise FileNotFoundError(source)
        source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
        if source_hash != photo['source_sha256']:
            raise ValueError(f'Factory photo source hash mismatch: {source.name}')
        optimize_factory_photo(source, destination)
        output_hash = hashlib.sha256(destination.read_bytes()).hexdigest()
        if output_hash != photo['sha256']:
            raise ValueError(f'Factory photo output hash mismatch: {destination.name}')
        with Image.open(destination) as image:
            expected_size = (int(photo['width']), int(photo['height']))
            if image.size != expected_size:
                raise ValueError(f'Factory photo size {image.size} does not match {expected_size}')

    shutil.copy2(required[0], video_target / required[0].name)
    shutil.copy2(required[1], TARGET / required[1].name)
    shutil.copy2(required[2], data_target / required[2].name)

    for obsolete in ('factory-assembly.webp', 'factory-quality.webp', 'factory-packing.webp'):
        (TARGET / obsolete).unlink(missing_ok=True)


def build_model_script():
    source = SHOPIFY_ASSETS / 'chair-model.js'
    code = source.read_text(encoding='utf-8')
    replacements = [
        ("preserveDrawingBuffer:true", "preserveDrawingBuffer:false"),
        (
            "let selected=0,theta=.46,phi=.10",
            "let selected=Math.max(0,Math.min(payload.variants.length-1,Number(select.value)||0)),theta=0,phi=.06",
        ),
        ("const scale=Math.min(window.devicePixelRatio||1,2)", "const scale=Math.min(window.devicePixelRatio||1,1.5)"),
        (
            "listen(canvas,'wheel',e=>{e.preventDefault();distance=Math.max(1.1,Math.min(4.8,distance*Math.exp(e.deltaY*.001)));schedule();},{passive:false});",
            "listen(canvas,'wheel',e=>{if(!(e.ctrlKey||e.metaKey))return;e.preventDefault();distance=Math.max(1.1,Math.min(4.8,distance*Math.exp(e.deltaY*.001)));schedule();},{passive:false});",
        ),
        (
            "for(const b of root.querySelectorAll('[data-angle]'))listen(b,'click',()=>{theta=Number(b.dataset.angle);phi=.06;schedule();});",
            "for(const b of root.querySelectorAll('[data-angle]'))listen(b,'click',()=>{theta=Number(b.dataset.angle);phi=.06;root.querySelectorAll('[data-angle]').forEach(button=>button.setAttribute('aria-pressed',String(button===b)));schedule();});",
        ),
        (
            "if(!gl){status.textContent=root.dataset.unavailableText||'3D preview is unavailable in this browser.';status.setAttribute('role','alert');return;}",
            "if(!gl){throw new Error(root.dataset.unavailableText||'3D preview is unavailable in this browser.');}",
        ),
    ]
    for old, new in replacements:
        if old not in code:
            raise RuntimeError(f'Expected model fragment not found: {old[:90]}')
        code = code.replace(old, new, 1)
    # The source renderer was embedded in a Shopify section. WordPress mounts
    # it explicitly after a click, so these platform listeners are dead code
    # and would create an unnecessary Shopify runtime marker.
    code = code.replace(
        "document.addEventListener('shopify:section:load',event=>mountAll(event.target));\n",
        "",
    ).replace(
        "document.addEventListener('shopify:section:unload',event=>unmountAll(event.target));\n",
        "",
    )
    (THEME / 'assets' / 'js' / 'chair-model.js').write_text(code, encoding='utf-8')


def main():
    TARGET.mkdir(parents=True, exist_ok=True)
    for name in COPY_ASSETS:
        source = SHOPIFY_ASSETS / name
        if not source.is_file():
            raise FileNotFoundError(source)
        shutil.copy2(source, TARGET / name)
    for target, source in CONFIGURATIONS.items():
        optimize(CATALOG_IMAGES / source, TARGET / target)
    build_hero()
    build_factory_media()
    build_model_script()
    print(f'Built {len(list(TARGET.glob("*.webp")))} WebP assets')
    print(f'3D script: {(THEME / "assets/js/chair-model.js").stat().st_size} bytes')


if __name__ == '__main__':
    main()
