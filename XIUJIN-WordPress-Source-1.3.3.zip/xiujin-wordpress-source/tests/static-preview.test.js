#!/usr/bin/env node
'use strict';

const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const { chromium } = require('playwright');

const projectRoot = path.resolve(__dirname, '..');
const previewRoot = path.resolve(process.argv[2] || path.join(projectRoot, 'preview'));
const artifactsRoot = path.resolve(process.argv[3] || path.join(projectRoot, 'tests', 'artifacts'));
const viewports = [
  { name: 'desktop-1440', width: 1440, height: 1000 },
  { name: 'tablet-768', width: 768, height: 1024 },
  { name: 'mobile-390', width: 390, height: 844 },
  { name: 'mobile-320', width: 320, height: 720 },
];

const results = [];
const expectedModelMappings = [
  { modelIndex: '0', variant: 'black-white' },
  { modelIndex: '1', variant: 'red-black-color-trim' },
  { modelIndex: '4', variant: 'blue-white' },
  { modelIndex: '5', variant: 'yellow-black' },
  { modelIndex: '2', variant: 'red-black' },
  { modelIndex: '3', variant: 'orange-black' },
];
const addResult = (viewport, check, pass, details = '') => {
  results.push({ viewport, check, pass: Boolean(pass), details: String(details || '') });
};

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webp': 'image/webp',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
};

const safeFile = (requestUrl) => {
  const pathname = decodeURIComponent(new URL(requestUrl, 'http://127.0.0.1').pathname);
  const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const resolved = path.resolve(previewRoot, relative);
  return resolved === previewRoot || resolved.startsWith(`${previewRoot}${path.sep}`) ? resolved : null;
};

const startServer = async () => {
  const index = path.join(previewRoot, 'index.html');
  await fsp.access(index, fs.constants.R_OK);
  const server = http.createServer(async (req, res) => {
    try {
      const file = safeFile(req.url || '/');
      if (!file) {
        res.writeHead(403).end('Forbidden');
        return;
      }
      const stat = await fsp.stat(file);
      const finalFile = stat.isDirectory() ? path.join(file, 'index.html') : file;
      const body = await fsp.readFile(finalFile);
      res.writeHead(200, {
        'Content-Type': mime[path.extname(finalFile).toLowerCase()] || 'application/octet-stream',
        'Cache-Control': 'no-store',
      });
      res.end(body);
    } catch (error) {
      res.writeHead(404).end('Not found');
    }
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  return { server, url: `http://127.0.0.1:${address.port}/` };
};

const scrollPage = async (page) => {
  await page.evaluate(async () => {
    const step = Math.max(300, Math.round(window.innerHeight * 0.58));
    for (let y = 0; y < document.documentElement.scrollHeight; y += step) {
      window.scrollTo({ top: y, behavior: 'instant' });
      await new Promise((resolve) => setTimeout(resolve, 90));
    }
    document.querySelectorAll('img[loading="lazy"]').forEach((image) => { image.loading = 'eager'; });
    await Promise.all([...document.images].map((image) => {
      if (image.complete) return Promise.resolve();
      return new Promise((resolve) => {
        const done = () => resolve();
        image.addEventListener('load', done, { once: true });
        image.addEventListener('error', done, { once: true });
        setTimeout(done, 3000);
      });
    }));
    window.scrollTo({ top: 0, behavior: 'instant' });
  });
  await page.waitForTimeout(350);
};

const assertStaticContent = async (page, name) => {
  const counts = await page.evaluate(() => ({
    products: document.querySelectorAll('.product-card').length,
    configurations: document.querySelectorAll('[data-config-choice]').length,
    showroom: document.querySelectorAll('.showroom-card').length,
    factoryPhotos: document.querySelectorAll('[data-factory-photo]').length,
    headerSocials: [...document.querySelectorAll('.header-social-link')].map((link) => link.getAttribute('aria-label')),
  }));
  addResult(name, '18 product cards', counts.products === 18, counts.products);
  addResult(name, '6 real configurations', counts.configurations === 6, counts.configurations);
  addResult(name, '10 showroom visuals', counts.showroom === 10, counts.showroom);
  addResult(name, '4 verified factory photographs', counts.factoryPhotos === 4, counts.factoryPhotos);
  addResult(
    name,
    '2 accessible header social icons',
    JSON.stringify(counts.headerSocials) === JSON.stringify(['Facebook', 'TikTok']),
    JSON.stringify(counts.headerSocials),
  );

  const visibleText = await page.locator('body').innerText();
  addResult(name, 'No visible 8011', !/(^|\D)8011(\D|$)/.test(visibleText), 'body.innerText');
  addResult(name, 'No visible Shopify copy', !/shopify/i.test(visibleText), 'body.innerText');

  const source = await page.content();
  addResult(name, 'No Shopify runtime/source', !/(cdn\.shopify\.com|myshopify\.com|Shopify\.theme|shopify-section)/i.test(source), 'HTML source');
};

const assertImagesAndLayout = async (page, name) => {
  await scrollPage(page);
  await page.waitForTimeout(400);
  const images = await page.evaluate(() => [...document.images].map((image) => ({
    src: image.currentSrc || image.src,
    complete: image.complete,
    width: image.naturalWidth,
    height: image.naturalHeight,
  })));
  const failed = images.filter((image) => !image.complete || image.width < 1 || image.height < 1);
  addResult(name, 'All images load', failed.length === 0, failed.map((item) => item.src).join(', '));

  const layout = await page.evaluate(() => {
    const root = document.documentElement;
    const body = document.body;
    const width = window.innerWidth;
    const offenders = [...document.querySelectorAll('body *')].filter((element) => {
      const style = getComputedStyle(element);
      if (style.display === 'none' || style.visibility === 'hidden' || style.position === 'fixed') return false;
      if (element.closest('[data-showroom-track], .configuration-options, .model-controls')) return false;
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && (rect.left < -2 || rect.right > width + 2);
    }).slice(0, 12).map((element) => ({
      selector: `${element.tagName.toLowerCase()}${element.id ? `#${element.id}` : ''}${element.classList.length ? `.${[...element.classList].slice(0, 3).join('.')}` : ''}`,
      left: Math.round(element.getBoundingClientRect().left),
      right: Math.round(element.getBoundingClientRect().right),
    }));
    return {
      clientWidth: root.clientWidth,
      rootScrollWidth: root.scrollWidth,
      bodyScrollWidth: body.scrollWidth,
      offenders,
    };
  });
  const noPageOverflow = layout.rootScrollWidth <= layout.clientWidth + 2 && layout.bodyScrollWidth <= layout.clientWidth + 2;
  addResult(name, 'No horizontal page overflow', noPageOverflow, JSON.stringify(layout));
};

const assertInteractions = async (page, name, viewport) => {
  const configButtons = page.locator('[data-config-choice]');
  if (await configButtons.count() >= 2) {
    const firstImage = page.locator('[data-config-image]');
    const oldSource = await firstImage.getAttribute('src');
    await configButtons.nth(1).click();
    await page.waitForTimeout(500);
    const state = {
      secondPressed: await configButtons.nth(1).getAttribute('aria-pressed'),
      source: await firstImage.getAttribute('src'),
      title: await page.locator('[data-config-title]').textContent(),
    };
    addResult(name, 'Configuration selector works', state.secondPressed === 'true' && state.source !== oldSource && Boolean(state.title.trim()), JSON.stringify(state));

    const modelSync = await page.evaluate(() => {
      const choices = [...document.querySelectorAll('[data-config-choice]')];
      const select = document.querySelector('[data-chair-model] select');
      return {
        mappings: choices.map((choice) => choice.dataset.modelIndex || ''),
        optionValues: select ? [...select.options].map((option) => option.value) : [],
        selectedValue: select?.value || '',
        activeModelIndex: choices.find((choice) => choice.getAttribute('aria-pressed') === 'true')?.dataset.modelIndex || '',
      };
    });
    const declaredMappings = expectedModelMappings.map((item) => item.modelIndex);
    addResult(
      name,
      'Six photo-to-3D mappings are declared',
      JSON.stringify(modelSync.mappings) === JSON.stringify(declaredMappings)
        && JSON.stringify(modelSync.optionValues) === JSON.stringify(['0', '1', '2', '3', '4', '5']),
      JSON.stringify(modelSync),
    );
    addResult(
      name,
      'Photo selection synchronizes the pending 3D variant',
      modelSync.selectedValue === modelSync.activeModelIndex && modelSync.selectedValue === '1',
      JSON.stringify(modelSync),
    );
  } else {
    addResult(name, 'Configuration selector works', false, 'selector missing');
  }

  const track = page.locator('[data-showroom-track]');
  const next = page.locator('[data-showroom-direction="1"]');
  if (await track.count() && await next.count()) {
    await track.evaluate((element) => { element.scrollLeft = 0; });
    await next.click();
    await page.waitForTimeout(650);
    const scrollLeft = await track.evaluate((element) => element.scrollLeft);
    addResult(name, 'Showroom carousel advances', scrollLeft > 10, scrollLeft);
  } else {
    addResult(name, 'Showroom carousel advances', false, 'controls missing');
  }

  const enquiry = page.locator('[data-enquiry-product]').first();
  const field = page.locator('[data-product-field]').first();
  if (await enquiry.count() && await field.count()) {
    const expected = await enquiry.getAttribute('data-enquiry-product');
    await enquiry.click();
    await page.waitForTimeout(120);
    addResult(name, 'Enquiry link pre-fills product', await field.inputValue() === expected, expected);
  } else {
    addResult(name, 'Enquiry link pre-fills product', false, 'link or field missing');
  }

  const factoryPhoto = page.locator('[data-factory-photo]').first();
  const factoryDialog = page.locator('[data-factory-lightbox]');
  if (await factoryPhoto.count() && await factoryDialog.count()) {
    await factoryPhoto.scrollIntoViewIfNeeded();
    const expectedTitle = await factoryPhoto.getAttribute('data-title');
    await factoryPhoto.click();
    const opened = await factoryDialog.evaluate((dialog) => dialog.open);
    const lightboxTitle = await factoryDialog.locator('[data-factory-lightbox-title]').textContent();
    const lightboxSource = await factoryDialog.locator('[data-factory-lightbox-image]').getAttribute('src');
    await page.keyboard.press('Escape');
    const closed = !(await factoryDialog.evaluate((dialog) => dialog.open));
    const focusRestored = await factoryPhoto.evaluate((link) => document.activeElement === link);
    addResult(
      name,
      'Factory photograph viewer opens, closes and restores focus',
      opened && closed && focusRestored && lightboxTitle?.trim() === expectedTitle && /factory-cnc-wood-components\.webp$/.test(lightboxSource || ''),
      JSON.stringify({ opened, closed, focusRestored, lightboxTitle, expectedTitle, lightboxSource }),
    );
  } else {
    addResult(name, 'Factory photograph viewer opens, closes and restores focus', false, 'gallery or dialog missing');
  }

  if (viewport.width <= 900) {
    const toggle = page.locator('[data-menu-toggle]');
    const menu = page.locator('#MobileNavigation');
    if (await toggle.count() && await menu.count()) {
      await toggle.click();
      const opened = await toggle.getAttribute('aria-expanded') === 'true' && !(await menu.getAttribute('hidden'));
      await page.keyboard.press('Escape');
      const closed = await toggle.getAttribute('aria-expanded') === 'false' && (await menu.getAttribute('hidden')) !== null;
      addResult(name, 'Mobile menu opens and closes', opened && closed, `opened=${opened}, closed=${closed}`);
    } else {
      addResult(name, 'Mobile menu opens and closes', false, 'menu controls missing');
    }
  }
};

const assertMotion = async (page, name) => {
  const motion = await page.evaluate(async () => {
    const reveal = document.querySelector('[data-reveal]');
    if (!reveal) return { root: false, reveal: false, transition: '' };
    reveal.scrollIntoView({ block: 'center', behavior: 'instant' });
    await new Promise((resolve) => setTimeout(resolve, 700));
    const style = getComputedStyle(reveal);
    return {
      root: document.documentElement.classList.contains('motion-enabled'),
      reveal: reveal.classList.contains('is-visible'),
      transition: style.transitionProperty,
    };
  });
  addResult(name, 'Reveal motion initializes', motion.root && motion.reveal && /opacity|transform/.test(motion.transition), JSON.stringify(motion));
};

const assertReducedMotion = async (browser, baseUrl) => {
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    reducedMotion: 'reduce',
  });
  const page = await context.newPage();
  await page.goto(baseUrl, { waitUntil: 'networkidle' });
  const state = await page.evaluate(() => {
    const reveal = document.querySelector('[data-reveal]');
    const style = reveal ? getComputedStyle(reveal) : null;
    const animated = [...document.getAnimations()].some((animation) => animation.playState === 'running');
    return {
      media: matchMedia('(prefers-reduced-motion: reduce)').matches,
      opacity: style?.opacity,
      transform: style?.transform,
      transitionDuration: style?.transitionDuration,
      animated,
    };
  });
  addResult('reduced-motion', 'Reduced motion preference honored', state.media && state.opacity === '1' && (state.transform === 'none' || state.transform === 'matrix(1, 0, 0, 1, 0, 0)') && !state.animated, JSON.stringify(state));
  await context.close();
};

const assert3DLoader = async (page, name) => {
  const button = page.locator('[data-model-load]').first();
  if (!(await button.count())) {
    addResult(name, '3D remains click-to-load', false, 'button missing');
    return;
  }
  const scriptsBefore = await page.locator('script[src*="chair-model"]').count();
  addResult(name, '3D script deferred before click', scriptsBefore === 0, scriptsBefore);
  await button.scrollIntoViewIfNeeded();
  await button.click();
  try {
    await page.waitForFunction(() => {
      const loader = document.querySelector('[data-model-loader]');
      return loader?.classList.contains('model-loader-ready') || loader?.classList.contains('model-loader-error');
    }, null, { timeout: 15000 });
  } catch (_) {}
  const outcome = await page.evaluate(() => {
    const loader = document.querySelector('[data-model-loader]');
    const root = loader?.querySelector('[data-chair-model]');
    return {
      ready: loader?.classList.contains('model-loader-ready'),
      error: loader?.classList.contains('model-loader-error'),
      scripts: document.querySelectorAll('script[src*="chair-model"]').length,
      status: loader?.querySelector('[data-status]')?.textContent?.trim() || '',
      variant: root?.dataset.variant || '',
      selectedValue: root?.querySelector('select')?.value || '',
    };
  });
  addResult(name, '3D loads only after user action', outcome.scripts === 1 && outcome.ready && !outcome.error, JSON.stringify(outcome));
  addResult(
    name,
    '3D starts on the photo selected before loading',
    outcome.variant === 'red-black-color-trim' && outcome.selectedValue === '1',
    JSON.stringify(outcome),
  );

  const mappingFailures = [];
  const choices = page.locator('[data-config-choice]');
  for (let index = 0; index < expectedModelMappings.length; index += 1) {
    const expected = expectedModelMappings[index];
    await choices.nth(index).click();
    try {
      await page.waitForFunction(
        ({ variant, modelIndex }) => {
          const root = document.querySelector('[data-chair-model]');
          const active = document.querySelector('[data-config-choice][aria-pressed="true"]');
          const select = root?.querySelector('select');
          const image = document.querySelector('[data-config-image]');
          return root?.dataset.variant === variant
            && select?.value === modelIndex
            && active?.dataset.modelIndex === modelIndex
            && image?.getAttribute('src') === active?.dataset.image;
        },
        expected,
        { timeout: 2500 },
      );
    } catch (_) {}
    const state = await page.evaluate(() => {
      const root = document.querySelector('[data-chair-model]');
      const active = document.querySelector('[data-config-choice][aria-pressed="true"]');
      const image = document.querySelector('[data-config-image]');
      return {
        variant: root?.dataset.variant || '',
        selectedValue: root?.querySelector('select')?.value || '',
        activeModelIndex: active?.dataset.modelIndex || '',
        activeImage: active?.dataset.image || '',
        displayedImage: image?.getAttribute('src') || '',
      };
    });
    if (
      state.variant !== expected.variant
      || state.selectedValue !== expected.modelIndex
      || state.activeModelIndex !== expected.modelIndex
      || state.activeImage !== state.displayedImage
    ) {
      mappingFailures.push({ index, expected, state });
    }
  }
  addResult(
    name,
    'All six photos select their matching 3D variants',
    mappingFailures.length === 0,
    JSON.stringify(mappingFailures),
  );
};

const writeReports = async () => {
  const failures = results.filter((result) => !result.pass);
  const summary = {
    previewRoot: 'preview',
    checks: results.length,
    passed: results.length - failures.length,
    failed: failures.length,
    results,
  };
  await fsp.mkdir(artifactsRoot, { recursive: true });
  await fsp.writeFile(path.join(artifactsRoot, 'browser-validation.json'), `${JSON.stringify(summary, null, 2)}\n`);
  const lines = [
    '# Static preview browser validation',
    '',
    `- Checks: ${summary.checks}`,
    `- Passed: ${summary.passed}`,
    `- Failed: ${summary.failed}`,
    '',
    '| Viewport | Check | Result | Details |',
    '|---|---|---:|---|',
    ...results.map((item) => `| ${item.viewport} | ${item.check} | ${item.pass ? 'PASS' : 'FAIL'} | ${item.details.replace(/\|/g, '\\|').replace(/\n/g, ' ')} |`),
    '',
  ];
  await fsp.writeFile(path.join(artifactsRoot, 'browser-validation.md'), lines.join('\n'));
  return summary;
};

(async () => {
  await fsp.mkdir(artifactsRoot, { recursive: true });
  const { server, url } = await startServer();
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium',
    args: ['--no-sandbox', '--disable-dev-shm-usage'],
  });
  try {
    for (const viewport of viewports) {
      const context = await browser.newContext({
        viewport: { width: viewport.width, height: viewport.height },
        deviceScaleFactor: 1,
      });
      const page = await context.newPage();
      const consoleErrors = [];
      const pageErrors = [];
      const failedRequests = [];
      const shopifyRequests = [];
      page.on('console', (message) => {
        if (message.type() === 'error') consoleErrors.push(message.text());
      });
      page.on('pageerror', (error) => pageErrors.push(error.message));
      page.on('requestfailed', (request) => failedRequests.push(`${request.url()} :: ${request.failure()?.errorText || 'failed'}`));
      page.on('request', (request) => {
        if (/shopify/i.test(request.url())) shopifyRequests.push(request.url());
      });

      const response = await page.goto(url, { waitUntil: 'networkidle' });
      addResult(viewport.name, 'Page responds successfully', response?.ok(), response?.status());
      await assertStaticContent(page, viewport.name);
      await assertImagesAndLayout(page, viewport.name);
      await assertInteractions(page, viewport.name, viewport);
      await assertMotion(page, viewport.name);
      if (viewport.name === 'desktop-1440') await assert3DLoader(page, viewport.name);
      await page.screenshot({
        path: path.join(artifactsRoot, `${viewport.name}.png`),
        fullPage: true,
      });
      addResult(viewport.name, 'No console errors', consoleErrors.length === 0, consoleErrors.join(' | '));
      addResult(viewport.name, 'No uncaught page errors', pageErrors.length === 0, pageErrors.join(' | '));
      addResult(viewport.name, 'No failed network requests', failedRequests.length === 0, failedRequests.join(' | '));
      addResult(viewport.name, 'No Shopify network requests', shopifyRequests.length === 0, shopifyRequests.join(' | '));
      await context.close();
    }
    await assertReducedMotion(browser, url);
  } finally {
    await browser.close();
    await new Promise((resolve) => server.close(resolve));
  }
  const summary = await writeReports();
  console.log(JSON.stringify({ checks: summary.checks, passed: summary.passed, failed: summary.failed }, null, 2));
  if (summary.failed) process.exitCode = 1;
})().catch(async (error) => {
  console.error(error.stack || error);
  process.exitCode = 1;
});
