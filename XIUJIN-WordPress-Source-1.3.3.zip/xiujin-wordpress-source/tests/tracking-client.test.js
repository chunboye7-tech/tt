#!/usr/bin/env node
'use strict';

const fs = require('fs');
const fsp = fs.promises;
const http = require('http');
const path = require('path');
const { chromium } = require('playwright');

const projectRoot = path.resolve(__dirname, '..');
const scriptPath = path.join(
  projectRoot,
  'plugin',
  'xiujin-store-core',
  'assets',
  'js',
  'tracking.js',
);
const reportPath = path.join(projectRoot, 'tests', 'artifacts', 'tracking-validation.json');
const eventId = '123e4567-e89b-42d3-a456-426614174000';
const piiMarkers = ['buyer@example.com', '+8613800138000', 'Private Buyer', 'Secret Company'];
const thirdPartyPattern = /(?:googletagmanager\.com|facebook\.net|tiktok\.com)/i;
const results = [];

const record = (check, pass, details = '') => {
  results.push({ check, pass: Boolean(pass), details: String(details || '') });
};

const platformConfig = {
  googleAdsId: 'AW-123456789',
  googleAdsLabel: 'Lead_Label-1',
  ga4Id: 'G-ABC12345',
  metaPixelId: '123456789012345',
  tiktokPixelId: 'C123456789ABCDEF',
};

const html = (configured, preexisting = false) => {
  const config = {
    platforms: configured ? platformConfig : {},
    consentKey: 'xiujin_tracking_test_consent',
    privacyUrl: '/privacy/',
    strings: {
      consentTitle: 'Privacy choices',
      consentDescription: 'Choose analytics and advertising services.',
      privacyLabel: 'Privacy policy',
      essentialLabel: 'Essential only',
      acceptLabel: 'Accept analytics and ads',
      settingsLabel: 'Privacy settings',
    },
    lead: configured ? {
      eventId,
      eventName: 'lead',
      queryKeys: ['xiujin_conversion'],
      // These unexpected fields prove the client never forwards form PII.
      email: piiMarkers[0],
      phone: piiMarkers[1],
      name: piiMarkers[2],
      company: piiMarkers[3],
    } : null,
  };
  const encoded = JSON.stringify(config).replace(/</g, '\\u003c');
  const existingVendors = preexisting ? `<script src="https://www.googletagmanager.com/gtag/js?id=G-EXISTING1"></script>
    <script src="https://connect.facebook.net/en_US/fbevents.js"></script>
    <script src="https://analytics.tiktok.com/i18n/pixel/events.js?sdkid=EXISTINGPIXEL1&lib=ttq"></script>
    <script>
      window.dataLayer = [];
      window.gtag = function gtag() { window.dataLayer.push(arguments); };
      const existingFbq = function fbq() { existingFbq.queue.push(arguments); };
      existingFbq.queue = [];
      window.fbq = existingFbq;
      window._fbq = existingFbq;
      const existingTtq = [];
      ['load', 'grantConsent', 'revokeConsent', 'page', 'track'].forEach((method) => {
        existingTtq[method] = function vendorStub() {
          existingTtq.push([method].concat(Array.from(arguments)));
        };
      });
      window.ttq = existingTtq;
    </script>` : '';
  return `<!doctype html><html><head><meta charset="utf-8"><title>Tracking test</title>${existingVendors}</head>
    <body><main>Test page</main><script>
      window.__leadEvents = [];
      document.addEventListener('xiujin:lead-tracked', (event) => window.__leadEvents.push(event.detail));
      window.xiujinTracking = ${encoded};
    </script><script src="/tracking.js"></script></body></html>`;
};

const startServer = async () => {
  const tracking = await fsp.readFile(scriptPath);
  const server = http.createServer((request, response) => {
    const url = new URL(request.url || '/', 'http://127.0.0.1');
    if (url.pathname === '/tracking.js') {
      response.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end(tracking);
      return;
    }
    if (url.pathname === '/privacy/') {
      response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      response.end('<!doctype html><title>Privacy</title>');
      return;
    }
    response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    response.end(html(url.searchParams.get('configured') === '1', url.searchParams.get('preexisting') === '1'));
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  return { server, origin: `http://127.0.0.1:${server.address().port}` };
};

const serializeCalls = async (page) => page.evaluate(() => {
  const list = (value) => Array.from(value || [], (entry) => Array.from(entry || []));
  return {
    dataLayer: list(window.dataLayer),
    meta: window.fbq && Array.isArray(window.fbq.queue) ? list(window.fbq.queue) : [],
    tiktok: Array.isArray(window.ttq) ? list(window.ttq) : [],
    leads: window.__leadEvents || [],
  };
});

const hasCall = (calls, name) => calls.some((entry) => entry[0] === 'event' && entry[1] === name);
const hasMetaCall = (calls, name) => calls.some((entry) => (
  (entry[0] === 'track' && entry[1] === name)
  || (entry[0] === 'trackSingle' && entry[2] === name)
));
const hasTikTokCall = (calls, name) => calls.some((entry) => entry[0] === 'track' && entry[1] === name);

(async () => {
  await fsp.mkdir(path.dirname(reportPath), { recursive: true });
  const { server, origin } = await startServer();
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium',
    args: ['--no-sandbox', '--disable-dev-shm-usage'],
  });

  try {
    // Empty settings are the release default and must initialize nothing.
    {
      const context = await browser.newContext();
      const page = await context.newPage();
      const requests = [];
      page.on('request', (request) => {
        if (thirdPartyPattern.test(request.url())) requests.push(request.url());
      });
      await page.goto(`${origin}/?configured=0`, { waitUntil: 'networkidle' });
      const state = await page.evaluate(() => ({
        banner: Boolean(document.querySelector('[data-xiujin-consent]')),
        settings: Boolean(document.querySelector('[data-xiujin-consent-settings]')),
        scripts: document.querySelectorAll('#xiujin-google-tag,#xiujin-meta-pixel,#xiujin-tiktok-pixel').length,
      }));
      record('Empty platform settings leave tracking disabled', !state.banner && !state.settings && state.scripts === 0 && requests.length === 0, JSON.stringify({ state, requests }));
      await context.close();
    }

    // A configured site must remain network-silent until an affirmative choice.
    {
      const context = await browser.newContext();
      const page = await context.newPage();
      const requests = [];
      await page.route('https://**/*', async (route) => {
        requests.push(route.request().url());
        await route.fulfill({ status: 200, contentType: 'text/javascript', body: '/* deterministic test stub */' });
      });
      await page.goto(`${origin}/?configured=1&xiujin_conversion=opaque-token`, { waitUntil: 'networkidle' });
      const before = await page.evaluate(() => ({
        bannerHidden: document.querySelector('[data-xiujin-consent]')?.hidden,
        role: document.querySelector('[data-xiujin-consent]')?.getAttribute('role'),
        labelled: Boolean(document.querySelector('[data-xiujin-consent]')?.getAttribute('aria-labelledby')),
        scripts: document.querySelectorAll('#xiujin-google-tag,#xiujin-meta-pixel,#xiujin-tiktok-pixel').length,
        query: window.location.search,
      }));
      record('Consent banner is accessible and strips the one-time URL marker', before.bannerHidden === false && before.role === 'region' && before.labelled && !before.query.includes('xiujin_conversion'), JSON.stringify(before));
      record('No vendor script or request occurs before consent', before.scripts === 0 && requests.length === 0, JSON.stringify(requests));

      await page.click('[data-xiujin-consent-essential]');
      await page.waitForTimeout(150);
      const essential = await page.evaluate(() => ({
        value: JSON.parse(localStorage.getItem('xiujin_tracking_test_consent') || '{}').value,
        scripts: document.querySelectorAll('#xiujin-google-tag,#xiujin-meta-pixel,#xiujin-tiktok-pixel').length,
      }));
      record('Essential-only choice keeps all vendors disabled', essential.value === 'essential' && essential.scripts === 0 && requests.length === 0, JSON.stringify({ essential, requests }));
      await context.close();
    }

    // Granting consent loads each configured vendor and records one verified lead.
    {
      const context = await browser.newContext();
      const page = await context.newPage();
      const requests = [];
      await page.route('https://**/*', async (route) => {
        requests.push(route.request().url());
        await route.fulfill({ status: 200, contentType: 'text/javascript', body: '/* deterministic test stub */' });
      });
      await page.goto(`${origin}/?configured=1&xiujin_conversion=opaque-token`, { waitUntil: 'networkidle' });
      await page.click('[data-xiujin-consent-accept]');
      await page.waitForTimeout(250);

      const calls = await serializeCalls(page);
      const loaded = await page.evaluate(() => ({
        google: Boolean(document.getElementById('xiujin-google-tag')),
        meta: Boolean(document.getElementById('xiujin-meta-pixel')),
        tiktok: Boolean(document.getElementById('xiujin-tiktok-pixel')),
      }));
      const domains = {
        google: requests.some((url) => /googletagmanager\.com/.test(url)),
        meta: requests.some((url) => /facebook\.net/.test(url)),
        tiktok: requests.some((url) => /tiktok\.com/.test(url)),
      };
      record('Affirmative consent loads all configured vendor scripts', Object.values(loaded).every(Boolean) && Object.values(domains).every(Boolean), JSON.stringify({ loaded, domains, requests }));
      record('Verified lead maps once to Google Ads and GA4', hasCall(calls.dataLayer, 'conversion') && hasCall(calls.dataLayer, 'generate_lead') && calls.leads.length === 1 && calls.leads[0].eventId === eventId, JSON.stringify(calls.dataLayer));
      record('Verified lead maps once to Meta and TikTok', hasMetaCall(calls.meta, 'Lead') && hasTikTokCall(calls.tiktok, 'SubmitForm'), JSON.stringify({ meta: calls.meta, tiktok: calls.tiktok }));

      const serialized = JSON.stringify({ requests, calls });
      record('Tracking requests and event payloads contain no enquiry PII', piiMarkers.every((marker) => !serialized.includes(marker)), serialized);

      // Changing the choice on the same page must update consent without
      // reinjecting vendor scripts or replaying page/lead events.
      await page.click('[data-xiujin-consent-settings]');
      await page.click('[data-xiujin-consent-essential]');
      await page.click('[data-xiujin-consent-settings]');
      await page.click('[data-xiujin-consent-accept]');
      await page.waitForTimeout(100);
      const changedCalls = await serializeCalls(page);
      const count = (list, predicate) => list.filter(predicate).length;
      const samePageState = {
        googleGrant: count(changedCalls.dataLayer, (entry) => entry[0] === 'consent' && entry[1] === 'update' && entry[2]?.ad_storage === 'granted'),
        googleDeny: count(changedCalls.dataLayer, (entry) => entry[0] === 'consent' && entry[1] === 'update' && entry[2]?.ad_storage === 'denied'),
        googlePage: count(changedCalls.dataLayer, (entry) => entry[0] === 'event' && entry[1] === 'page_view'),
        googleLead: count(changedCalls.dataLayer, (entry) => entry[0] === 'event' && ['conversion', 'generate_lead'].includes(entry[1])),
        metaGrant: count(changedCalls.meta, (entry) => entry[0] === 'consent' && entry[1] === 'grant'),
        metaRevoke: count(changedCalls.meta, (entry) => entry[0] === 'consent' && entry[1] === 'revoke'),
        metaPage: count(changedCalls.meta, (entry) => (entry[0] === 'track' && entry[1] === 'PageView') || (entry[0] === 'trackSingle' && entry[2] === 'PageView')),
        metaLead: count(changedCalls.meta, (entry) => (entry[0] === 'track' && entry[1] === 'Lead') || (entry[0] === 'trackSingle' && entry[2] === 'Lead')),
        tiktokGrant: count(changedCalls.tiktok, (entry) => entry[0] === 'grantConsent'),
        tiktokRevoke: count(changedCalls.tiktok, (entry) => entry[0] === 'revokeConsent'),
        tiktokPage: count(changedCalls.tiktok, (entry) => entry[0] === 'page'),
        tiktokLead: count(changedCalls.tiktok, (entry) => entry[0] === 'track' && entry[1] === 'SubmitForm'),
        scriptRequests: requests.length,
      };
      record(
        'Same-page revoke and regrant updates all vendors without duplicate page or lead events',
        samePageState.googleGrant === 2 && samePageState.googleDeny === 1
          && samePageState.googlePage === 1 && samePageState.googleLead === 2
          && samePageState.metaGrant === 2 && samePageState.metaRevoke === 1
          && samePageState.metaPage === 1 && samePageState.metaLead === 1
          && samePageState.tiktokGrant === 2 && samePageState.tiktokRevoke === 1
          && samePageState.tiktokPage === 1 && samePageState.tiktokLead === 1
          && samePageState.scriptRequests === 3,
        JSON.stringify(samePageState),
      );

      // Consent persists, but the event ID recorded in storage blocks a replay.
      const replay = await context.newPage();
      const replayRequests = [];
      await replay.route('https://**/*', async (route) => {
        replayRequests.push(route.request().url());
        await route.fulfill({ status: 200, contentType: 'text/javascript', body: '/* deterministic test stub */' });
      });
      await replay.goto(`${origin}/?configured=1&xiujin_conversion=opaque-token`, { waitUntil: 'networkidle' });
      await replay.waitForTimeout(150);
      const replayCalls = await serializeCalls(replay);
      record(
        'A stored event ID is not counted again after refresh/navigation',
        replayCalls.leads.length === 0
          && !hasCall(replayCalls.dataLayer, 'conversion')
          && !hasCall(replayCalls.dataLayer, 'generate_lead')
          && !hasMetaCall(replayCalls.meta, 'Lead')
          && !hasTikTokCall(replayCalls.tiktok, 'SubmitForm'),
        JSON.stringify(replayCalls),
      );
      await context.close();
    }

    // Browsers can block Web Storage, and malformed cookies can be introduced
    // by old consent tools. The client must keep working and dedupe in memory.
    {
      const context = await browser.newContext();
      const page = await context.newPage();
      const requests = [];
      const pageErrors = [];
      page.on('pageerror', (error) => pageErrors.push(String(error)));
      await page.route('https://**/*', async (route) => {
        requests.push(route.request().url());
        await route.fulfill({ status: 200, contentType: 'text/javascript', body: '/* deterministic test stub */' });
      });
      await page.goto(`${origin}/?configured=0`, { waitUntil: 'networkidle' });
      await page.evaluate(() => {
        document.cookie = 'xiujin_tracking_test_consent=%E0%A4%A; Path=/; SameSite=Lax';
      });
      await context.addInitScript(() => {
        Storage.prototype.getItem = function blockedGet() { throw new Error('Storage blocked'); };
        Storage.prototype.setItem = function blockedSet() { throw new Error('Storage blocked'); };
        Storage.prototype.removeItem = function blockedRemove() { throw new Error('Storage blocked'); };
      });
      await page.goto(`${origin}/?configured=1&xiujin_conversion=opaque-token`, { waitUntil: 'networkidle' });
      await page.click('[data-xiujin-consent-accept]');
      await page.click('[data-xiujin-consent-settings]');
      await page.click('[data-xiujin-consent-essential]');
      await page.click('[data-xiujin-consent-settings]');
      await page.click('[data-xiujin-consent-accept]');
      await page.waitForTimeout(100);
      const calls = await serializeCalls(page);
      const count = (list, predicate) => list.filter(predicate).length;
      const state = {
        googleLeadEvents: count(calls.dataLayer, (entry) => entry[0] === 'event' && ['conversion', 'generate_lead'].includes(entry[1])),
        metaLeads: count(calls.meta, (entry) => entry[0] === 'trackSingle' && entry[2] === 'Lead'),
        tiktokLeads: count(calls.tiktok, (entry) => entry[0] === 'track' && entry[1] === 'SubmitForm'),
        announcedLeads: calls.leads.length,
        scriptRequests: requests.length,
        errors: pageErrors,
      };
      record(
        'Blocked storage and a malformed consent cookie do not crash or replay a Lead',
        state.googleLeadEvents === 2 && state.metaLeads === 1 && state.tiktokLeads === 1
          && state.announcedLeads === 1 && state.scriptRequests === 3 && state.errors.length === 0,
        JSON.stringify(state),
      );
      await context.close();
    }

    // Coexist with Site Kit or another integration that has already installed
    // the same vendor globals/scripts. Our module may configure and emit events,
    // but it must not add a second vendor loader.
    {
      const context = await browser.newContext();
      const page = await context.newPage();
      const requests = [];
      await page.route('https://**/*', async (route) => {
        requests.push(route.request().url());
        await route.fulfill({ status: 200, contentType: 'text/javascript', body: '/* existing vendor stub */' });
      });
      await page.goto(`${origin}/?configured=1&preexisting=1`, { waitUntil: 'networkidle' });
      const baseline = requests.length;
      await page.click('[data-xiujin-consent-accept]');
      await page.waitForTimeout(150);
      const state = await page.evaluate(() => ({
        pluginScripts: document.querySelectorAll('#xiujin-google-tag,#xiujin-meta-pixel,#xiujin-tiktok-pixel').length,
        googleScripts: document.querySelectorAll('script[src*="googletagmanager.com/gtag/js"]').length,
        metaScripts: document.querySelectorAll('script[src*="connect.facebook.net"][src*="fbevents.js"]').length,
        tiktokScripts: document.querySelectorAll('script[src*="analytics.tiktok.com"][src*="events.js"]').length,
      }));
      record(
        'Existing vendor globals and loaders are reused without duplicate injection',
        baseline === 3 && requests.length === baseline && state.pluginScripts === 0
          && state.googleScripts === 1 && state.metaScripts === 1 && state.tiktokScripts === 1,
        JSON.stringify({ baseline, requests, state }),
      );
      await context.close();
    }
  } finally {
    await browser.close();
    await new Promise((resolve) => server.close(resolve));
  }

  const failures = results.filter((item) => !item.pass);
  const report = { checks: results.length, passed: results.length - failures.length, failed: failures.length, results };
  await fsp.writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`);
  results.forEach((item) => console.log(`[${item.pass ? 'PASS' : 'FAIL'}] ${item.check}${item.details ? `: ${item.details}` : ''}`));
  console.log(`\nTracking validation: ${report.passed} passed, ${report.failed} failed`);
  if (failures.length) process.exitCode = 1;
})().catch((error) => {
  console.error(error.stack || error);
  process.exitCode = 1;
});
