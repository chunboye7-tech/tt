# Static WordPress preview validation

Run from the project root after `preview/index.html` has been generated:

```bash
node tests/static-preview.test.js
```

The script serves the preview locally and validates it in Chromium at 1440, 768, 390 and 320 pixels. Reports and full-page screenshots are written to `tests/artifacts/`.

Run the consent-gated Google Ads, Meta Pixel and TikTok Pixel client checks with:

```bash
node tests/tracking-client.test.js
```

This deterministic browser test intercepts vendor scripts locally and verifies
that no third-party request occurs before consent, necessary-only consent keeps
all vendors disabled, affirmative consent loads each configured vendor, and a
verified enquiry emits one anonymous deduplicated Lead without personal data.
Its report is written to `tests/artifacts/tracking-validation.json` and is
required before a release can be packaged.
