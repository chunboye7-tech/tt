(() => {
  const init = (root = document) => {
    root.querySelectorAll('[data-menu-toggle]').forEach(button => {
      if (button.dataset.ready) return;
      button.dataset.ready = 'true';
      button.addEventListener('click', () => {
        const menu = document.getElementById(button.getAttribute('aria-controls'));
        if (!menu) return;
        const open = button.getAttribute('aria-expanded') === 'true';
        button.setAttribute('aria-expanded', String(!open));
        menu.hidden = open;
      });
    });
    root.querySelectorAll('[data-mobile-menu] a').forEach(link => {
      if (link.dataset.ready) return;
      link.dataset.ready = 'true';
      link.addEventListener('click', () => {
        const menu = link.closest('[data-mobile-menu]');
        menu.hidden = true;
        document.querySelectorAll('[data-menu-toggle]').forEach(button => button.setAttribute('aria-expanded', 'false'));
      });
    });
    root.querySelectorAll('[data-enquiry-product]').forEach(link => {
      if (link.dataset.ready) return;
      link.dataset.ready = 'true';
      link.addEventListener('click', () => {
        const form = document.querySelector('[data-quote-form]');
        const input = form?.querySelector('[data-product-field]');
        if (input) input.value = link.dataset.enquiryProduct;
      });
    });
    root.querySelectorAll('[data-gallery-thumbnail]').forEach(button => {
      if (button.dataset.ready) return;
      button.dataset.ready = 'true';
      button.addEventListener('click', () => {
        const gallery = button.closest('[data-gallery]');
        const main = gallery?.querySelector('[data-gallery-main]');
        if (!main) return;
        main.src = button.dataset.image;
        main.srcset = '';
        main.alt = button.dataset.alt || '';
        gallery.querySelectorAll('[data-gallery-thumbnail]').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
      });
    });
    if (document.body.dataset.preview === 'true') {
      root.querySelectorAll('[data-quote-form]').forEach(form => {
        if (form.dataset.ready) return;
        form.dataset.ready = 'true';
        form.addEventListener('submit', event => {
          event.preventDefault();
          const status = form.querySelector('[data-preview-status]');
          if (status) { status.hidden = false; status.focus(); }
        });
      });
    }
  };
  document.addEventListener('DOMContentLoaded', () => init());
  document.addEventListener('shopify:section:load', event => init(event.target));
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    const menu = document.querySelector('[data-mobile-menu]:not([hidden])');
    if (menu) {
      menu.hidden = true;
      const toggle = document.querySelector('[data-menu-toggle]');
      toggle?.setAttribute('aria-expanded', 'false');
      toggle?.focus();
    }
  });
})();
