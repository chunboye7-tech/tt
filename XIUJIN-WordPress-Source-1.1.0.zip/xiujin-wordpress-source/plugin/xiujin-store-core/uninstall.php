<?php
/**
 * Remove plugin-owned settings when the plugin is deleted.
 *
 * @package XiujinStoreCore
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Remove per-site plugin settings.
 *
 * Product sales metadata is intentionally retained because it is business
 * catalogue data and contains no enquiry personal data. Pseudonymous rate-limit
 * transients expire automatically no later than one hour after the most recent
 * counted submission attempt.
 */
function xiujin_store_core_delete_options() {
	delete_option( 'xiujin_inquiry_recipient_email' );
	delete_option( 'xiujin_enable_checkout' );
}

if ( is_multisite() ) {
	$site_ids = get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	);

	foreach ( $site_ids as $site_id ) {
		switch_to_blog( (int) $site_id );
		xiujin_store_core_delete_options();
		restore_current_blog();
	}
} else {
	xiujin_store_core_delete_options();
}

