=== XIUJIN Store Core ===
Contributors: xiujin
Tags: woocommerce, wholesale, retail, quotation, product enquiry
Requires at least: 6.4
Requires PHP: 8.1
Requires Plugins: woocommerce
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Keeps XIUJIN wholesale and retail product settings independent from the active theme and provides a secure quotation form.

== Description ==

XIUJIN Store Core adds sales mode, purchase path, minimum order quantity, lead time and internal configuration reference fields to WooCommerce products. The catalogue defaults to enquiry-only ordering for wholesale and retail, with cart and checkout disabled and no payment gateway required.

The `[xiujin_inquiry_form]` shortcode outputs an accessible, product-aware form protected by a nonce, honeypot, signed timing check, server-side validation and privacy-preserving rate limits. Valid enquiries are sent as plain-text email and are not stored in the WordPress database.

== Installation ==

1. Install and activate WooCommerce.
2. Upload and activate the XIUJIN Store Core ZIP.
3. Open Settings > XIUJIN enquiries and enter the sales recipient email.
4. Test email delivery before launch.
5. Leave online checkout disabled for an enquiry-only catalogue.
6. Edit each product, choose its sales mode, and keep its purchase path set to Quotation enquiry.

== Changelog ==

= 1.1.0 =
* Harden enquiry input handling, redirects, email headers and privacy disclosures.
* Keep quotation links on the active Polylang or WPML language homepage.
* Default wholesale and retail products to quotation-only ordering with cart and checkout routes disabled.
* Add global and per-product opt-in gates for any future online checkout.
* Add complete Spanish and Portuguese (Brazil) translations.

= 1.0.0 =
* Initial release.

