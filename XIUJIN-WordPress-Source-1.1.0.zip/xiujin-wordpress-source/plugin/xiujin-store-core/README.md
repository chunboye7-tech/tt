# XIUJIN Store Core

Companion plugin for the XIUJIN Furniture WordPress theme.

## Features

- Keeps wholesale/retail mode, purchase path, MOQ, lead time and internal configuration IDs outside the theme.
- Defaults the whole catalogue and every product to enquiry-only ordering, so no payment gateway is required.
- Disables cart and checkout routes until an administrator explicitly enables the global checkout gate and sets an individual product to the online-checkout purchase path.
- Adds the `[xiujin_inquiry_form]` shortcode.
- Protects enquiries with a WordPress nonce, honeypot, signed timing check, hourly rate limit, server-side validation and safe plain-text email headers.
- Sends no enquiry until the visitor explicitly submits the form and accepts the consent statement.
- Does not store enquiry contents in the WordPress database.

## Setup

1. Install and activate WooCommerce.
2. Upload and activate this plugin ZIP.
3. Go to **Settings → XIUJIN enquiries** and set the sales recipient.
4. Test outbound email delivery before launch. A transactional SMTP provider is recommended for production.
5. Keep **Enable WooCommerce cart and online checkout** off for the current enquiry-only site.
6. Edit each WooCommerce product and choose its sales mode. Keep **Purchase path** set to **Quotation enquiry**. Leave price empty when it is confirmed by quotation; never enter a placeholder zero price.

The shortcode can be placed on any page. Product links append a product ID so the homepage enquiry form is prefilled automatically.

The form marks its page as non-cacheable so visitors never receive an expired
WordPress nonce or signed timestamp. If the host or CDN ignores WordPress's
`DONOTCACHEPAGE` flag, exclude every page containing the shortcode from its
full-page cache. Static files can remain cached normally.

WooCommerce is used for catalogue and product management. A payment gateway is
not required for the default enquiry-only configuration. Online purchase can
only be enabled later with two deliberate controls: the global checkout setting
and the per-product **Online checkout** purchase path.

