# Static WordPress preview validation

Run from the project root after `preview/index.html` has been generated:

```bash
node tests/static-preview.test.js
```

The script serves the preview locally and validates it in Chromium at 1440, 768, 390 and 320 pixels. Reports and full-page screenshots are written to `tests/artifacts/`.
