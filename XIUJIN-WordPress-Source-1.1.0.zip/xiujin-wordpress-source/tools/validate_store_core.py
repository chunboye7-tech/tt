#!/usr/bin/env python3
"""Static release checks for the XIUJIN Store Core WordPress plugin."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1] / "plugin" / "xiujin-store-core"
REQUIRED = {
    "xiujin-store-core.php",
    "uninstall.php",
    "index.php",
    "includes/class-xiujin-product-fields.php",
    "includes/class-xiujin-inquiry.php",
    "assets/css/inquiry.css",
    "README.md",
}


def add(results: list[dict[str, str]], passed: bool, code: str, message: str) -> None:
    results.append({"status": "PASS" if passed else "FAIL", "code": code, "message": message})


def main() -> int:
    results: list[dict[str, str]] = []
    missing = sorted(name for name in REQUIRED if not (ROOT / name).is_file())
    add(results, not missing, "files.required", "All required files are present" if not missing else f"Missing: {', '.join(missing)}")

    php_files = sorted(ROOT.rglob("*.php"))
    php = "\n".join(path.read_text(encoding="utf-8") for path in php_files)
    main_file = (ROOT / "xiujin-store-core.php").read_text(encoding="utf-8")
    product = (ROOT / "includes/class-xiujin-product-fields.php").read_text(encoding="utf-8")
    inquiry = (ROOT / "includes/class-xiujin-inquiry.php").read_text(encoding="utf-8")
    uninstall = (ROOT / "uninstall.php").read_text(encoding="utf-8")

    headers = [
        "Plugin Name:       XIUJIN Store Core",
        "Version:           1.1.0",
        "Requires PHP:      8.1",
        "Requires Plugins:  woocommerce",
        "Text Domain:       xiujin-store-core",
        "Domain Path:       /languages",
    ]
    add(results, all(value in main_file for value in headers), "header.metadata", "Plugin metadata and text domain are declared")
    add(results, "example.com" not in php and "http://" not in php, "links.no-placeholder", "No placeholder or insecure URLs are present")

    meta_keys = ("_xiujin_sales_mode", "_xiujin_moq", "_xiujin_lead_time", "_xiujin_config_id", "_xiujin_checkout_mode")
    add(results, all(key in product for key in meta_keys), "products.meta", "All five durable WooCommerce business fields are implemented")
    sales_modes = ("'wholesale'", "'retail'", "'both'")
    add(results, all(mode in product for mode in sales_modes), "products.modes", "Wholesale, retail and combined sales modes are allowlisted")
    checkout_controls = (
        "woocommerce_is_purchasable" in product
        and "woocommerce_variation_is_purchasable" in product
        and "woocommerce_get_cart_url" in product
        and "woocommerce_get_checkout_url" in product
        and "redirect_disabled_commerce_routes" in product
    )
    add(results, checkout_controls, "products.checkout", "Global enquiry-only mode controls product purchase state and cart/checkout routes")
    add(results, "current_user_can( 'edit_post'" in product and "wp_verify_nonce" in product, "products.admin-security", "Product-field saves require capability and nonce checks")
    add(results, "has_scalar_post" in product and "is_string( $_POST[ $key ] )" in product, "products.input-shape", "Array-shaped product editor inputs are rejected before sanitation")
    add(results, "woocommerce_add_to_cart_validation" in product and "woocommerce_check_cart_items" in product, "products.cart-guard", "Enquiry-only products are blocked from direct cart requests and stale carts")
    add(results, "Request a current quotation" in product and "placeholder zero" not in product.lower(), "products.no-fake-price", "Quotation-only products do not invent a zero price")
    add(results, "if ( $moq && 'retail' !== $mode )" in product, "products.retail-moq", "Retail-only products do not display a wholesale MOQ")
    add(results, "xiujin_store_home_url()" in product, "products.localized-cta", "Quotation links retain the active multilingual homepage")
    product_checkout = (
        "get_option( self::OPTION_CHECKOUT, 'no' )" in product
        and "'online' === self::get_checkout_mode( $product )" in product
        and "return in_array( $mode, array( 'enquiry', 'online' ), true ) ? $mode : 'enquiry';" in product
    )
    add(results, product_checkout, "products.checkout-gates", "Checkout requires global opt-in and a product-level online path; missing values default to enquiry")

    security_tokens = (
        "wp_verify_nonce",
        "xiujin-inquiry-trap",
        "hash_equals",
        "hash_hmac",
        "get_transient",
        "set_transient",
        "sanitize_email",
        "sanitize_textarea_field",
        "wp_validate_redirect",
        "wp_safe_redirect",
    )
    add(results, all(token in inquiry for token in security_tokens), "inquiry.security", "Nonce, honeypot, timing, rate limit, sanitation and safe redirect controls are present")
    add(results, "post_scalar" in inquiry and "query_scalar" in inquiry and inquiry.count("is_string(") >= 2, "inquiry.input-shape", "Array-shaped form and query inputs are rejected before sanitation")
    add(results, "Content-Type: text/plain" in inquiry and "Reply-To: <" in inquiry and "sanitize_email" in inquiry, "inquiry.mail", "Enquiries use plain-text email and a validated address-only Reply-To header")
    add(results, "consent" in inquiry and "get_privacy_policy_url" in inquiry, "inquiry.consent", "Explicit consent and the configured privacy policy are included")
    add(results, "wp_add_privacy_policy_content" in inquiry and "Pseudonymous email-address" in inquiry, "inquiry.privacy-guide", "WordPress privacy guidance discloses email delivery and temporary pseudonymous rate-limit records")
    add(results, "source_page_url" in inquiry and "wp_parse_url" in inquiry and "query data" in inquiry, "inquiry.source-privacy", "Source-page mail context is same-origin and excludes query data")
    add(results, "nocache_headers" in inquiry and "wp_safe_redirect" in inquiry, "inquiry.redirect-cache", "Result redirects are same-site and marked non-cacheable")
    add(results, "DONOTCACHEPAGE" in inquiry, "inquiry.form-cache", "Pages rendering a live nonce form are marked non-cacheable")
    add(results, "preg_match( '/^[0-9]+$/D', $quantity_raw )" in inquiry, "inquiry.quantity", "Quantities must be unsigned decimal integers before conversion")
    add(results, "add_shortcode( 'xiujin_inquiry_form'" in inquiry, "inquiry.shortcode", "The documented enquiry shortcode is registered")
    add(results, "INSERT " not in php.upper() and "wp_insert_post" not in php and "$wpdb" not in php, "inquiry.no-persistence", "Enquiry contents are not written to the database")

    forbidden = ("eval(", "base64_decode(", "shell_exec(", "exec(", "passthru(", "system(")
    add(results, not any(token in php for token in forbidden), "code.no-dangerous-exec", "No dynamic or shell execution primitives are used")
    add(results, php.count("'xiujin-store-core'") >= 20 and "'xiujin'" not in php, "i18n.domain", "Front-end and admin copy consistently uses the plugin text domain")
    add(results, "pll_home_url" in main_file and "wpml_home_url" in main_file, "i18n.localized-home", "Polylang and WPML localized home URLs are supported")
    checkout_setting = (
        "Xiujin_Product_Fields::OPTION_CHECKOUT" in inquiry
        and "sanitize_checkout_setting" in inquiry
        and "get_option( Xiujin_Product_Fields::OPTION_CHECKOUT, 'no' )" in inquiry
    )
    add(results, checkout_setting, "settings.checkout-opt-in", "Admin settings expose an explicit, off-by-default global checkout gate")

    form_accessibility = (
        inquiry.count("<label for=") >= 8
        and inquiry.count(" required") >= 7
        and 'role="status" aria-live="polite"' in inquiry
        and 'autocomplete="email"' in inquiry
        and 'autocomplete="tel"' in inquiry
    )
    add(results, form_accessibility, "accessibility.form", "Form controls are labelled, required states are native, and result messages are announced")

    css_size = (ROOT / "assets/css/inquiry.css").stat().st_size
    add(results, css_size < 8_000, "performance.css", f"Form CSS is compact ({css_size} bytes)")
    css = (ROOT / "assets/css/inquiry.css").read_text(encoding="utf-8")
    add(results, "font-size:16px" in css, "mobile.input-size", "Form inputs use a mobile-safe 16px font size")
    add(results, not list(ROOT.rglob("*.js")), "performance.no-js", "The plugin adds no front-end JavaScript")

    uninstall_options = (
        "delete_option( 'xiujin_inquiry_recipient_email' )" in uninstall
        and "delete_option( 'xiujin_enable_checkout' )" in uninstall
    )
    add(results, uninstall_options, "uninstall.settings", "Plugin-owned recipient and checkout settings are deleted on uninstall")
    add(results, "is_multisite()" in uninstall and "switch_to_blog" in uninstall and "restore_current_blog" in uninstall, "uninstall.multisite", "Uninstall cleans recipient settings across a multisite network")

    language_dir = ROOT / "languages"
    translation_files = [
        language_dir / "xiujin-store-core.pot",
        language_dir / "xiujin-store-core-es_ES.po",
        language_dir / "xiujin-store-core-es_ES.mo",
        language_dir / "xiujin-store-core-pt_BR.po",
        language_dir / "xiujin-store-core-pt_BR.mo",
    ]
    add(results, all(path.is_file() and path.stat().st_size > 0 for path in translation_files), "i18n.catalogs", "POT and Spanish/Portuguese PO/MO catalogs are present")

    failures = sum(item["status"] == "FAIL" for item in results)
    for item in results:
        print(f"[{item['status']:4}] {item['code']}: {item['message']}")
    print(f"\nPlugin validation: {len(results) - failures} passed, {failures} failed")

    report_path = ROOT / "validation-report.json"
    report_path.write_text(
        json.dumps({"summary": {"passed": len(results) - failures, "failed": failures}, "checks": results}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())

