#!/usr/bin/env python3
"""Audit runtime gettext coverage for the XIUJIN theme and companion plugin."""

from __future__ import annotations

import ast
import importlib.util
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILDER_PATH = ROOT / "tools" / "build_i18n_catalogs.py"
REPORT_PATH = ROOT / "tests" / "artifacts" / "i18n-validation.json"

spec = importlib.util.spec_from_file_location("xiujin_i18n_builder", BUILDER_PATH)
if not spec or not spec.loader:
    raise RuntimeError("Could not load i18n builder")
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)


def parse_po(path: Path) -> tuple[dict[str, str], str]:
    entries: dict[str, str] = {}
    current: dict[str, str] = {}
    key = ""
    for line in path.read_text(encoding="utf-8").splitlines() + [""]:
        if line.startswith("msgid "):
            if "msgid" in current:
                entries[current["msgid"]] = current.get("msgstr", "")
            current = {"msgid": ast.literal_eval(line[6:])}
            key = "msgid"
        elif line.startswith("msgstr "):
            current["msgstr"] = ast.literal_eval(line[7:])
            key = "msgstr"
        elif line.startswith('"') and key:
            current[key] = current.get(key, "") + ast.literal_eval(line)
        elif not line.strip() and "msgid" in current:
            entries[current["msgid"]] = current.get("msgstr", "")
            current = {}
            key = ""
    return entries, entries.get("", "")


def result(check: str, passed: bool, detail: str) -> dict[str, object]:
    return {"check": check, "passed": passed, "detail": detail}


def main() -> None:
    checks: list[dict[str, object]] = []
    component_summary: dict[str, object] = {}
    locale_names = {"es_ES": "Spanish", "pt_BR": "Portuguese (Brazil)"}

    for component_name, component in builder.COMPONENTS.items():
        domain = component["domain"]
        output = component["output"]
        source = builder.extract_messages(component)
        source_ids = set(source)
        pot_path = output / f"{domain}.pot"
        pot, pot_header = parse_po(pot_path)
        pot_ids = set(pot) - {""}
        checks.append(
            result(
                f"{component_name}.pot_exact",
                source_ids == pot_ids,
                f"{len(source_ids)} source messages; {len(pot_ids)} POT messages",
            )
        )
        checks.append(
            result(
                f"{component_name}.pot_domain",
                f"X-Domain: {domain}\n" in pot_header,
                f"POT declares {domain}",
            )
        )

        locale_summary: dict[str, object] = {}
        for locale, language in locale_names.items():
            po_path = output / f"{domain}-{locale}.po"
            mo_path = output / f"{domain}-{locale}.mo"
            po, header = parse_po(po_path)
            po_ids = set(po) - {""}
            empty = sorted(msgid for msgid in po_ids if not po[msgid].strip())
            invalid: list[str] = []
            for msgid in sorted(po_ids):
                try:
                    builder.validate_translation(msgid, po[msgid], locale)
                except ValueError as error:
                    invalid.append(str(error))
            mo = builder.read_mo(mo_path)
            expected_mo = dict(po)
            exact = source_ids == po_ids and not empty and not invalid
            checks.extend(
                (
                    result(
                        f"{component_name}.{locale}.po_exact",
                        exact,
                        f"{len(po_ids)}/{len(source_ids)} translated; empty={len(empty)}; invalid={len(invalid)}",
                    ),
                    result(
                        f"{component_name}.{locale}.header",
                        f"Language: {locale}\n" in header
                        and f"X-Locale: {locale}\n" in header
                        and f"X-Domain: {domain}\n" in header,
                        f"Locale and domain headers for {language}",
                    ),
                    result(
                        f"{component_name}.{locale}.mo_roundtrip",
                        mo == expected_mo,
                        f"{len(mo) - 1} runtime MO messages",
                    ),
                )
            )
            locale_summary[locale] = {
                "language": language,
                "source_messages": len(source_ids),
                "translated_messages": len(po_ids) - len(empty),
                "coverage_percent": round(
                    100 * (len(po_ids) - len(empty)) / max(1, len(source_ids)), 2
                ),
                "placeholder_or_markup_errors": len(invalid),
                "mo_messages": len(mo) - 1,
            }
        component_summary[component_name] = {
            "text_domain": domain,
            "source_messages": len(source_ids),
            "locales": locale_summary,
        }

    theme_setup = (builder.THEME / "inc" / "setup.php").read_text(encoding="utf-8")
    plugin_boot = (builder.PLUGIN / "xiujin-store-core.php").read_text(encoding="utf-8")
    header = (builder.THEME / "header.php").read_text(encoding="utf-8")
    tags = (builder.THEME / "inc" / "template-tags.php").read_text(encoding="utf-8")
    seo = (builder.THEME / "inc" / "seo.php").read_text(encoding="utf-8")
    javascript = (builder.THEME / "assets" / "js" / "theme.js").read_text(encoding="utf-8")

    checks.extend(
        (
            result(
                "runtime.theme_domain_load",
                "load_theme_textdomain( 'xiujin'" in theme_setup,
                "Theme loads languages/ with the xiujin domain",
            ),
            result(
                "runtime.plugin_domain_load",
                "load_plugin_textdomain(" in plugin_boot
                and "'xiujin-store-core'" in plugin_boot
                and "'/languages'" in plugin_boot,
                "Plugin loads its Domain Path catalog",
            ),
            result(
                "runtime.document_language",
                "language_attributes()" in header,
                "HTML lang/dir values come from the active WordPress locale",
            ),
            result(
                "runtime.language_switcher",
                "pll_the_languages" in tags
                and "wpml_add_language_selector" in tags
                and "Language selection" in tags
                and "'hide_if_empty'" in tags
                and "'hide_if_no_translation'" in tags
                and "'force_home'" in tags,
                "Accessible Polylang and WPML switchers are present; Polylang keeps configured languages visible and safely falls back to their home pages",
            ),
            result(
                "runtime.javascript_strings",
                all(
                    item in theme_setup
                    for item in ("modelLoading", "modelError", "menuOpen", "menuClose")
                )
                and "window.xiujinTheme?.modelLoading" in javascript
                and "window.xiujinTheme?.menuOpen" in javascript,
                "Interactive status/menu copy is supplied through wp_localize_script",
            ),
            result(
                "seo.translated_description",
                "Explore XIUJIN factory-direct office and gaming chairs" in seo,
                "Fallback meta and Open Graph description uses gettext",
            ),
        )
    )

    failed = [item for item in checks if not item["passed"]]
    report = {
        "status": "passed" if not failed else "failed",
        "components": component_summary,
        "checks_passed": len(checks) - len(failed),
        "checks_total": len(checks),
        "checks": checks,
        "limitations": [
            "Gettext translates fixed theme/plugin interface copy.",
            "Product names, descriptions, pages, menus and media metadata are WordPress content and must be translated with Polylang or WPML/WooCommerce Multilingual.",
            "WooCommerce core strings are supplied by WooCommerce language packs.",
        ],
    }
    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
