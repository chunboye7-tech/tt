#!/usr/bin/env python3
"""Verify XIUJIN delivery ZIP safety, contents, hashes and reproducibility."""

from __future__ import annotations

import json
import stat
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

import package_release as release


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "tests" / "artifacts" / "release-validation.json"


def source_members(source: Path, root_name: str) -> dict[str, bytes]:
    members: dict[str, bytes] = {}
    for path in sorted(source.rglob("*")):
        relative = path.relative_to(source)
        if path.is_file() and not path.is_symlink() and release.wanted(relative):
            members[f"{root_name}/{relative.as_posix()}"] = path.read_bytes()
    return members


def unsafe_or_duplicate_members(archive: zipfile.ZipFile) -> tuple[list[str], list[str]]:
    unsafe: list[str] = []
    duplicates: list[str] = []
    seen: set[str] = set()
    for info in archive.infolist():
        pure = PurePosixPath(info.filename)
        mode = info.external_attr >> 16
        if (
            pure.is_absolute()
            or ".." in pure.parts
            or "\\" in info.filename
            or "\0" in info.filename
            or stat.S_ISLNK(mode)
        ):
            unsafe.append(info.filename)
        if info.filename in seen:
            duplicates.append(info.filename)
        seen.add(info.filename)
    return unsafe, duplicates


def main() -> int:
    delivery = release.DELIVERY
    names = release.release_names()
    expected = {
        names["theme"]: (
            "xiujin-furniture",
            release.THEME,
            {"xiujin-furniture/style.css", "xiujin-furniture/functions.php"},
        ),
        names["plugin"]: (
            "xiujin-store-core",
            release.PLUGIN,
            {"xiujin-store-core/xiujin-store-core.php", "xiujin-store-core/readme.txt"},
        ),
        names["import"]: (
            "XIUJIN-WooCommerce-Import",
            release.IMPORT,
            {
                "XIUJIN-WooCommerce-Import/XIUJIN-WooCommerce-products-DRAFT.csv",
                "XIUJIN-WooCommerce-Import/XIUJIN-WooCommerce-58-configurations.csv",
                "XIUJIN-WooCommerce-Import/XIUJIN-WooCommerce-media-library.csv",
                "XIUJIN-WooCommerce-Import/import-manifest.json",
                "XIUJIN-WooCommerce-Import/XIUJIN-product-copy-es_ES.csv",
                "XIUJIN-WooCommerce-Import/XIUJIN-product-copy-pt_BR.csv",
                "XIUJIN-WooCommerce-Import/XIUJIN-product-translations-validation.json",
            },
        ),
        names["preview"]: (
            "XIUJIN-WordPress-Preview",
            release.PREVIEW,
            {"XIUJIN-WordPress-Preview/index.html"},
        ),
    }
    source_name = names["source"]
    complete_name = names["complete"]
    checks: list[dict] = []

    def add(code: str, passed: bool, detail: str) -> None:
        checks.append({"check": code, "passed": bool(passed), "detail": detail})

    required_delivery = set(expected) | {
        source_name,
        complete_name,
        "START-HERE-中文.md",
        "HOSTINGER-INSTALL-中文.md",
        "RELEASE-NOTES-中文.md",
        "SHA256SUMS.txt",
        "release-manifest.json",
    }
    missing = sorted(name for name in required_delivery if not (delivery / name).is_file())
    add("delivery.files", not missing, "missing=" + ", ".join(missing) if missing else f"{len(required_delivery)} required files")
    if not missing:
        add(
            "delivery.install_guide",
            (delivery / "HOSTINGER-INSTALL-中文.md").read_text(encoding="utf-8") == release.rendered_install_guide(),
            "Hostinger guide uses the current package filenames",
        )

    for name, (root_name, source, required_members) in expected.items():
        archive_path = delivery / name
        if not archive_path.is_file():
            continue
        with zipfile.ZipFile(archive_path) as archive:
            corrupt = archive.testzip()
            names = set(archive.namelist())
            unsafe, duplicates = unsafe_or_duplicate_members(archive)
            add(f"{name}.crc", corrupt is None, corrupt or "all members passed CRC")
            add(f"{name}.safe_paths", not unsafe, ", ".join(unsafe) or "no traversal, absolute, backslash or symlink members")
            add(f"{name}.duplicates", not duplicates, ", ".join(duplicates) or "no duplicate members")
            bad_roots = [item for item in names if not item.startswith(root_name + "/")]
            add(f"{name}.root", not bad_roots, f"root={root_name}; members={len(names)}")
            add(f"{name}.required", required_members.issubset(names), f"required={len(required_members)}")

            expected_members = source_members(source, root_name)
            missing_members = sorted(set(expected_members) - names)
            extra_members = sorted(names - set(expected_members))
            mismatched = sorted(
                member
                for member, content in expected_members.items()
                if member in names and archive.read(member) != content
            )
            add(
                f"{name}.source_exact",
                not missing_members and not extra_members and not mismatched,
                f"source={len(expected_members)} missing={len(missing_members)} extra={len(extra_members)} mismatched={len(mismatched)}",
            )

    source_archive = delivery / source_name
    if source_archive.is_file():
        with zipfile.ZipFile(source_archive) as archive:
            corrupt = archive.testzip()
            unsafe, duplicates = unsafe_or_duplicate_members(archive)
            actual_names = set(archive.namelist())
            expected_source = {
                name: path.read_bytes()
                for name, path in release.source_bundle_files().items()
            }
            missing_members = sorted(set(expected_source) - actual_names)
            extra_members = sorted(actual_names - set(expected_source))
            mismatched = sorted(
                member
                for member, content in expected_source.items()
                if member in actual_names and archive.read(member) != content
            )
            add(f"{source_name}.crc", corrupt is None, corrupt or "all members passed CRC")
            add(f"{source_name}.safe_paths", not unsafe, ", ".join(unsafe) or "no unsafe members")
            add(f"{source_name}.duplicates", not duplicates, ", ".join(duplicates) or "no duplicate members")
            add(
                f"{source_name}.source_exact",
                not missing_members and not extra_members and not mismatched,
                f"source={len(expected_source)} missing={len(missing_members)} extra={len(extra_members)} mismatched={len(mismatched)}",
            )

    checksums = {}
    for line in (delivery / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        digest, filename = line.split(None, 1)
        checksums[filename.strip()] = digest
    checksum_failures = [
        name
        for name in [*expected, source_name]
        if checksums.get(name) != release.sha256(delivery / name)
    ]
    component_names = set(expected) | {source_name}
    add("checksums.components", not checksum_failures and set(checksums) == component_names, f"verified={len(checksums)} failures={len(checksum_failures)}")

    manifest = json.loads((delivery / "release-manifest.json").read_text(encoding="utf-8"))
    manifest_failures = []
    for name in [*expected, source_name, complete_name]:
        path = delivery / name
        record = manifest.get("files", {}).get(name, {})
        if record.get("bytes") != path.stat().st_size or record.get("sha256") != release.sha256(path):
            manifest_failures.append(name)
    add("manifest.files", not manifest_failures and manifest.get("version") == release.VERSION, f"verified={len(expected) + 2} failures={len(manifest_failures)}")
    verified_counts = manifest.get("verified_counts", {})
    add(
        "manifest.product_translations",
        verified_counts.get("product_translation_locales") == 2
        and verified_counts.get("translated_product_copy_rows") == 36,
        "expected=2 locales/36 rows; "
        f"actual={verified_counts.get('product_translation_locales')} locales/"
        f"{verified_counts.get('translated_product_copy_rows')} rows",
    )

    complete_path = delivery / complete_name
    with zipfile.ZipFile(complete_path) as complete:
        corrupt = complete.testzip()
        names = set(complete.namelist())
        required_complete = set(expected) | {
            source_name,
            "START-HERE-中文.md",
            "HOSTINGER-INSTALL-中文.md",
            "RELEASE-NOTES-中文.md",
            "SHA256SUMS.txt",
            "validation/theme-validation.json",
            "validation/browser-validation.json",
            "validation/browser-validation.md",
            "validation/i18n-validation.json",
            "validation/php-ast-validation.json",
            "validation/plugin-validation.json",
            "validation/catalog-validation.json",
            "validation/product-translations-validation.json",
        }
        unsafe, duplicates = unsafe_or_duplicate_members(complete)
        add("complete.crc", corrupt is None, corrupt or "all members passed CRC")
        add("complete.safe_paths", not unsafe, ", ".join(unsafe) or "no unsafe members")
        add("complete.duplicates", not duplicates, ", ".join(duplicates) or "no duplicate members")
        add("complete.required", required_complete.issubset(names), f"members={len(names)} required={len(required_complete)}")
        component_mismatch = [
            name for name in [*expected, source_name] if complete.read(name) != (delivery / name).read_bytes()
        ]
        add("complete.component_bytes", not component_mismatch, f"verified={len(expected) + 1} mismatched={len(component_mismatch)}")
        embedded_sources = {
            "START-HERE-中文.md": delivery / "START-HERE-中文.md",
            "RELEASE-NOTES-中文.md": delivery / "RELEASE-NOTES-中文.md",
            "SHA256SUMS.txt": delivery / "SHA256SUMS.txt",
            "validation/theme-validation.json": release.REPORTS / "theme-validation.json",
            "validation/browser-validation.json": release.REPORTS / "browser-validation.json",
            "validation/browser-validation.md": release.REPORTS / "browser-validation.md",
            "validation/i18n-validation.json": release.REPORTS / "i18n-validation.json",
            "validation/php-ast-validation.json": release.REPORTS / "php-ast-validation.json",
            "validation/plugin-validation.json": release.PLUGIN / "validation-report.json",
            "validation/catalog-validation.json": release.IMPORT / "validation-report.json",
            "validation/product-translations-validation.json": release.IMPORT / "XIUJIN-product-translations-validation.json",
        }
        embedded_mismatch = [
            name
            for name, source in embedded_sources.items()
            if complete.read(name) != source.read_bytes()
        ]
        if complete.read("HOSTINGER-INSTALL-中文.md") != release.rendered_install_guide().encode("utf-8"):
            embedded_mismatch.append("HOSTINGER-INSTALL-中文.md")
        add(
            "complete.embedded_evidence",
            not embedded_mismatch,
            f"verified={len(embedded_sources) + 1} mismatched={len(embedded_mismatch)}",
        )

    with tempfile.TemporaryDirectory(prefix="xiujin-repro-") as temporary:
        second = Path(temporary)
        release.build_release(second, release.validation_evidence())
        generated_names = sorted(path.name for path in second.iterdir() if path.is_file())
        reproducibility_failures = [
            name
            for name in generated_names
            if not (delivery / name).is_file() or (delivery / name).read_bytes() != (second / name).read_bytes()
        ]
    add("release.reproducible", not reproducibility_failures, f"compared={len(generated_names)} mismatched={len(reproducibility_failures)}")

    failed = [item for item in checks if not item["passed"]]
    report = {
        "version": release.VERSION,
        "summary": {"checks": len(checks), "passed": len(checks) - len(failed), "failed": len(failed)},
        "checks": checks,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report["summary"], indent=2))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
