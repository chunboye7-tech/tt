#!/usr/bin/env python3
"""Build optimized theme media and the lazy-loaded 3D script."""

from pathlib import Path
import os
import shutil
from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parents[1]
THEME = ROOT / 'theme' / 'xiujin-furniture'
TARGET = THEME / 'assets' / 'images'
SOURCE_ROOT = Path(os.environ.get('XIUJIN_SOURCE_ROOT', ROOT / 'inputs' / 'chair-trade-studio'))
SHOPIFY_ASSETS = SOURCE_ROOT / 'xiujin-b2b-theme' / 'assets'
HOME_IMAGES = SOURCE_ROOT / 'uploaded-home-images'
CATALOG_IMAGES = Path(os.environ.get('XIUJIN_CATALOG_REVIEW', ROOT / 'inputs' / 'catalog-review'))

COPY_ASSETS = [
    'chair-110.webp', 'chair-8011.webp', 'chair-8021.webp', 'chair-8031.webp',
    'chair-8051.webp', 'chair-8061.webp', 'chair-executive.webp', 'chair-mesh-a.webp',
    'chair-row42.webp', 'chair-row81.webp', 'chair-row91.webp', 'chair-row101.webp',
    'chair-row111.webp', 'chair-row131.webp', 'chair-row141.webp', 'chair-row151.webp',
    'chair-row161.webp', 'chair-row171.webp', 'factory-assembly.webp',
    'factory-quality.webp', 'factory-packing.webp',
] + [f'home-main-{number}.webp' for number in range(1, 11)]

CONFIGURATIONS = {
    'config-black-ivory.webp': '1_image2.png',
    'config-red-rgb.webp': '0_image1.png',
    'config-blue-piping.webp': '3_image4.png',
    'config-yellow-black.webp': '4_image5.png',
    'config-red-bow.webp': '5_image6.png',
    'config-orange-fabric.webp': '6_image7.png',
}


def optimize(source: Path, destination: Path, size=(1000, 1400), quality=82):
    with Image.open(source) as image:
        image = ImageOps.exif_transpose(image)
        image.thumbnail(size, Image.Resampling.LANCZOS)
        if image.mode not in ('RGB', 'RGBA'):
            image = image.convert('RGBA' if 'A' in image.getbands() else 'RGB')
        image.save(destination, 'WEBP', quality=quality, method=6)


def build_hero():
    # Remove the baked English heading from the supplied square graphic so the
    # WordPress page can provide translatable, indexable HTML copy instead.
    source = HOME_IMAGES / 'main-9.png'
    with Image.open(source) as image:
        image = ImageOps.exif_transpose(image).convert('RGB')
        width, height = image.size
        top = round(height * 0.25)
        crop = image.crop((0, top, width, height))
        crop = crop.resize((1200, 900), Image.Resampling.LANCZOS)
        crop.save(TARGET / 'hero-chair-collection.webp', 'WEBP', quality=84, method=6)


def build_model_script():
    source = SHOPIFY_ASSETS / 'chair-model.js'
    code = source.read_text(encoding='utf-8')
    replacements = [
        ("preserveDrawingBuffer:true", "preserveDrawingBuffer:false"),
        (
            "let selected=0,theta=.46,phi=.10",
            "let selected=Math.max(0,Math.min(payload.variants.length-1,Number(select.value)||0)),theta=0,phi=.06",
        ),
        ("const scale=Math.min(window.devicePixelRatio||1,2)", "const scale=Math.min(window.devicePixelRatio||1,1.5)"),
        (
            "listen(canvas,'wheel',e=>{e.preventDefault();distance=Math.max(1.1,Math.min(4.8,distance*Math.exp(e.deltaY*.001)));schedule();},{passive:false});",
            "listen(canvas,'wheel',e=>{if(!(e.ctrlKey||e.metaKey))return;e.preventDefault();distance=Math.max(1.1,Math.min(4.8,distance*Math.exp(e.deltaY*.001)));schedule();},{passive:false});",
        ),
        (
            "for(const b of root.querySelectorAll('[data-angle]'))listen(b,'click',()=>{theta=Number(b.dataset.angle);phi=.06;schedule();});",
            "for(const b of root.querySelectorAll('[data-angle]'))listen(b,'click',()=>{theta=Number(b.dataset.angle);phi=.06;root.querySelectorAll('[data-angle]').forEach(button=>button.setAttribute('aria-pressed',String(button===b)));schedule();});",
        ),
        (
            "if(!gl){status.textContent=root.dataset.unavailableText||'3D preview is unavailable in this browser.';status.setAttribute('role','alert');return;}",
            "if(!gl){throw new Error(root.dataset.unavailableText||'3D preview is unavailable in this browser.');}",
        ),
    ]
    for old, new in replacements:
        if old not in code:
            raise RuntimeError(f'Expected model fragment not found: {old[:90]}')
        code = code.replace(old, new, 1)
    # The source renderer was embedded in a Shopify section. WordPress mounts
    # it explicitly after a click, so these platform listeners are dead code
    # and would create an unnecessary Shopify runtime marker.
    code = code.replace(
        "document.addEventListener('shopify:section:load',event=>mountAll(event.target));\n",
        "",
    ).replace(
        "document.addEventListener('shopify:section:unload',event=>unmountAll(event.target));\n",
        "",
    )
    (THEME / 'assets' / 'js' / 'chair-model.js').write_text(code, encoding='utf-8')


def main():
    TARGET.mkdir(parents=True, exist_ok=True)
    for name in COPY_ASSETS:
        source = SHOPIFY_ASSETS / name
        if not source.is_file():
            raise FileNotFoundError(source)
        shutil.copy2(source, TARGET / name)
    for target, source in CONFIGURATIONS.items():
        optimize(CATALOG_IMAGES / source, TARGET / target)
    build_hero()
    build_model_script()
    print(f'Built {len(list(TARGET.glob("*.webp")))} WebP assets')
    print(f'3D script: {(THEME / "assets/js/chair-model.js").stat().st_size} bytes')


if __name__ == '__main__':
    main()
