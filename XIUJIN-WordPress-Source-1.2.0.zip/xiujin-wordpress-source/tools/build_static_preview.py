#!/usr/bin/env python3
"""Build a standalone, no-network preview of the XIUJIN WordPress homepage.

The preview mirrors the theme templates while keeping every asset path relative.
It is safe to open through a local web server and never submits enquiry data.
"""

from __future__ import annotations

from dataclasses import dataclass
from html import escape
from pathlib import Path
import shutil


PROJECT = Path(__file__).resolve().parents[1]
THEME = PROJECT / "theme" / "xiujin-furniture"
THEME_ASSETS = THEME / "assets"
PREVIEW = PROJECT / "preview"
PREVIEW_ASSETS = PREVIEW / "assets"


@dataclass(frozen=True)
class Product:
    title: str
    category: str
    detail: str
    source_image: str
    preview_image: str


PRODUCTS = (
    Product("135° Reclining Gaming Chair", "Gaming chairs", "Recline · linked armrests", "chair-8011.webp", "catalog-series-01.webp"),
    Product("Mesh Gaming Chair", "Gaming chairs", "Mesh upholstery · reclining backrest", "chair-8031.webp", "catalog-series-02.webp"),
    Product("180° Reclining Gaming Chair", "Gaming chairs", "Deep recline · adjustable armrests", "chair-8051.webp", "catalog-series-03.webp"),
    Product("Mesh Office Chair", "Office chairs", "Mesh back · seat-height adjustment", "chair-110.webp", "catalog-series-04.webp"),
    Product("Steel-Frame Gaming Chair", "Gaming chairs", "Steel frame · linked armrests", "chair-8021.webp", "catalog-series-05.webp"),
    Product("Adjustable Gaming Chair", "Gaming chairs", "Tilt function · adjustable armrests", "chair-8061.webp", "catalog-series-06.webp"),
    Product("Mesh Office Chair with Fixed Armrests", "Mesh office chairs", "Height adjustment · swivel · steel base", "chair-row42.webp", "catalog-series-07.webp"),
    Product("Mesh Task Chair with Fixed Armrests", "Mesh office chairs", "Mesh upholstery · optional headrest", "chair-mesh-a.webp", "catalog-series-08.webp"),
    Product("Swivel Mesh Office Chair", "Mesh office chairs", "Fixed armrests · steel base", "chair-row81.webp", "catalog-series-09.webp"),
    Product("Height-Adjustable Mesh Task Chair", "Mesh office chairs", "Height adjustment · optional headrest", "chair-row91.webp", "catalog-series-10.webp"),
    Product("Mesh Office Chair with Headrest", "Mesh office chairs", "Headrest configuration · polypropylene base", "chair-row101.webp", "catalog-series-11.webp"),
    Product("Reclining Mesh Office Chair", "Mesh office chairs", "Reclining function · optional footrest", "chair-row111.webp", "catalog-series-12.webp"),
    Product("Reclining Executive Chair with 3D Armrests", "Executive chairs", "Padded 3D armrests · steel base", "chair-executive.webp", "catalog-series-13.webp"),
    Product("Padded Reclining Executive Chair", "Executive chairs", "Reclining function · padded seating", "chair-row131.webp", "catalog-series-14.webp"),
    Product("High-Back Reclining Executive Chair", "Executive chairs", "High-back profile · optional footrest", "chair-row141.webp", "catalog-series-15.webp"),
    Product("Reclining Office Chair with Padded Armrests", "Executive chairs", "Padded armrests · steel base", "chair-row151.webp", "catalog-series-16.webp"),
    Product("Height-Adjustable Reclining Office Chair", "Executive chairs", "Height adjustment · optional footrest", "chair-row161.webp", "catalog-series-17.webp"),
    Product("Mesh Reclining Swivel Desk Chair", "Mesh office chairs", "Mesh upholstery · recline · polypropylene base", "chair-row171.webp", "catalog-series-18.webp"),
)


CONFIGURATIONS = (
    ("Black / ivory", "config-black-ivory.webp", "Black and ivory reclining gaming chair catalog photo"),
    ("Red / black with color trim", "config-red-rgb.webp", "Red and black gaming chair with color trim catalog photo"),
    ("Black / white with blue piping", "config-blue-piping.webp", "Black and white gaming chair with blue piping catalog photo"),
    ("Black / yellow", "config-yellow-black.webp", "Black and yellow gaming chair catalog photo"),
    ("Red / black with shaped cushions", "config-red-bow.webp", "Red and black gaming chair with shaped cushions catalog photo"),
    ("Black / orange fabric", "config-orange-fabric.webp", "Black and orange fabric gaming chair catalog photo"),
)

# The supplied photo order differs from the original 3D scene order. Keep the
# mapping explicit so each thumbnail selects the model reconstructed from that
# same catalog finish.
CONFIGURATION_MODELS = (
    (0, "black-white"),
    (1, "red-black-color-trim"),
    (4, "blue-white"),
    (5, "yellow-black"),
    (2, "red-black"),
    (3, "orange-black"),
)


SHOWROOM = (
    ("Gaming chair overview", "Chair styling for a gaming workspace"),
    ("Recline reference", "Reclining position and footrest visual"),
    ("Back support reference", "Backrest and lumbar support visual"),
    ("Height adjustment reference", "Seat-height adjustment visual"),
    ("Upholstery reference", "Seat upholstery and cushion visual"),
    ("Armrest reference", "Linked armrest visual"),
    ("Base and caster reference", "Chair base and caster visual"),
    ("Workspace reference", "Chair shown across workspace settings"),
    ("Finish collection", "Multiple supplied color references"),
    ("Dimension reference", "Catalog dimension visual requiring confirmation"),
)


def section_heading(eyebrow: str, title: str, intro: str) -> str:
    return f"""
      <div class="section-heading" data-reveal>
        <div><span class="eyebrow">{escape(eyebrow)}</span><h2>{escape(title)}</h2></div>
        <p>{escape(intro)}</p>
      </div>"""


def arrow() -> str:
    return '<span class="arrow" aria-hidden="true"></span>'


def whatsapp_icon() -> str:
    return '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 2a9.72 9.72 0 0 0-8.43 14.57L2.3 21.2l4.74-1.24A9.7 9.7 0 1 0 12 2Zm0 17.45a7.72 7.72 0 0 1-3.94-1.08l-.28-.17-2.82.74.75-2.74-.18-.29A7.73 7.73 0 1 1 12 19.45Zm4.24-5.79c-.23-.12-1.37-.68-1.58-.75-.21-.08-.36-.12-.52.12-.15.23-.59.75-.72.9-.13.16-.27.18-.5.06-.23-.11-.98-.36-1.86-1.15a7 7 0 0 1-1.29-1.6c-.13-.23-.01-.36.1-.47.1-.1.23-.27.35-.4.11-.14.15-.24.23-.4.08-.15.04-.29-.02-.4-.06-.12-.52-1.25-.71-1.71-.19-.45-.38-.39-.52-.4h-.44c-.15 0-.4.06-.61.29-.21.23-.8.78-.8 1.9s.82 2.2.93 2.35c.12.16 1.6 2.45 3.88 3.44.54.23.96.37 1.29.48.54.17 1.04.15 1.43.09.44-.07 1.37-.56 1.56-1.1.19-.55.19-1.02.13-1.11-.06-.1-.21-.16-.44-.27Z"/></svg>'


def copy_assets() -> None:
    if not THEME_ASSETS.exists():
        raise FileNotFoundError(f"Theme assets are missing: {THEME_ASSETS}")

    if PREVIEW_ASSETS.exists():
        shutil.rmtree(PREVIEW_ASSETS)
    (PREVIEW_ASSETS / "css").mkdir(parents=True)
    (PREVIEW_ASSETS / "js").mkdir(parents=True)
    (PREVIEW_ASSETS / "images").mkdir(parents=True)

    shutil.copy2(THEME_ASSETS / "css" / "theme.css", PREVIEW_ASSETS / "css" / "theme.css")
    shutil.copy2(THEME_ASSETS / "js" / "theme.js", PREVIEW_ASSETS / "js" / "theme.js")
    shutil.copy2(THEME_ASSETS / "js" / "chair-model.js", PREVIEW_ASSETS / "js" / "chair-model.js")

    # Public preview filenames intentionally omit all internal source numbers.
    for product in PRODUCTS:
        shutil.copy2(
            THEME_ASSETS / "images" / product.source_image,
            PREVIEW_ASSETS / "images" / product.preview_image,
        )

    names = ["hero-chair-collection.webp"]
    names.extend(image for _, image, _ in CONFIGURATIONS)
    names.extend(f"home-main-{index}.webp" for index in range(1, 11))
    names.extend(("factory-assembly.webp", "factory-quality.webp", "factory-packing.webp"))
    for name in names:
        shutil.copy2(THEME_ASSETS / "images" / name, PREVIEW_ASSETS / "images" / name)


def category_cards() -> str:
    categories = (
        ("Gaming chairs", "Reclining and adjustable seating for gaming and creator setups.", "catalog-series-03.webp", "coral"),
        ("Mesh office chairs", "Breathable task seating for office and home workspaces.", "catalog-series-04.webp", "teal"),
        ("Executive office chairs", "High-back and padded seating for management and meeting spaces.", "catalog-series-13.webp", "amber"),
    )
    cards = []
    for title, copy, image, accent in categories:
        cards.append(
            f"""
        <article class="category-card category-card--{accent}" data-reveal>
          <div class="category-image"><img src="assets/images/{image}" width="720" height="720" loading="lazy" decoding="async" alt="{escape(title)}"></div>
          <div class="category-copy"><span>Product category</span><h3>{escape(title)}</h3><p>{escape(copy)}</p><a href="#catalog">View chair series {arrow()}</a></div>
        </article>"""
        )
    return "".join(cards)


def product_cards() -> str:
    cards = []
    for product in PRODUCTS:
        title = escape(product.title)
        cards.append(
            f"""
        <article class="product-card" data-reveal>
          <a class="product-image" href="#quote" data-enquiry-product="{title}"><img src="assets/images/{product.preview_image}" width="720" height="720" loading="lazy" decoding="async" alt="{title}"></a>
          <div class="product-copy"><span class="product-category">{escape(product.category)}</span><h3>{title}</h3><p>{escape(product.detail)}</p><a class="card-link" href="#quote" data-enquiry-product="{title}">Enquire about this chair {arrow()}</a></div>
        </article>"""
        )
    return "".join(cards)


def configuration_choices() -> str:
    choices = []
    for index, ((title, image, alt), (model_index, model_key)) in enumerate(zip(CONFIGURATIONS, CONFIGURATION_MODELS)):
        pressed = "true" if index == 0 else "false"
        choices.append(
            f"""
              <button type="button" class="configuration-option" data-config-choice data-model-index="{model_index}" data-model-key="{model_key}" data-image="assets/images/{image}" data-title="{escape(title)}" data-alt="{escape(alt)}" aria-pressed="{pressed}">
                <img src="assets/images/{image}" width="180" height="220" loading="lazy" decoding="async" alt=""><span>{escape(title)}</span>
              </button>"""
        )
    return "".join(choices)


def model_options() -> str:
    options = sorted(
        (
            (model_index, title)
            for (title, _, _), (model_index, _) in zip(CONFIGURATIONS, CONFIGURATION_MODELS)
        ),
        key=lambda item: item[0],
    )
    return "".join(f'<option value="{model_index}">{escape(title)}</option>' for model_index, title in options)


def showroom_cards() -> str:
    cards = []
    for index, (title, alt) in enumerate(SHOWROOM, start=1):
        safe_title = escape(title)
        cards.append(
            f"""
          <article class="showroom-card" data-reveal>
            <img src="assets/images/home-main-{index}.webp" width="1024" height="1024" loading="lazy" decoding="async" alt="{escape(alt)}">
            <div><span>Supplied marketing visual</span><h3>{safe_title}</h3><a href="#quote" data-enquiry-product="{safe_title}">Ask about this detail {arrow()}</a></div>
          </article>"""
        )
    return "".join(cards)


def build_html() -> str:
    categories = category_cards()
    products = product_cards()
    configs = configuration_choices()
    models = model_options()
    showroom = showroom_cards()

    html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Office &amp; Gaming Chair Supplier | XIUJIN Furniture</title>
  <meta name="description" content="Explore XIUJIN office, executive and gaming chairs for factory-direct wholesale and retail enquiries.">
  <meta name="robots" content="noindex,nofollow">
  <link rel="icon" href="data:,">
  <link rel="stylesheet" href="assets/css/theme.css">
  <script>window.xiujinTheme={{menuOpen:'Open navigation',menuClose:'Close navigation',modelLoading:'Loading interactive view…',modelError:'The interactive view could not load.',modelScript:'assets/js/chair-model.js'}};</script>
  <script src="assets/js/theme.js" defer></script>
</head>
<body class="home" data-static-preview="true">
  <a class="skip-link screen-reader-text" href="#primary">Skip to content</a>
  <div class="announcement-bar">
    <div class="page-width announcement-inner">
      <p>Factory-direct chair supply · Wholesale and retail enquiries</p>
      <div class="language-switcher"><label class="screen-reader-text" for="PreviewLanguage">Preview language</label><select id="PreviewLanguage" title="English, Spanish and Portuguese are configured in WordPress"><option>English</option><option>Español</option><option>Português</option></select></div>
    </div>
  </div>
  <header class="site-header" data-site-header>
    <div class="page-width header-inner">
      <a class="site-brand" href="#primary" rel="home"><span class="brand-mark" aria-hidden="true">X</span><span class="brand-copy"><strong>XIUJIN</strong><small>Office &amp; gaming chairs</small></span></a>
      <nav class="primary-nav" aria-label="Primary navigation"><ul class="primary-menu"><li><a href="#collections">Chairs</a></li><li><a href="#wholesale-retail">Wholesale &amp; retail</a></li><li><a href="#factory">Factory &amp; quality</a></li><li><a href="#process">How to order</a></li></ul></nav>
      <div class="header-actions"><a class="header-whatsapp" href="https://wa.me/8618406845852" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp">{whatsapp_icon()}<span>WhatsApp</span></a><a class="button button--compact" href="#quote">Request a quote {arrow()}</a><button class="menu-toggle" type="button" aria-expanded="false" aria-controls="MobileNavigation" data-menu-toggle><span class="menu-icon" aria-hidden="true"></span><span class="screen-reader-text">Open navigation</span></button></div>
    </div>
    <nav id="MobileNavigation" class="mobile-navigation" aria-label="Mobile navigation" data-mobile-menu hidden><a href="#collections">Chairs</a><a href="#wholesale-retail">Wholesale &amp; retail</a><a href="#factory">Factory &amp; quality</a><a href="#process">How to order</a><a href="#quote">Request a quote</a></nav>
  </header>

  <main id="primary" class="site-main home-main">
    <section class="hero-section">
      <div class="hero-orb hero-orb--one" aria-hidden="true"></div><div class="hero-orb hero-orb--two" aria-hidden="true"></div>
      <div class="page-width hero-grid">
        <div class="hero-copy">
          <span class="eyebrow">XIUJIN FURNITURE · FACTORY DIRECT</span>
          <h1>Office &amp; gaming chairs. Wholesale &amp; retail.</h1>
          <p>Compare office, executive and gaming chair series, confirm the required configuration and request a current quotation for your market.</p>
          <div class="hero-actions"><a class="button button--gold" href="#quote">Request wholesale quote {arrow()}</a><a class="text-link" href="#catalog">Explore the chair catalog {arrow()}</a></div>
          <div class="hero-paths"><div><strong>Wholesale sourcing</strong><span>Quantities, configurations and destination confirmed by quotation</span></div><div><strong>Retail enquiries</strong><span>Individual chair requests are confirmed through an enquiry</span></div></div>
        </div>
        <div class="hero-media">
          <img class="hero-image" src="assets/images/hero-chair-collection.webp" width="1200" height="900" loading="eager" fetchpriority="high" decoding="async" alt="Five gaming chair styles in blue, yellow, orange, red and black with white accents">
          <div class="hero-color-dots" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></div>
          <p class="hero-media-note"><span>Multiple finishes</span>Confirm current color and upholstery options with your quotation.</p>
        </div>
      </div>
    </section>
    <section class="proof-strip" aria-label="Catalog summary"><div class="page-width proof-grid"><div class="proof-item"><strong data-counter="18">18</strong><span>source catalog series</span></div><div class="proof-item"><strong data-counter="58">58</strong><span>catalog visual configurations</span></div><div class="proof-item"><strong data-counter="3">3</strong><span>seating categories</span></div><div class="proof-item proof-item--text"><strong>B2B + retail</strong><span>quotation and enquiry paths</span></div></div></section>

    <section id="collections" class="section categories-section"><div class="page-width">
      {section_heading("Chair categories", "Choose the right seat for your market.", "Start with a seating category, then compare the available series and product-specific options.")}
      <div class="category-grid">{categories}</div>
    </div></section>

    <section id="wholesale-retail" class="section paths-section"><div class="page-width paths-grid">
      <article class="path-card path-card--wholesale" data-reveal><span class="eyebrow">Wholesale sourcing</span><h2>Build a chair order around your market.</h2><p>Share the chair series, quantities, destination and preferred configuration. Packaging, minimum order, lead time and commercial terms are confirmed in the quotation.</p><a class="button button--gold" href="#quote">Start a wholesale enquiry {arrow()}</a></article>
      <article class="path-card path-card--retail" data-reveal><span class="eyebrow">Retail enquiries</span><h2>Ask about individual chair models.</h2><p>Browse the catalog and tell us the model, configuration and quantity you need. We confirm current availability, price and delivery through a direct enquiry.</p><a class="button button--outline-light" href="#catalog">Browse product series {arrow()}</a></article>
    </div></section>

    <section id="catalog" class="section catalog-section"><div class="page-width">
      {section_heading("Chair catalog", "Explore all 18 source series.", "Each series has an independent introduction. Ask us to confirm the configuration, availability and current quotation before ordering.")}
      <div class="product-grid">{products}</div>
      <p class="catalog-note">Source-catalog descriptions are provided for selection. Final materials, colors, dimensions, packaging, price and availability follow the confirmed quotation.</p>
    </div></section>

    <section id="configurations" class="section configuration-section" data-config-gallery><div class="page-width">
      {section_heading("Real product references", "Compare each finish with its matching 3D view.", "Select a supplied catalog photo to display the corresponding 3D approximation. Use the photo to confirm the exact color and upholstery.")}
      <div class="configuration-layout">
        <figure class="reference-card" data-reveal><div class="reference-image"><img data-config-image src="assets/images/config-black-ivory.webp" width="910" height="1451" loading="lazy" decoding="async" alt="Black and ivory reclining gaming chair catalog photo"></div><figcaption><span>Actual catalog photo</span><strong data-config-title aria-live="polite">Black / ivory</strong><small>Use the photo to confirm visible color and upholstery details.</small></figcaption></figure>
        <div class="model-card" data-model-loader data-model-src="assets/js/chair-model.js" data-reveal>
          <div class="model-heading"><span>Interactive 3D reference</span><strong data-model-title aria-live="polite">Black / ivory</strong></div>
          <div class="model-shell" data-chair-model data-drag-zoom="Drag to rotate · Use buttons to zoom" data-selected-finish="Black / ivory" data-load-prompt="Load the 3D view to inspect this finish." data-error-text="The 3D view could not load." data-unavailable-text="3D is unavailable in this browser.">
            <img class="model-poster" data-model-poster src="assets/images/config-black-ivory.webp" width="910" height="1451" loading="lazy" decoding="async" alt="">
            <label class="screen-reader-text" for="ChairReferenceSelect">3D appearance</label><select class="screen-reader-text" id="ChairReferenceSelect" data-model-select tabindex="-1" aria-hidden="true">{models}</select>
            <canvas tabindex="-1" aria-label="Interactive 3D chair reference. Use arrow keys to rotate and plus or minus to zoom." aria-keyshortcuts="ArrowLeft ArrowRight ArrowUp ArrowDown + -" role="img">Interactive chair reference</canvas>
            <button class="model-load-button button button--gold" type="button" data-model-load aria-describedby="ChairModelStatus">Load 3D view {arrow()}</button>
            <div class="model-controls" role="group" aria-label="Choose viewing angle"><button type="button" data-angle="0" aria-pressed="true" disabled>Front</button><button type="button" data-angle="3.1415926536" aria-pressed="false" disabled>Back</button><button type="button" data-angle="-1.5707963268" aria-pressed="false" disabled>Left</button><button type="button" data-angle="1.5707963268" aria-pressed="false" disabled>Right</button><button type="button" data-zoom="0.82" disabled>Zoom in</button><button type="button" data-zoom="1.22" disabled>Zoom out</button></div>
            <span id="ChairModelStatus" class="model-status" data-status aria-live="polite">Load the 3D view to inspect this finish.</span>
          </div>
          <p class="model-disclosure">The 3D object is an approximate visual reference reconstructed from supplied photos. Confirm construction and dimensions against production specifications.</p>
        </div>
      </div>
      <div class="configuration-picker" data-reveal><div><strong>Photo configurations</strong><span>Select a photo and matching 3D finish</span></div><div class="configuration-options" role="group" aria-label="Product photo configurations">{configs}</div></div>
    </div></section>

    <section id="showroom" class="section showroom-section" data-showroom><div class="page-width">
      <div class="showroom-heading" data-reveal><div><span class="eyebrow">Visual catalog</span><h2>See the chairs in more detail.</h2></div><p>Browse supplied product visuals, then request confirmation for the exact configuration you plan to order.</p><div class="showroom-controls"><button type="button" data-showroom-direction="-1" aria-label="Previous visuals">‹</button><button type="button" data-showroom-direction="1" aria-label="Next visuals">›</button></div></div>
      <div class="showroom-track" data-showroom-track tabindex="0" aria-label="Chair visual catalog">{showroom}</div>
      <p class="showroom-note">Marketing visuals support product selection. Verify all written claims, measurements and options against current production information before publishing them as specifications.</p>
    </div></section>

    <section id="factory" class="section factory-section"><div class="factory-grid-pattern" aria-hidden="true"></div><div class="page-width">
      {section_heading("Factory & supply workflow", "From chair production to market-ready supply.", "Discuss production configuration, quality review, packaging and dispatch requirements for your order.")}
      <div class="factory-grid">
        <article class="factory-card" data-reveal><div class="factory-image"><img src="assets/images/factory-assembly.webp" width="1600" height="900" loading="lazy" decoding="async" alt="Illustration of an organized chair assembly environment"><span>Workflow illustration</span></div><div><small>01</small><h3>Assembly workflow</h3><p>An illustration of an organized chair assembly environment.</p></div></article>
        <article class="factory-card" data-reveal><div class="factory-image"><img src="assets/images/factory-quality.webp" width="1600" height="900" loading="lazy" decoding="async" alt="Illustration of a chair inspection and review stage"><span>Workflow illustration</span></div><div><small>02</small><h3>Quality review</h3><p>An illustration of a chair inspection and review stage.</p></div></article>
        <article class="factory-card" data-reveal><div class="factory-image"><img src="assets/images/factory-packing.webp" width="1600" height="900" loading="lazy" decoding="async" alt="Illustration of organized packing and dispatch preparation"><span>Workflow illustration</span></div><div><small>03</small><h3>Packing and dispatch</h3><p>An illustration of organized packing and dispatch preparation.</p></div></article>
      </div>
      <div class="factory-disclosure" data-reveal><strong>Image disclosure</strong><p>These are production workflow illustrations. Replace them with verified photographs of the actual facility before presenting them as factory photography.</p></div>
    </div></section>

    <section id="process" class="section process-section"><div class="page-width">
      {section_heading("From enquiry to order", "A clear path to your next chair order.", "The process keeps product selection separate from the final commercial confirmation.")}
      <div class="process-grid">
        <article class="process-step" data-reveal><span>01</span><h3>Choose chair series</h3><p>Shortlist the seating styles that fit your customers or project.</p></article>
        <article class="process-step" data-reveal><span>02</span><h3>Confirm configuration</h3><p>Discuss upholstery, colors, components, packaging and quantity.</p></article>
        <article class="process-step" data-reveal><span>03</span><h3>Receive quotation</h3><p>Review the current price, minimum order, lead time and shipping terms.</p></article>
        <article class="process-step" data-reveal><span>04</span><h3>Confirm the order</h3><p>Agree on samples, payment and delivery details before proceeding.</p></article>
      </div>
      <div class="faq-layout"><div data-reveal><span class="eyebrow">Before you order</span><h2>Details we confirm with you.</h2></div><div class="faq-list"><details data-reveal><summary>Can I request mixed chair series?</summary><p>Tell us which series and quantities you need. Feasibility, packing and commercial terms are confirmed with the quotation.</p></details><details data-reveal><summary>Are all colors and options always available?</summary><p>Availability can vary by chair series and order. Use the catalog photos as references and confirm current options before ordering.</p></details><details data-reveal><summary>Can I enquire about a single chair?</summary><p>Yes. Send the model and quantity you need. We confirm availability, price and delivery directly; this site does not take online payment.</p></details></div></div>
    </div></section>

    <section id="quote" class="section quote-section"><div class="quote-orb" aria-hidden="true"></div><div class="page-width quote-layout">
      <div class="quote-copy" data-reveal><span class="eyebrow">Discuss your order</span><h2>Your next chair order starts here.</h2><p>Share the chair series, quantity, destination and configuration you need. We will use those details to discuss a current quotation.</p><div class="quote-checklist"><strong>A useful enquiry includes</strong><span>Chair series or category</span><span>Estimated quantity</span><span>Destination country or port</span><span>Preferred configuration</span></div></div>
      <div class="quote-form-shell" data-reveal>
        <form class="xiujin-inquiry-form" data-preview-form>
          <div class="inquiry-grid">
            <div class="inquiry-field"><label for="PreviewProduct">Chair series / category *</label><input id="PreviewProduct" data-product-field name="product" required></div>
            <div class="inquiry-field"><label for="PreviewQuantity">Estimated quantity *</label><input id="PreviewQuantity" name="quantity" type="number" min="1" step="1" required></div>
            <div class="inquiry-field"><label for="PreviewDestination">Destination country / port *</label><input id="PreviewDestination" name="destination" required></div>
            <div class="inquiry-field"><label for="PreviewCompany">Company</label><input id="PreviewCompany" name="company"></div>
            <div class="inquiry-field"><label for="PreviewName">Your name *</label><input id="PreviewName" name="name" required></div>
            <div class="inquiry-field"><label for="PreviewEmail">Business email *</label><input id="PreviewEmail" name="email" type="email" required></div>
            <div class="inquiry-field inquiry-field--wide"><label for="PreviewWhatsapp">WhatsApp</label><input id="PreviewWhatsapp" name="whatsapp" type="tel"></div>
            <div class="inquiry-field inquiry-field--wide"><label for="PreviewRequirements">Configuration &amp; order requirements</label><textarea id="PreviewRequirements" name="requirements" placeholder="Materials, colors, footrest options, mixed series, timing and other requirements"></textarea></div>
          </div>
          <button class="button" type="submit">Preview enquiry {arrow()}</button>
          <p class="inquiry-note">Static design preview only. This local form never sends data.</p>
          <p class="inquiry-message" data-preview-message role="status" tabindex="-1" hidden>Preview complete. No enquiry was sent.</p>
        </form>
      </div>
    </div></section>
  </main>

  <footer class="site-footer"><div class="page-width footer-grid"><div class="footer-brand"><strong>XIUJIN</strong><p>Office chairs, executive seating and gaming chairs for wholesale and retail enquiries.</p></div><div><h2>Explore</h2><nav class="footer-links" aria-label="Footer navigation"><a href="#collections">Chair categories</a><a href="#catalog">Product catalog</a><a href="#process">How to order</a><a href="#quote">Request a quote</a></nav></div><div><h2>Contact</h2><p>Bazhou Xiujin Furniture Co., Ltd</p><a href="tel:+8618406845852">+86 184 0684 5852</a></div><div><h2>Follow</h2><div class="social-links"><a class="social-link" href="#quote" title="Configure the Facebook URL in WordPress"><span>Facebook</span></a><a class="social-link" href="#quote" title="Configure the Instagram URL in WordPress"><span>Instagram</span></a><a class="social-link" href="#quote" title="Configure the TikTok URL in WordPress"><span>TikTok</span></a><a class="social-link social-link--whatsapp" href="https://wa.me/8618406845852" target="_blank" rel="noopener noreferrer"><span>WhatsApp</span></a><a class="social-link" href="#quote" title="Configure the Messenger URL in WordPress"><span>Messenger</span></a></div></div></div><div class="page-width footer-bottom"><p>&copy; 2026 Bazhou Xiujin Furniture Co., Ltd</p><p>Specifications, availability and commercial terms are confirmed for each order.</p></div></footer>
  <div class="mobile-actions"><a href="#quote">Quote</a></div>
  <script>
    document.addEventListener('DOMContentLoaded', () => {{
      const form = document.querySelector('[data-preview-form]');
      const message = document.querySelector('[data-preview-message]');
      form?.addEventListener('submit', (event) => {{
        event.preventDefault();
        if (!form.reportValidity()) return;
        if (message) {{ message.hidden = false; message.focus(); }}
      }});
      document.querySelector('#PreviewLanguage')?.addEventListener('change', (event) => {{
        event.target.value = 'English';
        event.target.title = 'Use Polylang or WPML in WordPress to preview translated pages.';
      }});
    }});
  </script>
</body>
</html>
"""
    return html


def validate(html: str) -> None:
    lowered = html.lower()
    checks = {
        "18 product cards": html.count('class="product-card"') == 18,
        "6 real configurations": html.count("data-config-choice") == 6,
        "10 showroom visuals": html.count('class="showroom-card"') == 10,
        "3 factory cards": html.count('class="factory-card"') == 3,
        "no visible internal hero number": "8011" not in html,
        "no zero-dollar placeholder": "$0" not in html and "$ 0" not in html,
        "relative assets": "assets/css/theme.css" in html and "assets/js/theme.js" in html,
        "lazy 3D": "data-model-load" in html and "data-model-src" in html,
        "reduced-motion CSS": "prefers-reduced-motion" in (THEME_ASSETS / "css" / "theme.css").read_text(encoding="utf-8"),
        "English language": '<html lang="en">' in lowered,
    }
    failures = [label for label, passed in checks.items() if not passed]
    if failures:
        raise RuntimeError("Static preview validation failed: " + ", ".join(failures))


def main() -> None:
    PREVIEW.mkdir(parents=True, exist_ok=True)
    copy_assets()
    html = build_html()
    validate(html)
    (PREVIEW / "index.html").write_text(html, encoding="utf-8")
    print(f"Built {PREVIEW / 'index.html'}")
    print("Products: 18 · Configurations: 6 · Showroom: 10 · Factory: 3")


if __name__ == "__main__":
    main()
